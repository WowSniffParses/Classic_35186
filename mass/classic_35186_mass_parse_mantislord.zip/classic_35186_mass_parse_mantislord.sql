# TrinityCore - WowPacketParser
# File name: multi
# Detected build: v1_13_5_35186
# Detected locale: enUS
# Targeted database: Classic
# Parsing date: 03/14/2021 11:41:15

SET @ACCID = 0; 
SET @CGUID = 0; 
SET @DGUID = 0;
SET @IGUID = 0; 
SET @OGUID = 0; 
SET @PGUID = 0; 
SET @POIID = 0; 
SET @LOOTID = 0; 
SET @SNIFFID = 0; 

DELETE FROM `player_classlevelstats` WHERE (`class`=1 AND `level` IN (2,1)) OR (`class`=3 AND `level`=60);
INSERT INTO `player_classlevelstats` (`class`, `level`, `basehp`, `basemana`) VALUES
(1, 2, 29, 0),
(3, 60, 1467, 1720),
(1, 1, 20, 0);

DELETE FROM `player_levelstats` WHERE (`race`=6 AND `class`=1 AND `level`=2) OR (`race`=4 AND `class`=3 AND `level`=60) OR (`race`=2 AND `class`=1 AND `level`=1);
INSERT INTO `player_levelstats` (`race`, `class`, `level`, `str`, `agi`, `sta`, `inte`, `spi`) VALUES
(6, 1, 2, 29, 16, 25, 15, 22),
(4, 3, 60, 52, 130, 89, 65, 70),
(2, 1, 1, 26, 17, 24, 17, 23);


DELETE FROM `gameobject_template_addon` WHERE `entry` IN (173047 /*173047*/, 179596 /*179596*/, 105576 /*105576*/, 173221 /*173221*/, 179881 /*179881*/, 178571 /*178571*/, 180842 /*180842*/, 180822 /*180822*/, 180836 /*180836*/, 180830 /*180830*/);
INSERT INTO `gameobject_template_addon` (`entry`, `faction`, `flags`) VALUES
(173047, 29, 0), -- 173047
(179596, 35, 0), -- 179596
(105576, 35, 0), -- 105576
(173221, 29, 0), -- 173221
(179881, 114, 0), -- 179881
(178571, 114, 0), -- 178571
(180842, 0, 32), -- 180842
(180822, 0, 32), -- 180822
(180836, 0, 32), -- 180836
(180830, 0, 32); -- 180830


DELETE FROM `broadcast_text` WHERE `entry` IN (8116, 11384, 11186, 11183, 11180, 11162, 11171, 11174, 11417, 11151, 11147, 11149, 11153, 11158, 11156, 11201, 11198, 11189, 11260, 11257, 11422, 11212, 11221, 11209, 11421, 11224, 11227, 11233, 11338, 11263, 11420, 11419, 11341, 11245, 11248, 11251, 11652, 11372, 11239, 11242, 11342, 11236, 4857, 9869);
INSERT INTO `broadcast_text` (`male_text`, `female_text`, `entry`, `language_id`, `condition_id`, `emotes_id`, `flags`, `sound_id1`, `sound_id2`, `emote_id1`, `emote_id2`, `emote_id3`, `emote_delay1`, `emote_delay2`, `emote_delay3`, `sniff_build`) VALUES
('When mounted on the back of a wind rider, one sees that its reputation for strength and speed is well earned.', '', 8116, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 35186),
('', 'Hail, $c. I trust you are here to inquire on the Ahn\'Qiraj war effort. We are going to need a great deal of assistance.$B$BThe war effort is a united effort between the Horde and Alliance to prepare for the impending war against the Silithid and their masters in Ahn\'Qiraj. In Orgrimmar\'s Valley of Spirits, we are collecting a vast number of goods to create war materiel, and these gathering tasks are what we need your help with.$B$BCan I convince you to speak with our commander about helping out?', 11384, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 35186),
('All is gathered, $c. All is being transported for final preparation to Silithus and should arrive within $2113w days. All of our combined forces await the $g hero : heroine; that will complete the reunification of the Scepter of the Shifting Sands, ring the gong and begin the Ahn\'Qiraj War.', '', 11186, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('', 'Looks like the last of the goods we\'ve collected are shipping out to Silithus over the next $2113w days. And once that\'s done, someone will have to come along and ring the gong on the Scarab Dais, outside of Ahn\'Qiraj, to open the gates. That\'s when our bandages will come in handy.', 11183, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('', 'Even as we speak, $c, all of the war materiel is being transported over to Silithus. By the looks of things, all of it should arrive in less than $2113w days. After that, a $g hero : heroine; will need to come along and ring the gong at the Scarab Dais. Then the war will begin in earnest.', 11180, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('', 'As I understand it dear, everything has been gathered and the final materiel is being assembled and shipped off to Cenarion Hold. The last of it should arrive in less than $2113w days. Once our equipment and forces are all there, the bearer of the Scepter of the Shifting Sands can ring the gong near Ahn\'Qiraj to open the gates. Then the war will begin.', 11162, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('A-ten-hut! All Ahn\'Qiraj war materiel accounted for and in the process of being transported to Cenarion Hold $g sir : ma\'am;! I am told that the last of it should arrive in less than $2113w days. Once that is done, and someone rings that gong over there to open the gates, I guarantee that we\'ll give those bugs one heck of a fight!', '', 11171, 0, 0, 0, 1, 0, 0, 66, 1, 0, 0, 0, 0, 35186),
('', 'Hey there, $c! Looks like the Horde collected the last of their stuff, and now theirs and ours is being shipped over to Silithus as we speak. I\'m told it\'ll be there in less than $2113w days, and then someone can ring that big gong near the Ahn\'Qiraj gates to start the war.', 11174, 0, 0, 0, 1, 0, 0, 3, 1, 0, 0, 0, 0, 35186),
('Greetings, $c - I\'m a Commendation Officer acting on behalf of Ironforge.  It is my duty to assist adventurers who have received Alliance Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Ironforge for your duty and service.\n', 'Greetings, $c - I\'m a Commendation Officer acting on behalf of Ironforge.  It is my duty to assist adventurers who have received Alliance Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Ironforge for your duty and service.', 11417, 0, 0, 0, 1, 0, 0, 66, 1, 0, 0, 0, 0, 35186),
('', 'Hello, $c. From what I\'ve been told, everything\'s been collected, and all of the materiel for the war is being shipped over to Silithus as we speak. It should all be there in less than $2113w days. Once that\'s done, and the gong has been rung with the Scepter of the Shifting Sands, the war will really begin.', 11151, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('It\'s all over \'cept for the crying now. All of the war materiel is being transported to Cenarion Hold in Silithus, and will be there in less than $2113w days. Shouldn\'t be much longer until the scepter is assembled and the war finally begins.', '', 11147, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('Woo hoo, here we go! Everyone\'s collected everything, and it\'s all being airlifted via zeppelin to Silithus as we speak. The last of it should be there in less than $2113w days. Once it\'s all over there, and the scepter has been assembled, the war against those dirty insects can begin. As they say, \'Ship It!\'	', '', 11149, 0, 0, 0, 1, 0, 0, 1, 4, 0, 0, 0, 0, 35186),
('That\'s it, everything\'s been collected by both sides. Now it\'s all being transported over to Silithus and should be there in less than $2113w days. Once that\'s done and someone rings the gong on the Scarab Dais with the Scepter of the Shifting Sands, the war is on!', '', 11153, 0, 0, 0, 1, 0, 0, 1, 5, 0, 0, 0, 0, 35186),
('', 'Are you reporting for duty, $c? All of the war materiel for both the Horde and the Alliance is completed and being shipped to Silithus as we speak. It should all arrive in less than $2113w days. I hope that someone has found the different pieces of the Scepter of the Shifting Sands and put them all together.', 11158, 0, 0, 0, 1, 0, 0, 6, 1, 0, 0, 0, 0, 35186),
('All is completed, young $c. Even as we speak, both the Horde and the Alliance are in the process of transporting all final goods for the war into Silithus near Cenarion Hold, which should be complete in less than $2113w days. After that, the gong near the gates of Ahn\'Qiraj can be rung, and the war will begin.', '', 11156, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('', 'Greetings, $r. The war materiel is gradually being sent on its way and should be at Cenarion Hold within $2113w day\'s time. We can only hope that once it is there that someone, having assembled the Scepter of the Shifting Sands, will step forward to ring the gong and open the gates.', 11201, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('', 'All of the food and war materiel we gathered is on its way to Silithus. It should be there in less than $2113w days. Someone told me that once it\'s all assembled over near Cenarion Hold, someone\'s going to have to go ring the gong at the Scarab Dais to open the gates to Ahn\'Qiraj and start the war.', 11198, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('All of the fish and everything else is on its way to Silithus, and should be there in less than $2113w days. After that someone\'s going to have to ring that gong with the Scepter of the Shifting Sands to start the war.', '', 11189, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('If you heard that all of the Horde and Alliance collections have been completed, then you heard right, $c. All of the goods for the war that we gathered and prepared are in the process of being sent to Cenarion Hold in Silithus, with less than $2113w days until the last of it arrives there. After that I suppose we\'ll just have to wait and see who assembles that scepter to ring the gong with, which will open the gates to Ahn\'Qiraj and herald the war.', '', 11260, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 35186),
('Looks like there be only $2113w more days left to fish until all this here war materiel is shipped over to the Silithus desert mon. Then they\'s gonna be getting\' it all ready, and someone is gonna have to ring that gong down south of Cenarion Hold there to open them gates and be startin\' the war.', '', 11257, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('Greetings, $c - I\'m a Commendation Officer acting on behalf of the Undercity.  It is my duty to assist adventurers who have received Horde Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from the Undercity for your duty and service.\n', 'Greetings, $c - I\'m a Commendation Officer acting on behalf of the Undercity.  It is my duty to assist adventurers who have received Horde Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from the Undercity for your duty and service.\n', 11422, 0, 0, 0, 1, 0, 0, 66, 1, 0, 0, 0, 0, 35186),
('If someone has put together the magic scepter of the sands then the war with the bugs will be soon. I relish it, $c! The last of our war goods are on their way to Silithus and should be there within $2113w days. Go and bring honor to the Horde!', '', 11212, 0, 0, 0, 1, 0, 0, 1, 15, 0, 0, 0, 0, 35186),
('', 'And now the war, it be comin\' soon. All that be left is the sendin\' of all these goods and weapons to the Cenarion Hold in Silithus, and that is gonna be done within $2113w days. Then some brave soul is gonna have to be ringin\' the gong near those Ahn\'Qiraj gates to open \'em and start the war.', 11221, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('I\'ve heard that the preparations are being shipped over to Silithus and should all arrive in under $2113w days. I don\'t want to see one of those bugs burrowing through into my mine, so I hope that someone is taking the time to assemble that Scepter of the Shifting Sands so the gong can be rung, the gates opened and the war finally begun.', '', 11209, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('Greetings, $c - I\'m a Commendation Officer acting on behalf of Thunder Bluff.  It is my duty to assist adventurers who have received Horde Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Thunder Bluff for your duty and service.\n', 'Greetings, $c - I\'m a Commendation Officer acting on behalf of Thunder Bluff.  It is my duty to assist adventurers who have received Horde Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Thunder Bluff for your duty and service.\n\n', 11421, 0, 0, 0, 1, 0, 0, 66, 1, 0, 0, 0, 0, 35186),
('', 'It is true, young $r, we and the Alliance have gathered and prepared all that we will need for this upcoming conflict at Ahn\'Qiraj. Even now these things are being sent to Cenarion Hold, and they should all arrive within $2113w days. After all is in place, some person will need to ring the gong on the Scarab Dais to open the gates and start the war.', 11224, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('Whoa now, $c, Pele\'keiki thinkin\' that you not knowin\' all that stuff be on its way to Silithus. Pele\'keiki told the last of it be getting\' there in less than $2113w days, and after that some misguided fool gonna ring the gong outside the Ahn\'Qiraj gates to open \'em up and be startin\' the war.', '', 11227, 0, 0, 0, 1, 0, 0, 1, 11, 0, 0, 0, 0, 35186),
('', 'The end draws nigh! Even as we speak our supplies are being shipped to Silithus and should arrive within $2113w days. Once there I am sure that all we be assembled in quick order, and then we\'ll be awaiting the ringing of the gong at the gates to Ahn\'Qiraj to start the war. I look forward to analyzing whether our preparatory efforts will make a difference.', 11233, 0, 0, 0, 1, 0, 0, 5, 1, 0, 0, 0, 0, 35186),
('We are united in cause, $r. An ancient evil threatens to extinguish all life on Kalimdor and consume the world with its depravity... Its hatred of all things born of the great Shapers: The eternal Titans.$B$BWe are the first and the last lines of defense against the armies of C\'Thun. If we do not rise up and strike at our enemy, our enemy will surely destroy us.$B$BThe war effort needs you!', '', 11338, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 35186),
('That\'s right, um, $g lad : lass;, all of the war materiel is being transported to Silithus and the last of it should get there within $2113w days. After that, we\'ll all just have to wait and see who puts forth a $g hero : heroine; to reconstitute the Scepter of the Shifting Sands and ring the gong on the Scarab Dais. Only when that occurs will the war begin to open the gates of Ahn\'Qiraj.', '', 11263, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('Greetings, $c - I\'m a Commendation Officer acting on behalf of the Darkspear tribe.  It is my duty to assist adventurers who have received Horde Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from the Darkspear tribe for your duty and service.\n', 'Greetings, $c - I\'m a Commendation Officer acting on behalf of the Darkspear tribe.  It is my duty to assist adventurers who have received Horde Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from the Darkspear tribe for your duty and service.\n', 11420, 0, 0, 0, 1, 0, 0, 66, 1, 0, 0, 0, 0, 35186),
('Greetings, $c - I\'m a Commendation Officer acting on behalf of Orgrimmar.  It is my duty to assist adventurers who have received Horde Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Orgrimmar for your duty and service.\n', 'Greetings, $c - I\'m a Commendation Officer acting on behalf of Orgrimmar.  It is my duty to assist adventurers who have received Horde Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Orgrimmar for your duty and service.\n\n', 11419, 0, 0, 0, 1, 0, 0, 66, 1, 0, 0, 0, 0, 35186),
('A Horde Commendation Signet is awarded to a $g hero : heroine; who goes above and beyond the call of duty to the Horde.  Various Commendation Officers for the factions of the Horde are located in all of the major cities; speak with the one with whom you\'d like to raise your reputation, and give them the number of signets they ask for!$B$BBy the way, during the war effort here, if you\'d rather receive a material reward for your signets instead of reputation, seek out Warlord Gorchuk.', '', 11341, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('All has been gathered and is being sent to Silithus, $c. It should get there within $2113w days. I can only hope that after the gong is rung, and the gates opened, that our efforts here will make an impact and save many lives.', '', 11245, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('', 'Yes, you heard true, $c, all of our collections are complete and the last of the war materiel should arrive in Silithus within $2113w days. I am told that once all is assembled there, and our troops readied, someone from within the ranks of you heroes is going to ring the gong outside of Ahn\'Qiraj, already having assembled the Scepter of the Shifting Sands to do so with. I hope that we don\'t have to wait too long for that to happen.', 11248, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 35186),
('', 'All of the preparations are complete now, $c. We await the last of the materiel to be sent to Silithus, which should be in less than $2113w day\'s time. Then once the organization there is done with, someone will have to come forward and ring the gong on the Scarab Dais with the Scepter of the Shifting Sands. That is when the Ahn\'Qiraj War will begin. May the Earth Mother watch over all of us then.', 11251, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 35186),
('We stand together with the Alliance, $r. An evil, so old that the world has forgotten it, seeks to engulf us all; first on Kalimdor and then the rest of Azeroth. It is driven by a hatred of all things born of the great Shapers: The eternal Titans.$B$BWe are all that stand in the way of C\'Thun\'s armies. We will strike first and bring down the forces of Ahn\'Qiraj. Let all of Azeroth quake at the combined might of the Horde and Alliance.$B$BThe war effort needs you!', '', 11652, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 35186),
('The time for war is almost upon us, $c! Both the Horde and the Alliance have finished with their preparations. All of our war materiel is being shipped to Silithus as we speak. I\'d expect it all to arrive within $2113w days. When all is assembled there, the one who has completed the arduous task of reassembling the Scepter of the Shifting Sands will bang it against the Scarab Gong and open the gates to Ahn\'Qiraj. Then battle shall be joined as has not been seen in ages!$B$BLok\'tar Ogar!', '', 11372, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 35186),
('', 'Throm\'ka, $c. All of the war materiel is in final preparation and being sent to Silithus. It should arrive over the course of the next $2113w days. With the equipment readied, and our forces arrayed, all we will be waiting for is someone to ring the gong on the Scarab Dais, which should open the gates of Ahn\'Qiraj and start the war.$B$BLok\'tar Ogar!', 11239, 0, 0, 0, 1, 0, 0, 1, 15, 0, 0, 0, 0, 35186),
('All of our collections are completed, $c. That which we have assembled is in the process of being transported to Cenarion Hold in Silithus, and the rest of it should take no more than $2113w days to arrive. The Ahn\'Qiraj War can then start once that is done and someone brave and foolish rings the gong right outside of the gates down there.', '', 11242, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('', 'A Horde Commendation Signet is awarded to a $g hero : heroine; who goes above and beyond the call of duty to the Horde.  Various Commendation Officers for the factions of the Horde are located in all of the major cities; speak with the one with whom you\'d like to raise your reputation, and give them the number of signets they ask for!$B$BBy the way, during the war effort here, if you\'d rather receive a material reward for your signets instead of reputation, seek out Warlord Gorchuk.', 11342, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('', 'All of the collecting is done and the finished goods are being shipped over to Silithus as they\'re being completed. Looks like less than $2113w days until all of it is over there. After that we just need to get someone to ring that gong and open the gates to Ahn\'Qiraj. Then the real fun begins.', 11236, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 35186),
('What are you looking for?', 'What are you looking for?', 4857, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 35186),
('Look to this fallen dragon, $r. The might of the Horde is unquestionable!', '', 9869, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 35186);


DELETE FROM `playercreateinfo` WHERE (`class`=8 AND `race`=7) OR (`class`=1 AND `race` IN (4,3));
INSERT INTO `playercreateinfo` (`race`, `class`, `map`, `zone`, `position_x`, `position_y`, `position_z`, `orientation`) VALUES
(7, 8, 0, 0, -6240.32, 331.033, 382.758, 0),
(4, 1, 1, 0, 10311.3, 831.463, 1326.41, 0),
(3, 1, 0, 0, -6240.32, 331.033, 382.758, 0);


INSERT IGNORE INTO `sniff_data` (`sniff_build`, `sniff_id`, `object_type`, `id`, `data`) VALUES
(35186, @SNIFFID+0, 2, 13262, 'CAST'),
(35186, @SNIFFID+0, 6, 3083, 'SPAWN'),
(35186, @SNIFFID+0, 6, 2997, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3020, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3019, 'SPAWN'),
(35186, @SNIFFID+0, 6, 4721, 'SPAWN'),
(35186, @SNIFFID+0, 2, 7478, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 7475, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 14546, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 7499, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 7494, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 14791, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 15011, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 15012, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 20555, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 20557, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 20558, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 23301, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 26290, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 5323, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 8096, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 7128, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 1244, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 2383, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 7, 177269, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3084, 'SPAWN'),
(35186, @SNIFFID+0, 6, 8722, 'SPAWN'),
(35186, @SNIFFID+0, 6, 2998, 'SPAWN'),
(35186, @SNIFFID+0, 6, 6410, 'SPAWN'),
(35186, @SNIFFID+0, 6, 10278, 'SPAWN'),
(35186, @SNIFFID+0, 6, 2999, 'SPAWN'),
(35186, @SNIFFID+0, 7, 35591, 'SPAWN'),
(35186, @SNIFFID+0, 7, 50469, 'SPAWN'),
(35186, @SNIFFID+0, 7, 50468, 'SPAWN'),
(35186, @SNIFFID+0, 2, 20550, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 20551, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 20552, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 5232, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 6, 3007, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3011, 'SPAWN'),
(35186, @SNIFFID+0, 7, 177265, 'SPAWN'),
(35186, @SNIFFID+0, 6, 15702, 'SPAWN'),
(35186, @SNIFFID+0, 6, 11071, 'SPAWN'),
(35186, @SNIFFID+0, 6, 8674, 'SPAWN'),
(35186, @SNIFFID+0, 7, 177270, 'SPAWN'),
(35186, @SNIFFID+0, 2, 5301, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 21156, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 1243, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 2457, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 6, 3012, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3008, 'SPAWN'),
(35186, @SNIFFID+0, 6, 11084, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3093, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3003, 'SPAWN'),
(35186, @SNIFFID+0, 6, 15767, 'SPAWN'),
(35186, @SNIFFID+0, 6, 10054, 'SPAWN'),
(35186, @SNIFFID+0, 2, 20573, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 20574, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 21563, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 16092, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 21184, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 6, 14728, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3095, 'SPAWN'),
(35186, @SNIFFID+0, 7, 3286, 'SPAWN'),
(35186, @SNIFFID+0, 6, 15105, 'SPAWN'),
(35186, @SNIFFID+0, 7, 143985, 'SPAWN'),
(35186, @SNIFFID+0, 2, 9329, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 7598, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 15464, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 7597, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 19984, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 22841, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 15810, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 14585, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 14049, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 18384, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 13670, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 20885, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 15813, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 13364, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 13889, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 9335, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 13824, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 9332, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 16108, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 16184, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 16189, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 16198, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 16225, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 16217, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 29088, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 29193, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 29080, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 16284, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 16287, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 16295, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 16305, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 17489, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 20608, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 6, 7089, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3005, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3015, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3017, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3092, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3050, 'SPAWN'),
(35186, @SNIFFID+0, 6, 11051, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3004, 'SPAWN'),
(35186, @SNIFFID+0, 7, 175885, 'SPAWN'),
(35186, @SNIFFID+0, 6, 8358, 'SPAWN'),
(35186, @SNIFFID+0, 6, 8359, 'SPAWN'),
(35186, @SNIFFID+0, 6, 8356, 'SPAWN'),
(35186, @SNIFFID+0, 6, 8357, 'SPAWN'),
(35186, @SNIFFID+0, 6, 2996, 'SPAWN'),
(35186, @SNIFFID+0, 6, 8360, 'SPAWN'),
(35186, @SNIFFID+0, 7, 180394, 'SPAWN'),
(35186, @SNIFFID+0, 7, 152583, 'SPAWN'),
(35186, @SNIFFID+0, 7, 3298, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3014, 'SPAWN'),
(35186, @SNIFFID+0, 7, 177266, 'SPAWN'),
(35186, @SNIFFID+0, 2, 10937, 'CAST'),
(35186, @SNIFFID+0, 2, 10937, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 10951, 'CAST'),
(35186, @SNIFFID+0, 2, 10951, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 9414, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 15714, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 9346, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 9412, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 7504, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 7501, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 21969, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 14749, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 14777, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 14787, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 14528, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 15310, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 15334, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 17325, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 15320, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 15317, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 15330, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 15338, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 5227, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 20579, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 2, 15473, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 6, 3057, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 12383, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 8401, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3057, 'SPAWN'),
(35186, @SNIFFID+0, 6, 12383, 'SPAWN'),
(35186, @SNIFFID+0, 6, 8401, 'SPAWN'),
(35186, @SNIFFID+0, 2, 17462, 'CAST'),
(35186, @SNIFFID+0, 2, 17462, 'AURA_UPDATE'),
(35186, @SNIFFID+0, 6, 3018, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3028, 'SPAWN'),
(35186, @SNIFFID+0, 7, 177267, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3018, 'SPAWN'),
(35186, @SNIFFID+0, 6, 15164, 'SPAWN'),
(35186, @SNIFFID+0, 7, 177268, 'SPAWN'),
(35186, @SNIFFID+0, 6, 10881, 'SPAWN'),
(35186, @SNIFFID+0, 2, 7620, 'CAST'),
(35186, @SNIFFID+0, 2, 836, 'CAST'),
(35186, @SNIFFID+0, 6, 3029, 'SPAWN'),
(35186, @SNIFFID+0, 7, 178571, 'SPAWN'),
(35186, @SNIFFID+0, 13, 5500, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 15, 4326, '2995'),
(35186, @SNIFFID+0, 6, 15164, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3028, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3029, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3011, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3024, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 4721, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3024, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3013, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3014, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3013, 'SPAWN'),
(35186, @SNIFFID+0, 6, 11071, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3017, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3012, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3025, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3021, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3020, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3019, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 8398, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3022, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3025, 'SPAWN'),
(35186, @SNIFFID+0, 7, 3303, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3021, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3027, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3026, 'SPAWN'),
(35186, @SNIFFID+0, 6, 8398, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3023, 'SPAWN'),
(35186, @SNIFFID+0, 7, 3315, 'SPAWN'),
(35186, @SNIFFID+0, 7, 160426, 'SPAWN'),
(35186, @SNIFFID+0, 15, 6809, '15767'),
(35186, @SNIFFID+0, 15, 6790, '15702'),
(35186, @SNIFFID+0, 10, 8792, 'ACCEPT'),
(35186, @SNIFFID+0, 2, 18629, 'CAST'),
(35186, @SNIFFID+0, 13, 8107, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 6, 3083, 'QUERY_RESPONSE'),
(35186, @SNIFFID+0, 3, 1, 'LOAD_SCREEN'),
(35186, @SNIFFID+0, 6, 3978, 'SPAWN'),
(35186, @SNIFFID+0, 6, 2995, 'SPAWN'),
(35186, @SNIFFID+0, 6, 6746, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3001, 'SPAWN'),
(35186, @SNIFFID+0, 6, 3002, 'SPAWN'),
(35186, @SNIFFID+0, 7, 3296, 'SPAWN'),
(35186, @SNIFFID+0, 6, 5054, 'SPAWN'),
(35186, @SNIFFID+0, 6, 8362, 'SPAWN'),
(35186, @SNIFFID+0, 6, 5189, 'SPAWN'),
(35186, @SNIFFID+0, 6, 4451, 'SPAWN'),
(35186, @SNIFFID+0, 6, 8364, 'SPAWN'),
(35186, @SNIFFID+0, 6, 8363, 'SPAWN'),
(35186, @SNIFFID+0, 6, 8361, 'SPAWN'),
(35186, @SNIFFID+0, 6, 11869, 'SPAWN'),
(35186, @SNIFFID+0, 6, 2987, 'SPAWN'),
(35186, @SNIFFID+1, 2, 23221, 'CAST'),
(35186, @SNIFFID+1, 2, 3183, 'CAST'),
(35186, @SNIFFID+1, 2, 21925, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7685, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20592, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20593, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20591, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13364, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14056, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13823, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7219, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15464, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9333, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9336, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15811, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14049, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21975, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7597, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9331, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24153, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13669, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19990, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21874, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 22841, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13889, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14136, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14179, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14159, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14167, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14142, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14075, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13872, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 30920, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13807, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13852, 'AURA_UPDATE');

INSERT IGNORE INTO `sniff_data` (`sniff_build`, `sniff_id`, `object_type`, `id`, `data`) VALUES
(35186, @SNIFFID+1, 2, 13875, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13866, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13845, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13792, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13863, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 1860, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 2836, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20596, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20595, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 16092, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21184, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 6, 5595, 'SPAWN'),
(35186, @SNIFFID+1, 7, 26496, 'SPAWN'),
(35186, @SNIFFID+1, 7, 139852, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171537, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171539, 'SPAWN'),
(35186, @SNIFFID+1, 6, 2790, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171764, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171614, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171613, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171612, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171538, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143319, 'SPAWN'),
(35186, @SNIFFID+1, 6, 8879, 'SPAWN'),
(35186, @SNIFFID+1, 6, 2784, 'SPAWN'),
(35186, @SNIFFID+1, 6, 1274, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171758, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171757, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5049, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171618, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171617, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171616, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171615, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143322, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143318, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5101, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5130, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171611, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171610, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171609, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171582, 'SPAWN'),
(35186, @SNIFFID+1, 7, 149413, 'SPAWN'),
(35186, @SNIFFID+1, 2, 23221, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 7, 171580, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171608, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171581, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171583, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171633, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180397, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180400, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143320, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15102, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171587, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171586, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5132, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5100, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5099, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143326, 'SPAWN'),
(35186, @SNIFFID+1, 6, 2461, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171584, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171588, 'SPAWN'),
(35186, @SNIFFID+1, 2, 1953, 'CAST'),
(35186, @SNIFFID+1, 2, 1953, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13587, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21926, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7598, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 29094, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23560, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23794, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13824, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 22780, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21432, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 29413, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19511, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24691, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19490, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19500, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19423, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19431, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19420, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19602, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19620, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19587, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19556, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20583, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20582, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21009, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13358, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24949, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24497, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 4190, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24445, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24555, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20784, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20782, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19591, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19589, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19582, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19581, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19580, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17210, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 8875, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9416, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18384, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23549, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19988, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14047, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18382, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9346, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14248, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21879, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 22843, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17367, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21619, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23729, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17493, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18056, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 29076, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13927, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14799, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13825, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21362, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14254, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24156, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18054, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19992, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23727, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18050, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12351, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12518, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12350, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12848, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12341, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12571, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12490, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 16758, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12985, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12953, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15053, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12475, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 16763, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 28332, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 1244, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 2383, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9417, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9345, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9413, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18013, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15714, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17900, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18018, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18011, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18825, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18743, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18701, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18710, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18750, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17786, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18704, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18696, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17808, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18219, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18693, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18095, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18830, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18183, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17814, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 30796, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9103, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9098, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14161, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13964, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18429, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13856, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9412, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9328, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9262, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9260, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14794, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7215, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18016, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9325, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18008, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9342, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18127, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18134, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17792, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17803, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18275, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18181, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18178, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20599, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20597, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20598, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20864, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 5784, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 2580, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 22912, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13675, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14249, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21363, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13390, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7494, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7490, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9334, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9117, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9099, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7517, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12811, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 16542, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12302, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12945, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12764, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12818, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12753, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12727, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12856, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12296, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12679, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 16466, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 5301, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21156, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 22818, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 22817, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 22820, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 6898, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 2457, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 7, 171585, 'SPAWN'),
(35186, @SNIFFID+1, 6, 7434, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143321, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171634, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5103, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5102, 'SPAWN'),
(35186, @SNIFFID+1, 7, 144159, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143325, 'SPAWN'),
(35186, @SNIFFID+1, 7, 32431, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171524, 'SPAWN'),
(35186, @SNIFFID+1, 7, 137646, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143324, 'SPAWN'),
(35186, @SNIFFID+1, 7, 32427, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143323, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5109, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180802, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180803, 'SPAWN'),
(35186, @SNIFFID+1, 2, 9343, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14626, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14635, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 29091, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18378, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 5707, 'AURA_UPDATE');

INSERT IGNORE INTO `sniff_data` (`sniff_build`, `sniff_id`, `object_type`, `id`, `data`) VALUES
(35186, @SNIFFID+1, 2, 12489, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 28595, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12519, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12577, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 29447, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12592, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12840, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12488, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 16766, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17454, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19984, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15396, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14027, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13828, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15813, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15600, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15465, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 16494, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12867, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12290, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12659, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12663, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12974, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13048, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20503, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23588, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12861, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13002, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23228, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21564, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18030, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7500, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7497, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7501, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7496, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9344, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15354, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15338, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15018, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15031, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20711, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 27790, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15014, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14892, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18535, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17191, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15011, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 10156, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 2791, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7477, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18950, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7478, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7472, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14824, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9100, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7470, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19415, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 1494, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7576, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21881, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9329, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14137, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 7, 180801, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180806, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180800, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180807, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180679, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171636, 'SPAWN'),
(35186, @SNIFFID+1, 6, 2460, 'SPAWN'),
(35186, @SNIFFID+1, 7, 176573, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171698, 'SPAWN'),
(35186, @SNIFFID+1, 7, 176628, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171699, 'SPAWN'),
(35186, @SNIFFID+1, 7, 176629, 'SPAWN'),
(35186, @SNIFFID+1, 6, 9859, 'SPAWN'),
(35186, @SNIFFID+1, 7, 176627, 'SPAWN'),
(35186, @SNIFFID+1, 6, 14365, 'SPAWN'),
(35186, @SNIFFID+1, 6, 1201, 'SPAWN'),
(35186, @SNIFFID+1, 2, 21092, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9408, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21973, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9315, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23796, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9314, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21624, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 22748, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23264, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23236, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21894, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14585, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9415, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24158, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18034, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18032, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18033, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15403, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21364, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9406, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21626, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21618, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9318, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15326, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 27816, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 27904, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15012, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18555, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14772, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14771, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14783, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14749, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14777, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14774, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14769, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14791, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 26013, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14054, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18020, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18052, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9396, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15715, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19985, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13827, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18055, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18014, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24157, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21347, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18175, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18744, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18751, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18707, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17959, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18136, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17918, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 11735, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 29626, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7508, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7493, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9115, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9114, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14164, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13791, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14173, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14095, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13980, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14064, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14066, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13973, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17866, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9395, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12469, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 28574, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 29440, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 10220, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 10157, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9110, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9105, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9106, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 29090, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12353, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12501, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12605, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18464, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 29446, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9324, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7503, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17779, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 30795, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7491, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14827, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19625, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19590, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19578, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19572, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19552, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24443, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19612, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21625, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21361, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18057, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17747, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13881, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23798, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14558, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14127, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12575, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9304, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 30777, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13368, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12473, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 11180, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24198, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17670, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18031, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7479, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15363, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15356, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14911, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 27900, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 10937, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14406, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13599, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 11207, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12982, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 29439, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 10957, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7302, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 8451, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 1461, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21958, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9112, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9108, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9111, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7476, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7495, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7499, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9113, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9263, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14405, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14784, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14767, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9101, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14158, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14165, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14140, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14148, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18427, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 6777, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 2479, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 6, 8720, 'SPAWN'),
(35186, @SNIFFID+1, 7, 176924, 'SPAWN'),
(35186, @SNIFFID+1, 7, 176624, 'SPAWN'),
(35186, @SNIFFID+1, 7, 26499, 'SPAWN'),
(35186, @SNIFFID+1, 6, 7292, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171635, 'SPAWN'),
(35186, @SNIFFID+1, 2, 465, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21596, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20969, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18372, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17787, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18393, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 11734, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18742, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18735, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18727, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 6, 13843, 'SPAWN'),
(35186, @SNIFFID+1, 6, 14363, 'SPAWN'),
(35186, @SNIFFID+1, 6, 1860, 'SPAWN'),
(35186, @SNIFFID+1, 2, 23510, 'CAST'),
(35186, @SNIFFID+1, 2, 23510, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18046, 'AURA_UPDATE');

INSERT IGNORE INTO `sniff_data` (`sniff_build`, `sniff_id`, `object_type`, `id`, `data`) VALUES
(35186, @SNIFFID+1, 2, 24151, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17371, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21365, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18041, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18038, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23728, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15696, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18039, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20245, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20147, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20489, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20150, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20175, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20137, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 25829, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 25836, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20215, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20235, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20239, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20208, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20261, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19900, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23578, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21928, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23559, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21440, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15829, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21445, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 29414, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24295, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19422, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19599, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21850, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 27681, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20906, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14322, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 6, 8671, 'SPAWN'),
(35186, @SNIFFID+1, 7, 176625, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171696, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171762, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171761, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171697, 'SPAWN'),
(35186, @SNIFFID+1, 2, 8114, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13674, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13385, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13665, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23563, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18185, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13387, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21969, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15393, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13670, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9332, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 22852, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15438, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12312, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12664, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12765, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 16624, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13388, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9121, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9118, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13383, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13386, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7502, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7518, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18196, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12792, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12855, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12857, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12879, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12838, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12803, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7376, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 71, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9107, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7466, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9119, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9104, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 11100, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12400, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18460, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 11368, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12598, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12841, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12873, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12360, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9265, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9261, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7504, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7506, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7505, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9264, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 7, 176626, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5107, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5106, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5108, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171704, 'SPAWN'),
(35186, @SNIFFID+1, 2, 9335, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21439, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24154, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24283, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19245, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19232, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19160, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19387, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19153, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19417, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19553, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 10938, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 7, 171702, 'SPAWN'),
(35186, @SNIFFID+1, 15, 345, '5111'),
(35186, @SNIFFID+1, 7, 171661, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171660, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171543, 'SPAWN'),
(35186, @SNIFFID+1, 2, 10937, 'CAST'),
(35186, @SNIFFID+1, 7, 171547, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171546, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5111, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5112, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171692, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171572, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171571, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171545, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171544, 'SPAWN'),
(35186, @SNIFFID+1, 2, 7681, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9120, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9122, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9142, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9398, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20142, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9453, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 1032, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14052, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15807, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19287, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19258, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19297, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 5118, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19879, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 6, 14183, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171579, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171578, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171577, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171576, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171575, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171574, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171573, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171570, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171569, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5110, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171694, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171693, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171649, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171648, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143317, 'SPAWN'),
(35186, @SNIFFID+1, 7, 32349, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143253, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171700, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171695, 'SPAWN'),
(35186, @SNIFFID+1, 7, 142838, 'SPAWN'),
(35186, @SNIFFID+1, 7, 137644, 'SPAWN'),
(35186, @SNIFFID+1, 7, 32424, 'SPAWN'),
(35186, @SNIFFID+1, 7, 149418, 'SPAWN'),
(35186, @SNIFFID+1, 2, 836, 'CAST'),
(35186, @SNIFFID+1, 6, 6175, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171701, 'SPAWN'),
(35186, @SNIFFID+1, 7, 32385, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171703, 'SPAWN'),
(35186, @SNIFFID+1, 2, 15810, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23300, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 18379, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15388, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14467, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23302, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21142, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20059, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20113, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 26021, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 26023, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20121, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20062, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 25957, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20105, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20266, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20218, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17229, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9316, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23043, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14770, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 10952, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19596, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 29096, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14330, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 31726, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 8394, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13690, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23181, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 21485, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7516, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9397, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23591, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23565, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24196, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20234, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20182, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20200, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20470, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20193, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20332, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 25780, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 10301, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23214, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 11185, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15047, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 16765, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12497, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 7, 180728, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171657, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171656, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171655, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171654, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171653, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171652, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171540, 'SPAWN'),
(35186, @SNIFFID+1, 6, 7298, 'SPAWN'),
(35186, @SNIFFID+1, 6, 10090, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171658, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171536, 'SPAWN'),
(35186, @SNIFFID+1, 6, 1901, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171659, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171638, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171651, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171535, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171650, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5125, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5129, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5114, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5126, 'SPAWN'),
(35186, @SNIFFID+1, 6, 13084, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171558, 'SPAWN'),
(35186, @SNIFFID+1, 6, 11865, 'SPAWN'),
(35186, @SNIFFID+1, 6, 7976, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5121, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5120, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5119, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143249, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143254, 'SPAWN'),
(35186, @SNIFFID+1, 15, 6772, '15701'),
(35186, @SNIFFID+1, 15, 6771, '15701');

INSERT IGNORE INTO `sniff_data` (`sniff_build`, `sniff_id`, `object_type`, `id`, `data`) VALUES
(35186, @SNIFFID+1, 6, 5150, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5138, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5137, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171747, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171746, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171738, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15451, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15453, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15452, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171557, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171559, 'SPAWN'),
(35186, @SNIFFID+1, 2, 2983, 'CAST'),
(35186, @SNIFFID+1, 2, 2983, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 6, 15663, 'SPAWN'),
(35186, @SNIFFID+1, 6, 7944, 'SPAWN'),
(35186, @SNIFFID+1, 6, 6569, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5569, 'SPAWN'),
(35186, @SNIFFID+1, 6, 4081, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171754, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171750, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171749, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171753, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171748, 'SPAWN'),
(35186, @SNIFFID+1, 6, 1246, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5177, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5178, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5123, 'SPAWN'),
(35186, @SNIFFID+1, 7, 149412, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143250, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5115, 'SPAWN'),
(35186, @SNIFFID+1, 6, 6114, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5113, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171641, 'SPAWN'),
(35186, @SNIFFID+1, 2, 9330, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 30771, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13832, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14083, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14081, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24456, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24428, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13384, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12860, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 6, 15351, 'SPAWN'),
(35186, @SNIFFID+1, 6, 12197, 'SPAWN'),
(35186, @SNIFFID+1, 6, 14982, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171643, 'SPAWN'),
(35186, @SNIFFID+1, 2, 14135, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14169, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23028, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 22723, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23223, 'CAST'),
(35186, @SNIFFID+1, 2, 23223, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 15987, 'CAST'),
(35186, @SNIFFID+1, 2, 15986, 'CAST'),
(35186, @SNIFFID+1, 2, 458, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 6, 857, 'SPAWN'),
(35186, @SNIFFID+1, 2, 9305, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17897, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17873, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 9298, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 17878, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12569, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 28594, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 12574, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13033, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 15, 6805, '15734'),
(35186, @SNIFFID+1, 2, 14798, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 467, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 5232, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 22783, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 22888, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7469, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 16936, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 673, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 3219, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 15, 6702, '15431'),
(35186, @SNIFFID+1, 15, 6602, '15431'),
(35186, @SNIFFID+1, 7, 171639, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5116, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5570, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5122, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171667, 'SPAWN'),
(35186, @SNIFFID+1, 7, 142915, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171668, 'SPAWN'),
(35186, @SNIFFID+1, 7, 142916, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171670, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5140, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5117, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171666, 'SPAWN'),
(35186, @SNIFFID+1, 7, 142914, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5605, 'SPAWN'),
(35186, @SNIFFID+1, 6, 9984, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171669, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171671, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171672, 'SPAWN'),
(35186, @SNIFFID+1, 7, 142911, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171673, 'SPAWN'),
(35186, @SNIFFID+1, 7, 142912, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171554, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15437, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15457, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171664, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171665, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15456, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171556, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15455, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143251, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15434, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171555, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15445, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143255, 'SPAWN'),
(35186, @SNIFFID+1, 6, 5124, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15431, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171553, 'SPAWN'),
(35186, @SNIFFID+1, 15, 6610, '15451'),
(35186, @SNIFFID+1, 6, 15701, 'SPAWN'),
(35186, @SNIFFID+1, 15, 6613, '15453'),
(35186, @SNIFFID+1, 15, 6720, '15453'),
(35186, @SNIFFID+1, 13, 7994, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 15, 6612, '15452'),
(35186, @SNIFFID+1, 15, 6718, '15452'),
(35186, @SNIFFID+1, 13, 7991, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 15, 6716, '15451'),
(35186, @SNIFFID+1, 13, 7988, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 15, 6607, '15446'),
(35186, @SNIFFID+1, 15, 6696, '15446'),
(35186, @SNIFFID+1, 13, 7971, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 15, 6608, '15448'),
(35186, @SNIFFID+1, 15, 6712, '15448'),
(35186, @SNIFFID+1, 13, 7981, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 15, 6609, '15450'),
(35186, @SNIFFID+1, 15, 6714, '15450'),
(35186, @SNIFFID+1, 13, 7984, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 13, 8129, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 2, 20049, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 25988, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 23686, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13928, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20063, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20048, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 20149, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 27841, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 15, 6806, '15735'),
(35186, @SNIFFID+1, 15, 6603, '15432'),
(35186, @SNIFFID+1, 15, 6704, '15432'),
(35186, @SNIFFID+1, 7, 171737, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171736, 'SPAWN'),
(35186, @SNIFFID+1, 7, 143336, 'SPAWN'),
(35186, @SNIFFID+1, 15, 6665, '15539'),
(35186, @SNIFFID+1, 15, 6671, '15539'),
(35186, @SNIFFID+1, 7, 171642, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171640, 'SPAWN'),
(35186, @SNIFFID+1, 15, 6803, '15731'),
(35186, @SNIFFID+1, 2, 14462, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7498, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7473, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 29416, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19621, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19560, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19575, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 19885, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24447, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24439, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24552, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 4191, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24488, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24492, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 24493, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 6, 2043, 'SPAWN'),
(35186, @SNIFFID+1, 7, 32429, 'SPAWN'),
(35186, @SNIFFID+1, 7, 32404, 'SPAWN'),
(35186, @SNIFFID+1, 13, 8126, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 2, 17265, 'CAST'),
(35186, @SNIFFID+1, 2, 7455, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 7419, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13851, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 13, 8130, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 13, 7962, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 15, 6599, '15383'),
(35186, @SNIFFID+1, 2, 7684, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 15, 6700, '15383'),
(35186, @SNIFFID+1, 13, 7958, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 13, 7960, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 6, 15446, 'SPAWN'),
(35186, @SNIFFID+1, 2, 14334, 'CAST'),
(35186, @SNIFFID+1, 15, 6604, '15434'),
(35186, @SNIFFID+1, 15, 6706, '15434'),
(35186, @SNIFFID+1, 13, 7964, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 15, 6606, '15445'),
(35186, @SNIFFID+1, 15, 6710, '15445'),
(35186, @SNIFFID+1, 13, 7969, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 15, 6605, '15437'),
(35186, @SNIFFID+1, 15, 6708, '15437'),
(35186, @SNIFFID+1, 13, 7967, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 15, 6726, '15457'),
(35186, @SNIFFID+1, 15, 6616, '15457'),
(35186, @SNIFFID+1, 13, 8003, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 15, 6615, '15456'),
(35186, @SNIFFID+1, 13, 8070, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 15, 6724, '15456'),
(35186, @SNIFFID+1, 13, 8000, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 15, 6614, '15455'),
(35186, @SNIFFID+1, 13, 8072, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 15, 6722, '15455'),
(35186, @SNIFFID+1, 13, 7997, 'QUERY_RESPONSE'),
(35186, @SNIFFID+1, 2, 7509, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 13819, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 6, 7950, 'SPAWN'),
(35186, @SNIFFID+1, 6, 7937, 'SPAWN'),
(35186, @SNIFFID+1, 7, 1685, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171752, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171751, 'SPAWN'),
(35186, @SNIFFID+1, 2, 17551, 'CAST'),
(35186, @SNIFFID+1, 3, 0, 'LOAD_SCREEN'),
(35186, @SNIFFID+1, 7, 180714, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180676, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180675, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180598, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180674, 'SPAWN'),
(35186, @SNIFFID+1, 7, 142851, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15448, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15450, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171526, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171525, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171527, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180694, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180681, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180693, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180692, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15733, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15734, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15539, 'SPAWN'),
(35186, @SNIFFID+1, 7, 171552, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15731, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15735, 'SPAWN'),
(35186, @SNIFFID+1, 6, 2695, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15432, 'SPAWN'),
(35186, @SNIFFID+1, 6, 15383, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180782, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180781, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180780, 'SPAWN'),
(35186, @SNIFFID+1, 7, 180680, 'SPAWN'),
(35186, @SNIFFID+1, 2, 24465, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14384, 'AURA_UPDATE'),
(35186, @SNIFFID+1, 2, 14097, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23798, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13827, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9118, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9108, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9264, 'AURA_UPDATE');

INSERT IGNORE INTO `sniff_data` (`sniff_build`, `sniff_id`, `object_type`, `id`, `data`) VALUES
(35186, @SNIFFID+2, 2, 9260, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13862, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7504, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7496, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9115, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9104, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13370, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9117, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9106, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7702, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15053, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12592, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12985, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12490, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12519, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16758, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12953, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12475, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12488, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12571, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29440, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16766, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20555, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20557, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20558, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23301, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 26290, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 8395, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 10156, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 2383, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 27841, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 10938, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 176519, 'SPAWN'),
(35186, @SNIFFID+2, 7, 176517, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15105, 'SPAWN'),
(35186, @SNIFFID+2, 7, 176516, 'SPAWN'),
(35186, @SNIFFID+2, 2, 9331, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7597, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15464, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23559, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21928, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23794, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15829, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23560, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29413, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13823, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24154, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21432, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7598, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13735, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13364, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19600, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19560, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19511, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19422, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24691, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19490, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19500, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19431, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19420, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19620, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19612, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19575, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19587, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20573, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20574, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20576, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13358, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24949, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20906, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21850, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9408, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9318, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21363, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19988, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18037, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24158, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18384, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18046, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13889, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18039, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17371, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9315, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18030, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13927, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9316, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22748, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23264, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23236, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18034, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18033, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19992, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21626, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23796, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21894, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23688, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14908, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15363, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15014, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18535, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15012, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15011, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14770, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14772, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18555, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14783, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14523, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14777, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14769, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14767, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14791, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23028, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 10929, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 176518, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15515, 'SPAWN'),
(35186, @SNIFFID+2, 15, 6663, '15534'),
(35186, @SNIFFID+2, 6, 15532, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15696, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15529, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15525, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15522, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15528, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3349, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173159, 'SPAWN'),
(35186, @SNIFFID+2, 15, 6778, '15700'),
(35186, @SNIFFID+2, 2, 7517, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22738, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13828, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22778, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14049, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13675, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19984, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15465, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15600, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7516, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16494, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12867, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12296, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12679, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12659, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12664, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12974, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13048, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20503, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23588, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12861, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13002, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12856, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21563, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 5301, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7381, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22888, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 2458, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 10880, 'SPAWN'),
(35186, @SNIFFID+2, 15, 6807, '15737'),
(35186, @SNIFFID+2, 15, 6758, '15535'),
(35186, @SNIFFID+2, 13, 8052, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6664, '15535'),
(35186, @SNIFFID+2, 15, 6756, '15534'),
(35186, @SNIFFID+2, 13, 8049, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 1951, '3296'),
(35186, @SNIFFID+2, 6, 3296, 'SPAWN'),
(35186, @SNIFFID+2, 2, 18052, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18013, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21599, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14047, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9417, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14054, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23727, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18055, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18382, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14055, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14248, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9396, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9346, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21347, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9345, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18020, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 25113, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22747, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18056, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13881, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17959, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17929, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17918, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18134, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17792, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17803, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18748, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18710, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18756, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18707, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18693, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18696, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18701, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18183, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17814, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18175, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 5227, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20579, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 30795, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 8220, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 2580, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11735, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18791, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 13, 8133, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6810, '15738'),
(35186, @SNIFFID+2, 6, 5910, 'SPAWN'),
(35186, @SNIFFID+2, 15, 6619, '15460'),
(35186, @SNIFFID+2, 13, 8013, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 13, 8016, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6624, '15469'),
(35186, @SNIFFID+2, 2, 7465, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7477, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13705, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7478, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7471, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13789, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7468, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13863, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13792, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16092, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21184, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7475, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16936, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16814, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16858, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20550, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20551, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20552, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 467, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 5232, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 7567, 'SPAWN'),
(35186, @SNIFFID+2, 15, 6729, '15459'),
(35186, @SNIFFID+2, 15, 6618, '15459'),
(35186, @SNIFFID+2, 13, 8010, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6678, '15458'),
(35186, @SNIFFID+2, 15, 6809, '15739'),
(35186, @SNIFFID+2, 13, 8019, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6625, '15477'),
(35186, @SNIFFID+2, 13, 8022, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6651, '15508'),
(35186, @SNIFFID+2, 15, 6740, '15512'),
(35186, @SNIFFID+2, 15, 6653, '15512'),
(35186, @SNIFFID+2, 13, 8025, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 7, 176521, 'SPAWN'),
(35186, @SNIFFID+2, 7, 176520, 'SPAWN'),
(35186, @SNIFFID+2, 2, 18950, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 14376, 'SPAWN'),
(35186, @SNIFFID+2, 15, 6759, '15458');

INSERT IGNORE INTO `sniff_data` (`sniff_build`, `sniff_id`, `object_type`, `id`, `data`) VALUES
(35186, @SNIFFID+2, 13, 8055, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 13, 8127, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 18050, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17900, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14127, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15715, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23549, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24156, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14798, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14799, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21879, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13825, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21362, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14254, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21619, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9304, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17367, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13824, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12489, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12487, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 28595, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18464, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29441, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12469, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 28574, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12577, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12840, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 177015, 'SPAWN'),
(35186, @SNIFFID+2, 13, 8131, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6808, '15736'),
(35186, @SNIFFID+2, 13, 8073, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6748, '15528'),
(35186, @SNIFFID+2, 13, 8037, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6659, '15528'),
(35186, @SNIFFID+2, 15, 6660, '15529'),
(35186, @SNIFFID+2, 15, 6750, '15529'),
(35186, @SNIFFID+2, 13, 8040, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6661, '15532'),
(35186, @SNIFFID+2, 15, 6752, '15532'),
(35186, @SNIFFID+2, 13, 8043, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 23048, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23049, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15806, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9336, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14467, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9329, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13670, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20885, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9330, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14027, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14089, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16513, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14179, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14137, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14159, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14161, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14142, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14164, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 30895, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14083, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14173, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14095, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13980, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14065, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14066, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13973, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 1860, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 2836, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 15460, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15533, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15738, 'SPAWN'),
(35186, @SNIFFID+2, 15, 6779, '15700'),
(35186, @SNIFFID+2, 2, 3563, 'CAST'),
(35186, @SNIFFID+2, 2, 2479, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19985, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9343, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21620, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23025, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9344, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23037, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19990, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 28332, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12576, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29447, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17465, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22783, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 10157, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 173162, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3373, 'SPAWN'),
(35186, @SNIFFID+2, 13, 8094, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6656, '15522'),
(35186, @SNIFFID+2, 15, 6744, '15522'),
(35186, @SNIFFID+2, 13, 8031, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 13, 8034, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6657, '15525'),
(35186, @SNIFFID+2, 7, 179742, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15533, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 14376, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15535, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15460, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15738, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15535, 'SPAWN'),
(35186, @SNIFFID+2, 13, 8074, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6742, '15515'),
(35186, @SNIFFID+2, 13, 8028, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6654, '15515'),
(35186, @SNIFFID+2, 6, 15534, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15534, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15469, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3373, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15469, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15459, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15737, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3349, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15459, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15737, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177014, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15458, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15458, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173157, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15532, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15529, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15528, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15736, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15512, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15739, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15736, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15512, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15739, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15700, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15700, 'SPAWN'),
(35186, @SNIFFID+2, 2, 18032, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15696, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21853, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18029, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21365, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18041, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21364, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9406, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21618, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15356, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15031, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17191, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 15508, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15477, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15522, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15508, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15477, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173161, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173160, 'SPAWN'),
(35186, @SNIFFID+2, 2, 13390, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7470, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7509, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7505, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7506, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7473, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12834, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12677, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12697, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16463, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21156, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 2457, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 8404, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 8404, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15525, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15696, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15515, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 7562, 'SPAWN'),
(35186, @SNIFFID+2, 6, 7565, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177016, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172997, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172996, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172971, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172970, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173207, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177026, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173224, 'SPAWN'),
(35186, @SNIFFID+2, 2, 22721, 'CAST'),
(35186, @SNIFFID+2, 2, 22721, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 7562, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 14375, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173215, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173205, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173106, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173220, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3370, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3314, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5188, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3370, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15188, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173219, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173113, 'SPAWN'),
(35186, @SNIFFID+2, 2, 18054, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23729, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23728, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7687, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12400, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11368, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12873, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29076, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12351, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12350, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18460, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12353, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12848, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12341, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21564, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 175885, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173208, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173217, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173164, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173111, 'SPAWN'),
(35186, @SNIFFID+2, 2, 17493, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9414, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24157, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9416, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17778, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17927, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23825, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18750, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18773, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18744, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 173109, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3312, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173107, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180394, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177021, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173210, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173214, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173209, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173108, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173110, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173125, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177022, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173211, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173212, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173213, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172966, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177023, 'SPAWN'),
(35186, @SNIFFID+2, 2, 15396, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9333, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12290, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12663, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24425, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24382, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 12799, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 13669, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14121, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13665, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21881, 'AURA_UPDATE');

INSERT IGNORE INTO `sniff_data` (`sniff_build`, `sniff_id`, `object_type`, `id`, `data`) VALUES
(35186, @SNIFFID+2, 2, 15401, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9332, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23558, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7219, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24153, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18429, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 30920, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13964, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13852, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13872, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13875, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13845, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13712, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14167, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 3223, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7472, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7479, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16287, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16305, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16301, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16612, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17013, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9139, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7469, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7503, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7498, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13849, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13866, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 8094, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 3222, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 8115, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 12799, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3310, 'SPAWN'),
(35186, @SNIFFID+2, 7, 179741, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3331, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3323, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173006, 'SPAWN'),
(35186, @SNIFFID+2, 7, 179740, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172974, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172973, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172972, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172969, 'SPAWN'),
(35186, @SNIFFID+2, 7, 179739, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172968, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173117, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173116, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5910, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 1781, 'CAST'),
(35186, @SNIFFID+2, 7, 173007, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173102, 'SPAWN'),
(35186, @SNIFFID+2, 6, 10880, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 7, 177002, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173101, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3328, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173168, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173166, 'SPAWN'),
(35186, @SNIFFID+2, 2, 23581, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14056, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15814, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24434, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14113, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22722, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 16012, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3342, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3401, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 6446, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 16012, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3342, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173062, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173025, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172995, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172994, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172993, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172977, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172976, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172975, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3401, 'SPAWN'),
(35186, @SNIFFID+2, 6, 6446, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173170, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173163, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3402, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 14304, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173130, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3402, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173132, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173131, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3327, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 7, 173146, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173136, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3327, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173167, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173145, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173175, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3334, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3334, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173169, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173165, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173144, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173143, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173177, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5816, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 7, 173142, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173139, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5816, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5892, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3403, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3330, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 7, 180830, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180829, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180828, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180827, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180826, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5892, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3403, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173138, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173137, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3330, 'SPAWN'),
(35186, @SNIFFID+2, 6, 4047, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3344, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 13417, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 4047, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3344, 'SPAWN'),
(35186, @SNIFFID+2, 6, 13417, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173141, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173140, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173172, 'SPAWN'),
(35186, @SNIFFID+2, 6, 14304, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 7, 180836, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180835, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180834, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180833, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180832, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177005, 'SPAWN'),
(35186, @SNIFFID+2, 7, 175316, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173173, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15765, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 5909, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3324, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 5815, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3335, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3325, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 7, 180816, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180815, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180814, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180813, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180812, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15765, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177004, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173058, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173057, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172981, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172980, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172979, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172978, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5909, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3324, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5815, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3335, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3325, 'SPAWN'),
(35186, @SNIFFID+2, 7, 175319, 'SPAWN'),
(35186, @SNIFFID+2, 2, 17465, 'CAST'),
(35186, @SNIFFID+2, 7, 173061, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173059, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5875, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 5875, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3351, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3350, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3326, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 7, 180822, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180821, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180820, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180819, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180818, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3351, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3350, 'SPAWN'),
(35186, @SNIFFID+2, 7, 175658, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173060, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173056, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3326, 'SPAWN'),
(35186, @SNIFFID+2, 7, 175312, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15761, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15761, 'SPAWN'),
(35186, @SNIFFID+2, 7, 175314, 'SPAWN'),
(35186, @SNIFFID+2, 2, 15810, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7576, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13807, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14136, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14075, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7466, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29418, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19454, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19423, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19427, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19418, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19412, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14318, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 836, 'CAST'),
(35186, @SNIFFID+2, 7, 180842, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180841, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180840, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180839, 'SPAWN'),
(35186, @SNIFFID+2, 7, 180838, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177003, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172950, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172956, 'SPAWN'),
(35186, @SNIFFID+2, 6, 4949, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173104, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173048, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173022, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172951, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172944, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173103, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3367, 'SPAWN'),
(35186, @SNIFFID+2, 6, 11066, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3346, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3345, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172947, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3372, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173037, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173036, 'SPAWN'),
(35186, @SNIFFID+2, 6, 11046, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 11046, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173050, 'SPAWN'),
(35186, @SNIFFID+2, 6, 7010, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3371, 'SPAWN'),
(35186, @SNIFFID+2, 6, 8659, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3405, 'SPAWN'),
(35186, @SNIFFID+2, 6, 8659, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173105, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173020, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172949, 'SPAWN'),
(35186, @SNIFFID+2, 2, 7491, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14462, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13587, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9119, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9102, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9101, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9100, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 30892, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14071, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 30906, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14081, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13976, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17463, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 3348, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3404, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173053, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173052, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173051, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173049, 'SPAWN');

INSERT IGNORE INTO `sniff_data` (`sniff_build`, `sniff_id`, `object_type`, `id`, `data`) VALUES
(35186, @SNIFFID+2, 7, 172948, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172946, 'SPAWN'),
(35186, @SNIFFID+2, 6, 2855, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173033, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173018, 'SPAWN'),
(35186, @SNIFFID+2, 2, 26341, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 14720, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3347, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173031, 'SPAWN'),
(35186, @SNIFFID+2, 2, 9397, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17890, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13831, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18462, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 10174, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 10220, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 172991, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172990, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172989, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172988, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172987, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173021, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173086, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173023, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173024, 'SPAWN'),
(35186, @SNIFFID+2, 6, 6986, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173054, 'SPAWN'),
(35186, @SNIFFID+2, 6, 6987, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173055, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172955, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3363, 'SPAWN'),
(35186, @SNIFFID+2, 6, 14392, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172986, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172985, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172984, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172983, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172982, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173044, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173043, 'SPAWN'),
(35186, @SNIFFID+2, 2, 28857, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24461, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15388, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9415, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22801, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24155, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17997, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22804, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9342, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23516, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16221, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16181, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16198, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16189, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16225, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16217, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16582, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16108, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16089, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29000, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29065, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16544, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16120, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16164, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16161, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16110, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20608, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22724, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 173047, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173046, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173045, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3316, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5811, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3365, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3366, 'SPAWN'),
(35186, @SNIFFID+2, 6, 7088, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173035, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173034, 'SPAWN'),
(35186, @SNIFFID+2, 2, 2657, 'CAST'),
(35186, @SNIFFID+2, 7, 173038, 'SPAWN'),
(35186, @SNIFFID+2, 2, 9400, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11124, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12342, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12360, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12605, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12598, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12842, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 14377, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173042, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173041, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173040, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173039, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3359, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173088, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173087, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173080, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173079, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173077, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173076, 'SPAWN'),
(35186, @SNIFFID+2, 2, 21926, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9335, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21445, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19602, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19585, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19556, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14322, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13979, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 30903, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 30894, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14094, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14062, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14156, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12497, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15813, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24456, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12860, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12838, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12668, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12704, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12713, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12963, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23509, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18035, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21625, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23044, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23043, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19986, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9314, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21624, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14774, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15017, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 27816, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14771, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 177008, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172992, 'SPAWN'),
(35186, @SNIFFID+2, 6, 4485, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177009, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173084, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173075, 'SPAWN'),
(35186, @SNIFFID+2, 2, 26283, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22007, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11190, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12399, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16757, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12984, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11185, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11078, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 173069, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177012, 'SPAWN'),
(35186, @SNIFFID+2, 6, 12353, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 14540, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 10088, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 12353, 'SPAWN'),
(35186, @SNIFFID+2, 6, 14540, 'SPAWN'),
(35186, @SNIFFID+2, 6, 10088, 'SPAWN'),
(35186, @SNIFFID+2, 6, 14541, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 12351, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3362, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 14541, 'SPAWN'),
(35186, @SNIFFID+2, 6, 12351, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3362, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5195, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 14539, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 4752, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 5195, 'SPAWN'),
(35186, @SNIFFID+2, 6, 14539, 'SPAWN'),
(35186, @SNIFFID+2, 6, 4752, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173194, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173184, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3352, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3352, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173178, 'SPAWN'),
(35186, @SNIFFID+2, 6, 11178, 'SPAWN'),
(35186, @SNIFFID+2, 6, 7790, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173179, 'SPAWN'),
(35186, @SNIFFID+2, 7, 35591, 'SPAWN'),
(35186, @SNIFFID+2, 2, 7731, 'CAST'),
(35186, @SNIFFID+2, 6, 3406, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3407, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 7294, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 9988, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3406, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3407, 'SPAWN'),
(35186, @SNIFFID+2, 6, 7294, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177013, 'SPAWN'),
(35186, @SNIFFID+2, 6, 9988, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177011, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177007, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177006, 'SPAWN'),
(35186, @SNIFFID+2, 2, 2983, 'CAST'),
(35186, @SNIFFID+2, 2, 2983, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23243, 'CAST'),
(35186, @SNIFFID+2, 2, 23243, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 173085, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173074, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173067, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173072, 'SPAWN'),
(35186, @SNIFFID+2, 2, 3317, 'CAST'),
(35186, @SNIFFID+2, 2, 16342, 'CAST'),
(35186, @SNIFFID+2, 7, 177010, 'SPAWN'),
(35186, @SNIFFID+2, 6, 14499, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173100, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173099, 'SPAWN'),
(35186, @SNIFFID+2, 6, 14498, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173071, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173068, 'SPAWN'),
(35186, @SNIFFID+2, 6, 14451, 'SPAWN'),
(35186, @SNIFFID+2, 6, 14182, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3332, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3333, 'SPAWN'),
(35186, @SNIFFID+2, 6, 14182, 'SPAWN'),
(35186, @SNIFFID+2, 2, 9142, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7476, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21345, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19464, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19421, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14320, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 8083, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7419, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12672, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12473, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 2659, 'CAST'),
(35186, @SNIFFID+2, 2, 3304, 'CAST'),
(35186, @SNIFFID+2, 2, 21927, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29637, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21352, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9132, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7495, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7492, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9098, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14330, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19430, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19625, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19578, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19596, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16609, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 173063, 'SPAWN'),
(35186, @SNIFFID+2, 2, 24965, 'CAST'),
(35186, @SNIFFID+2, 2, 10097, 'CAST'),
(35186, @SNIFFID+2, 7, 173096, 'SPAWN'),
(35186, @SNIFFID+2, 2, 22718, 'CAST'),
(35186, @SNIFFID+2, 2, 22718, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 5812, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3355, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 5812, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3355, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173095, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173094, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173083, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3356, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3356, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173073, 'SPAWN');

INSERT IGNORE INTO `sniff_data` (`sniff_build`, `sniff_id`, `object_type`, `id`, `data`) VALUES
(35186, @SNIFFID+2, 6, 7790, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 7230, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 10266, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 7792, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 7793, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 7230, 'SPAWN'),
(35186, @SNIFFID+2, 6, 10266, 'SPAWN'),
(35186, @SNIFFID+2, 6, 7792, 'SPAWN'),
(35186, @SNIFFID+2, 6, 7793, 'SPAWN'),
(35186, @SNIFFID+2, 2, 22843, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21361, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18799, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9308, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12952, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12606, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16770, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24388, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13033, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9122, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9140, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9267, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7507, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12999, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16464, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12785, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12714, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23578, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29414, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19599, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24295, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 8178, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24504, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24445, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20784, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20782, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19591, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19589, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19582, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19581, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19580, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17222, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 8875, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 11357, 'SPAWN'),
(35186, @SNIFFID+2, 2, 22724, 'CAST'),
(35186, @SNIFFID+2, 6, 1383, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 11176, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 1383, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173065, 'SPAWN'),
(35186, @SNIFFID+2, 6, 11176, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173066, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173064, 'SPAWN'),
(35186, @SNIFFID+2, 6, 11177, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 11178, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 11177, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3354, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 15350, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3408, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 23557, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23732, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18379, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13383, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17113, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24946, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24972, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17108, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17082, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17073, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17061, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16931, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16941, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16862, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16835, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17249, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 10958, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 27681, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9910, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13385, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16492, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12318, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23695, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12815, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12712, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 173089, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3354, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15350, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3408, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173119, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15006, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3353, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 14498, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3890, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 9317, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 2857, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3410, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 14942, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 11017, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3412, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3413, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 9360, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9358, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16235, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16223, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16229, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16115, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16160, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 28998, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 25669, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7215, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21895, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23572, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21899, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29202, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16234, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16240, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16213, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16293, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17489, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16208, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13198, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23217, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17007, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24894, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16999, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16975, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16938, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16906, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9885, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13372, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19991, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13796, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24429, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17896, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 173118, 'SPAWN'),
(35186, @SNIFFID+2, 6, 15006, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173120, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3353, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173092, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173121, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3890, 'SPAWN'),
(35186, @SNIFFID+2, 2, 15714, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12983, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12841, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21838, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13676, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23562, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12811, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12945, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12762, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12818, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12727, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20496, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7497, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21627, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9317, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18036, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16209, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18549, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14531, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 26013, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24148, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18740, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18737, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18728, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11767, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 4511, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9327, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9326, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18008, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7709, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18127, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18275, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18310, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18219, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18178, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18095, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17787, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11734, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 30794, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 9317, 'SPAWN'),
(35186, @SNIFFID+2, 6, 2857, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173070, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173090, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3410, 'SPAWN'),
(35186, @SNIFFID+2, 6, 14942, 'SPAWN'),
(35186, @SNIFFID+2, 6, 416, 'SPAWN'),
(35186, @SNIFFID+2, 6, 11017, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173123, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3412, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173122, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3413, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173082, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173093, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173091, 'SPAWN'),
(35186, @SNIFFID+2, 2, 9114, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23265, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15334, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15314, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15330, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15326, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23990, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21641, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29439, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 14499, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3357, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 14451, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3357, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3358, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3358, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173081, 'SPAWN'),
(35186, @SNIFFID+2, 6, 4485, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3332, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3333, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3359, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 22734, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 13, 2593, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3347, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3348, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 11066, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 6986, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3346, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 6987, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3345, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3405, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3404, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 7, 179596, 'SPAWN'),
(35186, @SNIFFID+2, 7, 175315, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5811, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3365, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3316, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3366, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 7088, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3363, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 2855, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 13366, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15060, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12503, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 130, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 173032, 'SPAWN'),
(35186, @SNIFFID+2, 6, 14726, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3315, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 14726, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3315, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3367, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3371, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3364, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3364, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173030, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3372, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 7010, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 7, 173028, 'SPAWN');

INSERT IGNORE INTO `sniff_data` (`sniff_build`, `sniff_id`, `object_type`, `id`, `data`) VALUES
(35186, @SNIFFID+2, 7, 172954, 'SPAWN'),
(35186, @SNIFFID+2, 2, 7502, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12285, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 27787, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22841, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18679, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 27037, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14163, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23246, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 10140, 'CAST'),
(35186, @SNIFFID+2, 7, 173019, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3369, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 7686, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7689, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11095, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12359, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7301, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 1460, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7527, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7578, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15874, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20505, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12950, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23250, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 3369, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173029, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173017, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173015, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173014, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172942, 'SPAWN'),
(35186, @SNIFFID+2, 2, 12051, 'CAST'),
(35186, @SNIFFID+2, 2, 12051, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 3368, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3400, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3399, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 168, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 175317, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3368, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3400, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3399, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173016, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172941, 'SPAWN'),
(35186, @SNIFFID+2, 2, 14463, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14406, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29091, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14465, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14408, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9111, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9105, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9262, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9261, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14405, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7499, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 10193, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 173027, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173026, 'SPAWN'),
(35186, @SNIFFID+2, 2, 11213, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 8690, 'CAST'),
(35186, @SNIFFID+2, 2, 22734, 'CAST'),
(35186, @SNIFFID+2, 2, 13262, 'CAST'),
(35186, @SNIFFID+2, 7, 172945, 'SPAWN'),
(35186, @SNIFFID+2, 2, 1953, 'CAST'),
(35186, @SNIFFID+2, 2, 1953, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 10958, 'CAST'),
(35186, @SNIFFID+2, 6, 3328, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 7, 105576, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3216, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3216, 'SPAWN'),
(35186, @SNIFFID+2, 7, 175318, 'SPAWN'),
(35186, @SNIFFID+2, 7, 175313, 'SPAWN'),
(35186, @SNIFFID+2, 2, 10938, 'CAST'),
(35186, @SNIFFID+2, 2, 25146, 'CAST'),
(35186, @SNIFFID+2, 2, 27681, 'CAST'),
(35186, @SNIFFID+2, 6, 3331, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3329, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3323, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3189, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 23509, 'CAST'),
(35186, @SNIFFID+2, 2, 18428, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 3329, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3189, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173176, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173174, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173171, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172952, 'SPAWN'),
(35186, @SNIFFID+2, 2, 21564, 'CAST'),
(35186, @SNIFFID+2, 2, 13836, 'CAST'),
(35186, @SNIFFID+2, 2, 130, 'CAST'),
(35186, @SNIFFID+2, 6, 7565, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 14751, 'CAST'),
(35186, @SNIFFID+2, 2, 14751, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12792, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21890, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18185, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23563, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16542, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12765, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12764, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12879, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16466, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7376, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 8098, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 71, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15821, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13365, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11551, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 177025, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172967, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172953, 'SPAWN'),
(35186, @SNIFFID+2, 2, 12289, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9412, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14776, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15310, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 27840, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17325, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15316, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15448, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15328, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15317, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22959, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7373, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 10901, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 3430, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3310, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 16040, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16112, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23734, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 10432, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 325, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12658, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 172962, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172963, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172964, 'SPAWN'),
(35186, @SNIFFID+2, 6, 8673, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 9856, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 21973, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14407, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9107, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29438, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29444, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15438, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14472, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14464, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 8397, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13369, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17875, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23730, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18463, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17897, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17873, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17902, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16763, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11165, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17670, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21969, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18074, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29088, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29080, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16284, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16291, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15811, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29096, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17746, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14135, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14803, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13664, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24489, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11334, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11405, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16295, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16253, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9782, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24428, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13384, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12329, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22010, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18550, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14750, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19266, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 10952, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 8673, 'SPAWN'),
(35186, @SNIFFID+2, 6, 9856, 'SPAWN'),
(35186, @SNIFFID+2, 2, 16491, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14204, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24482, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29446, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12536, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24191, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24595, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15013, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15362, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15009, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14768, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21440, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7778, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19618, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19160, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19152, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19883, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 4194, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17210, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16947, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21178, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9635, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24899, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24868, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9634, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 772, 'SPAWN'),
(35186, @SNIFFID+2, 2, 9258, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9121, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16820, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17068, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17055, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16847, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16901, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16880, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16926, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16913, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16919, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16825, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29166, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9884, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18031, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7823, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24159, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16819, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16920, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17078, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 8222, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 10259, 'SPAWN'),
(35186, @SNIFFID+2, 2, 21874, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14052, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14168, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 5188, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 4190, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24507, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17223, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22780, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19377, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24283, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19245, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19390, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19153, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19885, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23047, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23046, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18312, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18830, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17784, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18176, 'AURA_UPDATE');

INSERT IGNORE INTO `sniff_data` (`sniff_build`, `sniff_id`, `object_type`, `id`, `data`) VALUES
(35186, @SNIFFID+2, 2, 19480, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 30797, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19007, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18739, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18738, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18730, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 9696, 'SPAWN'),
(35186, @SNIFFID+2, 6, 417, 'SPAWN'),
(35186, @SNIFFID+2, 6, 8724, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 14377, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3322, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 14786, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17878, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9298, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13363, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7773, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18018, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29090, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 28682, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11129, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19619, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19425, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 5118, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7464, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29092, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24486, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24430, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18771, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18751, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20575, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 26395, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18049, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17807, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18372, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18094, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17779, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 30796, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16184, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7501, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9112, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7474, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9099, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9141, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14824, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 1494, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 8724, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3322, 'SPAWN'),
(35186, @SNIFFID+2, 2, 23570, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16224, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16114, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7494, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7513, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9760, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12971, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16487, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12282, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 3312, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 5784, 'CAST'),
(35186, @SNIFFID+2, 6, 15188, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 7, 173218, 'SPAWN'),
(35186, @SNIFFID+2, 2, 14639, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 14375, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 7582, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22811, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7570, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24294, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 20895, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19586, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19552, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19407, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 10796, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14321, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 27901, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9109, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29094, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13839, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29626, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24443, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19494, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19498, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19458, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 19468, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24439, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 4192, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24630, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16462, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 731, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173222, 'SPAWN'),
(35186, @SNIFFID+2, 2, 16968, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12518, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21975, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14416, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14418, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18459, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11151, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 4189, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24502, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24497, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 172965, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3314, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 11189, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23252, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17780, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17808, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13856, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9103, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9123, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12833, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12678, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13697, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9120, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16933, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21922, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23555, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18752, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18770, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9413, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15473, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15807, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12858, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12177, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 173223, 'SPAWN'),
(35186, @SNIFFID+2, 2, 18388, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18044, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7681, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9398, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29189, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23247, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7490, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13972, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22817, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22820, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23587, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14585, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7500, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9113, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12575, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 5611, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3318, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 5610, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 5614, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3320, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3309, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 17866, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18042, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21636, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15815, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7540, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14909, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9265, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15052, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21871, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21872, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17066, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16834, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17071, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16840, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16818, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 5611, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3318, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5610, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5614, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3320, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3309, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5613, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 6466, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 5606, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 5609, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 23566, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15366, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15312, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 30919, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16323, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15771, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17074, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17063, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 28856, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13959, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7442, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7455, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9110, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14889, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14528, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15336, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 24198, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17495, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 173115, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5613, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173225, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173114, 'SPAWN'),
(35186, @SNIFFID+2, 6, 6466, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5606, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5609, 'SPAWN'),
(35186, @SNIFFID+2, 13, 7176, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 15, 6024, '14720'),
(35186, @SNIFFID+2, 6, 6929, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 28997, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23686, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23585, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13595, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17790, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18742, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18735, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 18727, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21596, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14717, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15345, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21629, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13388, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21930, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14641, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16372, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14626, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14636, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15808, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29369, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14787, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16111, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29193, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22852, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12797, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12803, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 30778, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 1860, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173226, 'SPAWN'),
(35186, @SNIFFID+2, 6, 6929, 'SPAWN'),
(35186, @SNIFFID+2, 2, 13838, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 12501, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15007, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29179, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16116, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16274, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 173221, 'SPAWN'),
(35186, @SNIFFID+2, 2, 14645, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9334, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 25069, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 25129, 'CAST'),
(35186, @SNIFFID+2, 7, 173012, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173011, 'SPAWN'),
(35186, @SNIFFID+2, 6, 13842, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 23930, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 21920, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 17539, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 29333, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14162, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 14160, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 27789, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15020, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23515, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13793, 'AURA_UPDATE');

INSERT IGNORE INTO `sniff_data` (`sniff_build`, `sniff_id`, `object_type`, `id`, `data`) VALUES
(35186, @SNIFFID+2, 6, 13842, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173216, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3319, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3321, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 5603, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3317, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 5597, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 2, 18014, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13928, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22847, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 13387, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 7217, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 22683, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 16864, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 9305, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23212, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15275, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15329, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 15338, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 1245, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 7, 177020, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3319, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3321, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5603, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173206, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3317, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173204, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177019, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173202, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177024, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5597, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5817, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173199, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173198, 'SPAWN'),
(35186, @SNIFFID+2, 6, 173758, 'SPAWN'),
(35186, @SNIFFID+2, 7, 179881, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173197, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5817, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3313, 'QUERY_RESPONSE'),
(35186, @SNIFFID+2, 6, 3313, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173203, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173112, 'SPAWN'),
(35186, @SNIFFID+2, 7, 177017, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173200, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172961, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172960, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172959, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172958, 'SPAWN'),
(35186, @SNIFFID+2, 7, 172957, 'SPAWN'),
(35186, @SNIFFID+2, 7, 176562, 'SPAWN'),
(35186, @SNIFFID+2, 3, 1, 'NEW_WORLD'),
(35186, @SNIFFID+2, 7, 177018, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173008, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173010, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173009, 'SPAWN'),
(35186, @SNIFFID+2, 7, 173013, 'SPAWN'),
(35186, @SNIFFID+2, 3, 1, 'LOAD_SCREEN'),
(35186, @SNIFFID+2, 2, 15047, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 11222, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 2, 23241, 'AURA_UPDATE'),
(35186, @SNIFFID+2, 6, 4311, 'SPAWN'),
(35186, @SNIFFID+2, 6, 5951, 'SPAWN'),
(35186, @SNIFFID+2, 6, 3100, 'SPAWN');

DELETE FROM `quest_details` WHERE `ID`=8792;
INSERT INTO `quest_details` (`ID`, `Emote1`, `Emote2`, `Emote3`, `Emote4`, `EmoteDelay1`, `EmoteDelay2`, `EmoteDelay3`, `EmoteDelay4`, `VerifiedBuild`) VALUES
(8792, 1, 1, 6, 0, 0, 1000, 1000, 0, 35186); -- 8792


DELETE FROM `quest_request_items` WHERE `ID` IN (8843 /*8843*/, 8850 /*8850*/, 8821 /*8821*/, 8813 /*8813*/, 8822 /*8822*/, 8819 /*8819*/, 8814 /*8814*/, 8824 /*8824*/, 8816 /*8816*/, 8826 /*8826*/, 8817 /*8817*/, 8825 /*8825*/, 8818 /*8818*/, 8823 /*8823*/, 8815 /*8815*/);
INSERT INTO `quest_request_items` (`ID`, `Emote`, `CompletionText`, `VerifiedBuild`) VALUES
(8843, 1, 'I accept commendation signets from adventurers who have received them in the line of duty.  For each set of ten that you hand to me, I\'ll make sure that you receive a significant acknowledgement of your deeds with Thunder Bluff.  I also accept single tokens, but at a much reduced rate of recognition.  We are much more interested in greater feats of duty, though no feat will be ignored.$B$BWith that said, I\'ll gladly take your signets if you are ready to hand in a set.', 35186), -- 8843
(8850, 1, 'Ah, here for additional supplies for yourself, are you?  Well, I can certainly understand the need for additional materiel... just take a look around if you need any proof.$B$BI\'ll issue you some additional supplies, but you\'ll need to give me an appropriate number of commendation signets in exchange.  You won\'t receive any recognition for surrendering the signets in this manner, but you might find something useful that will help keep you alive when battle is finally upon us.', 35186), -- 8850
(8821, 1, 'I accept commendation signets from adventurers who have received them in the line of duty.  For each set of ten that you hand to me, I\'ll make sure that you receive a significant acknowledgement of your deeds with Ironforge.  I also accept single tokens, but at a much reduced rate of recognition.  We are much more interested in greater feats of duty, though no feat will be ignored.$B$BWith that said, I\'ll gladly take your signets if you are ready to hand in a set.', 35186), -- 8821
(8813, 1, 'For those adventurers who have but a single commendation signet, I\'ll exchange it for a small amount of recognition with Ironforge.$B$BPlease bear in mind that it is better to hand over a stack of ten signets at once; your efforts will receive greater recognition in doing so.  We offer a single signet exchange as a service for those who don\'t have enough for a full stack of ten.$B$BWith that being said, I stand ready to assist you if you still wish to hand in a single signet.', 35186), -- 8813
(8822, 1, 'I accept commendation signets from adventurers who have received them in the line of duty.  For each set of ten that you hand to me, I\'ll make sure that you receive a significant acknowledgement of your deeds with Stormwind.  I also accept single tokens, but at a much reduced rate of recognition.  We are much more interested in greater feats of duty, though no feat will be ignored.$B$BWith that said, I\'ll gladly take your signets if you are ready to hand in a set.', 35186), -- 8822
(8819, 1, 'I accept commendation signets from adventurers who have received them in the line of duty.  For each set of ten that you hand to me, I\'ll make sure that you receive a significant acknowledgement of your deeds with Darnassus.  I also accept single tokens, but at a much reduced rate of recognition.  We are much more interested in greater feats of duty, though no feat will be ignored.$B$BWith that said, I\'ll gladly take your signets if you are ready to hand in a set.', 35186), -- 8819
(8814, 1, 'For those adventurers who have but a single commendation signet, I\'ll exchange it for a small amount of recognition with Stormwind.$B$BPlease bear in mind that it is better to hand over a stack of ten signets at once; your efforts will receive greater recognition in doing so.  We offer a single signet exchange as a service for those who don\'t have enough for a full stack of ten.$B$BWith that being said, I stand ready to assist you if you still wish to hand in a single signet.', 35186), -- 8814
(8824, 1, 'I accept commendation signets from adventurers who have received them in the line of duty.  For each set of ten that you hand to me, I\'ll make sure that you receive a significant acknowledgement of your deeds with the Darkspear tribe.  I also accept single tokens, but at a much reduced rate of recognition.  We are much more interested in greater feats of duty, though no feat will be ignored.$B$BWith that said, I\'ll gladly take your signets if you are ready to hand in a set.', 35186), -- 8824
(8816, 1, 'For those adventurers who have but a single commendation signet, I\'ll exchange it for a small amount of recognition with the Darkspear tribe.$B$BPlease bear in mind that it is better to hand over a stack of ten signets at once; your efforts will receive greater recognition in doing so.  We offer a single signet exchange as a service for those who don\'t have enough for a full stack of ten.$B$BWith that being said, I stand ready to assist you if you still wish to hand in a single signet.', 35186), -- 8816
(8826, 1, 'I accept commendation signets from adventurers who have received them in the line of duty.  For each set of ten that you hand to me, I\'ll make sure that you receive a significant acknowledgement of your deeds with Undercity.  I also accept single tokens, but at a much reduced rate of recognition.  We are much more interested in greater feats of duty, though no feat will be ignored.$B$BWith that said, I\'ll gladly take your signets if you are ready to hand in a set.', 35186), -- 8826
(8817, 1, 'For those adventurers who have but a single commendation signet, I\'ll exchange it for a small amount of recognition with the Undercity.$B$BPlease bear in mind that it is better to hand over a stack of ten signets at once; your efforts will receive greater recognition in doing so.  We offer a single signet exchange as a service for those who don\'t have enough for a full stack of ten.$B$BWith that being said, I stand ready to assist you if you still wish to hand in a single signet.', 35186), -- 8817
(8825, 1, 'I accept commendation signets from adventurers who have received them in the line of duty.  For each set of ten that you hand to me, I\'ll make sure that you receive a significant acknowledgement of your deeds with Thunder Bluff.  I also accept single tokens, but at a much reduced rate of recognition.  We are much more interested in greater feats of duty, though no feat will be ignored.$B$BWith that said, I\'ll gladly take your signets if you are ready to hand in a set.', 35186), -- 8825
(8818, 1, 'For those adventurers who have but a single commendation signet, I\'ll exchange it for a small amount of recognition with Thunder Bluff.$B$BPlease bear in mind that it is better to hand over a stack of ten signets at once; your efforts will receive greater recognition in doing so.  We offer a single signet exchange as a service for those who don\'t have enough for a full stack of ten.$B$BWith that being said, I stand ready to assist you if you still wish to hand in a single signet.', 35186), -- 8818
(8823, 1, 'I accept commendation signets from adventurers who have received them in the line of duty.  For each set of ten that you hand to me, I\'ll make sure that you receive a significant acknowledgement of your deeds with Orgrimmar.  I also accept single tokens, but at a much reduced rate of recognition.  We are much more interested in greater feats of duty, though no feat will be ignored.$B$BWith that said, I\'ll gladly take your signets if you are ready to hand in a set.', 35186), -- 8823
(8815, 1, 'For those adventurers who have but a single commendation signet, I\'ll exchange it for a small amount of recognition with Orgrimmar.$B$BPlease bear in mind that it is better to hand over a stack of ten signets at once; your efforts will receive greater recognition in doing so.  We offer a single signet exchange as a service for those who don\'t have enough for a full stack of ten.$B$BWith that being said, I stand ready to assist you if you still wish to hand in a single signet.', 35186); -- 8815


DELETE FROM `quest_starter` WHERE (`object_id`=15702 AND `object_type`='Creature' AND `quest_id`=8792);
INSERT INTO `quest_starter` (`object_id`, `object_type`, `quest_id`) VALUES
(15702, 'Creature', 8792); -- 15702


DELETE FROM `quest_ender` WHERE (`object_id`=15767 AND `object_type`='Creature' AND `quest_id`=8843) OR (`object_id`=15700 AND `object_type`='Creature' AND `quest_id`=8792) OR (`object_id`=16107 AND `object_type`='Creature' AND `quest_id`=8984) OR (`object_id`=15701 AND `object_type`='Creature' AND `quest_id`=8850) OR (`object_id`=15734 AND `object_type`='Creature' AND `quest_id`=8821) OR (`object_id`=15734 AND `object_type`='Creature' AND `quest_id`=8813) OR (`object_id`=15735 AND `object_type`='Creature' AND `quest_id`=8822) OR (`object_id`=15731 AND `object_type`='Creature' AND `quest_id`=8819) OR (`object_id`=15735 AND `object_type`='Creature' AND `quest_id`=8814) OR (`object_id`=179551 AND `object_type`='GameObject' AND `quest_id`=7486) OR (`object_id`=16788 AND `object_type`='Creature' AND `quest_id`=9389) OR (`object_id`=16817 AND `object_type`='Creature' AND `quest_id`=9367) OR (`object_id`=16788 AND `object_type`='Creature' AND `quest_id`=9323) OR (`object_id`=16788 AND `object_type`='Creature' AND `quest_id`=9322) OR (`object_id`=16788 AND `object_type`='Creature' AND `quest_id`=9319) OR (`object_id`=11558 AND `object_type`='Creature' AND `quest_id`=8471) OR (`object_id`=15170 AND `object_type`='Creature' AND `quest_id`=8308) OR (`object_id`=14526 AND `object_type`='Creature' AND `quest_id`=7634) OR (`object_id`=14374 AND `object_type`='Creature' AND `quest_id`=7482) OR (`object_id`=13777 AND `object_type`='Creature' AND `quest_id`=7122) OR (`object_id`=12425 AND `object_type`='Creature' AND `quest_id`=6185) OR (`object_id`=11023 AND `object_type`='Creature' AND `quest_id`=5343) OR (`object_id`=11033 AND `object_type`='Creature' AND `quest_id`=5214) OR (`object_id`=9562 AND `object_type`='Creature' AND `quest_id`=4701) OR (`object_id`=15737 AND `object_type`='Creature' AND `quest_id`=8824) OR (`object_id`=15737 AND `object_type`='Creature' AND `quest_id`=8816) OR (`object_id`=15738 AND `object_type`='Creature' AND `quest_id`=8826) OR (`object_id`=15738 AND `object_type`='Creature' AND `quest_id`=8817) OR (`object_id`=15739 AND `object_type`='Creature' AND `quest_id`=8825) OR (`object_id`=15739 AND `object_type`='Creature' AND `quest_id`=8818) OR (`object_id`=15736 AND `object_type`='Creature' AND `quest_id`=8823) OR (`object_id`=15736 AND `object_type`='Creature' AND `quest_id`=8815);
INSERT INTO `quest_ender` (`object_id`, `object_type`, `quest_id`) VALUES
(15767, 'Creature', 8843), -- 15767
(15700, 'Creature', 8792), -- 15700
(16107, 'Creature', 8984), -- 16107
(15701, 'Creature', 8850), -- 15701
(15734, 'Creature', 8821), -- 15734
(15734, 'Creature', 8813), -- 15734
(15735, 'Creature', 8822), -- 15735
(15731, 'Creature', 8819), -- 15731
(15735, 'Creature', 8814), -- 15735
(179551, 'GameObject', 7486), -- 179551
(16788, 'Creature', 9389), -- 16788
(16817, 'Creature', 9367), -- 16817
(16788, 'Creature', 9323), -- 16788
(16788, 'Creature', 9322), -- 16788
(16788, 'Creature', 9319), -- 16788
(11558, 'Creature', 8471), -- 11558
(15170, 'Creature', 8308), -- 15170
(14526, 'Creature', 7634), -- 14526
(14374, 'Creature', 7482), -- 14374
(13777, 'Creature', 7122), -- 13777
(12425, 'Creature', 6185), -- 12425
(11023, 'Creature', 5343), -- 11023
(11033, 'Creature', 5214), -- 11033
(9562, 'Creature', 4701), -- 9562
(15737, 'Creature', 8824), -- 15737
(15737, 'Creature', 8816), -- 15737
(15738, 'Creature', 8826), -- 15738
(15738, 'Creature', 8817), -- 15738
(15739, 'Creature', 8825), -- 15739
(15739, 'Creature', 8818), -- 15739
(15736, 'Creature', 8823), -- 15736
(15736, 'Creature', 8815); -- 15736


DELETE FROM `creature` WHERE `guid` BETWEEN @CGUID+0 AND @CGUID+521;
INSERT INTO `creature` (`guid`, `id`, `map`, `zone_id`, `area_id`, `position_x`, `position_y`, `position_z`, `orientation`, `wander_distance`, `movement_type`, `is_spawn`, `is_hovering`, `is_temporary`, `is_pet`, `summon_spell`, `scale`, `display_id`, `native_display_id`, `mount_display_id`, `class`, `gender`, `faction`, `level`, `npc_flags`, `unit_flags`, `unit_flags2`, `dynamic_flags`, `current_health`, `max_health`, `current_mana`, `max_mana`, `aura_state`, `emote_state`, `stand_state`, `vis_flags`, `sheath_state`, `pvp_flags`, `shapeshift_form`, `move_flags`, `speed_walk`, `speed_run`, `speed_run_back`, `speed_swim`, `speed_swim_back`, `speed_fly`, `speed_fly_back`, `bounding_radius`, `combat_reach`, `mod_melee_haste`, `main_hand_attack_time`, `off_hand_attack_time`, `main_hand_slot_item`, `off_hand_slot_item`, `ranged_slot_item`, `channel_spell_id`, `channel_visual_id`, `auras`, `sniff_id`, `sniff_build`) VALUES
(@CGUID+4, 2998, 1, 1638, 1638, -1233.331, 105.6367, 129.4562, 5.61996, 0, 0, 0, 0, 0, 0, 0, 1, 2090, 2090, 0, 1, 0, 104, 35, 1, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 1903, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+5, 3003, 1, 1638, 1638, -1220.143, 84.16078, 131.2034, 2.408554, 0, 0, 0, 0, 0, 0, 0, 1, 2109, 2109, 0, 1, 1, 104, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 2197, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+18, 3084, 1, 1638, 1638, -1279.37, 53.55626, 129.2348, 0.6283185, 0, 0, 0, 0, 0, 0, 0, 1, 9391, 9391, 0, 1, 0, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+11, 8360, 1, 1638, 1638, -1243.762, 47.36779, 127.2204, 5.986479, 0, 0, 0, 0, 0, 0, 0, 1, 7624, 7624, 0, 1, 0, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+7, 15105, 1, 1638, 1638, -1245.479, 58.31109, 127.087, 4.118977, 0, 0, 0, 0, 0, 0, 0, 1, 15250, 15250, 0, 2, 1, 1641, 30, 1, 0, 2048, 0, 852, 852, 852, 852, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+17, 10054, 1, 1638, 1638, -1269.077, 46.05962, 128.5839, 2.216568, 0, 0, 0, 0, 0, 0, 0, 1, 9272, 9272, 0, 1, 0, 29, 30, 4194304, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 1.07217, 4.455, 1, 2000, 2000, 12328, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+3, 10278, 1, 1638, 1638, -1244.25, 105.0842, 129.0869, 0.5061455, 0, 0, 0, 0, 0, 0, 0, 1, 9742, 9742, 0, 1, 0, 104, 24, 17, 512, 2048, 0, 664, 664, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 1903, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+9, 8674, 1, 1638, 1638, -1210.214, 94.85867, 134.5352, 2.984513, 0, 0, 0, 0, 0, 0, 0, 1, 7999, 7999, 0, 1, 0, 104, 50, 2097152, 0, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+15, 8358, 1, 1638, 1638, -1243.86, 40.9178, 127.1974, 0.5934119, 0, 0, 0, 0, 0, 0, 0, 1, 7622, 7622, 0, 1, 0, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+16, 8359, 1, 1638, 1638, -1238.583, 38.97103, 127.1472, 2.059489, 0, 0, 0, 0, 0, 0, 0, 1, 7623, 7623, 0, 1, 0, 104, 30, 4227, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+21, 8361, 1, 1638, 1638, -1228.985, 137.3052, 133.2202, 3.221807, 0, 0, 0, 0, 0, 0, 0, 1, 7625, 7625, 0, 1, 1, 104, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 2716, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+22, 8363, 1, 1638, 1638, -1295.305, 92.46194, 129.81, 0.8028514, 0, 0, 0, 0, 0, 0, 0, 1, 7628, 7628, 0, 1, 1, 104, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 1903, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+10, 15702, 1, 1638, 1638, -1209.585, 100.2201, 134.661, 3.159046, 0, 0, 0, 0, 0, 0, 0, 1, 15664, 15664, 0, 1, 1, 104, 60, 3, 0, 2048, 0, 15260, 15260, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 5280, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+6, 6410, 1, 1638, 1638, -1239.841, 110.5848, 129.7397, 1.832596, 0, 0, 0, 0, 0, 0, 0, 1, 5372, 5372, 0, 1, 0, 83, 45, 2, 512, 2048, 0, 2218, 2218, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 1903, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+14, 11869, 1, 1638, 1638, -1286.474, 89.42285, 129.2798, 0.3141593, 0, 0, 0, 0, 0, 0, 0, 1, 11803, 11803, 0, 1, 0, 104, 50, 17, 0, 2048, 0, 15505, 15505, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 14527, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+1, 15767, 1, 1638, 1638, -1246.485, 74.2627, 128.3682, 5.026548, 0, 0, 0, 0, 0, 0, 0, 1, 15730, 15730, 0, 1, 1, 104, 55, 3, 0, 2048, 0, 2614, 2614, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+23, 3084, 1, 1638, 1638, -1276.69, 45.71994, 129.0358, 0.6632251, 0, 0, 0, 0, 0, 0, 0, 1, 2141, 2141, 0, 1, 0, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+13, 2987, 1, 1638, 1638, -1264.422, 123.3006, 131.731, 3.089233, 0, 0, 0, 0, 0, 0, 0, 1, 4516, 4516, 0, 1, 0, 83, 12, 2, 512, 2048, 0, 247, 247, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 2023, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+20, 3084, 1, 1638, 1638, -1232.89, 136.3647, 132.8886, 3.340167, 0, 0, 0, 0, 0, 0, 0, 1, 8572, 8572, 0, 1, 1, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+12, 2997, 1, 1638, 1638, -1283.918, 84.36076, 128.8695, 1.012291, 0, 0, 0, 0, 0, 0, 0, 1, 2110, 2110, 0, 1, 1, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 5292, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+2, 2999, 1, 1638, 1638, -1237.209, 101.0656, 129.1598, 5.654867, 0, 0, 0, 0, 0, 0, 0, 1, 2100, 2100, 0, 1, 0, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 5532, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+19, 8722, 1, 1638, 1638, -1199.256, 110.6928, 134.9491, 3.054326, 0, 0, 0, 0, 0, 0, 0, 1, 7998, 7998, 0, 1, 0, 104, 50, 2097152, 0, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+8, 15105, 1, 1638, 1638, -1247.748, 54.70242, 127.2171, 1.047198, 0, 0, 0, 0, 0, 0, 0, 1, 15249, 15249, 0, 2, 1, 1641, 30, 1, 0, 2048, 0, 852, 852, 852, 852, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+36, 3002, 1, 1638, 1638, -1243.526, 158.1636, 133.6302, 3.665191, 0, 0, 0, 0, 0, 0, 0, 1, 2092, 2092, 0, 1, 0, 104, 40, 128, 512, 2048, 0, 1753, 1753, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 1910, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+42, 3005, 1, 1638, 1638, -1163.944, 59.48568, 145.8775, 6.021386, 0, 0, 0, 0, 0, 0, 0, 1, 2093, 2093, 0, 1, 0, 104, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 5281, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+40, 10881, 1, 1638, 1638, -1320.085, 56.37432, 129.1248, 3.336318, 151.5292, 2, 0, 0, 0, 0, 0, 1, 10188, 10188, 0, 1, 0, 104, 3, 3, 0, 2048, 0, 71, 71, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 1906, 0, 0, 0, 0, '', @SNIFFID+0, 35186), --  (possible waypoints or random movement)
(@CGUID+48, 3008, 1, 1638, 1638, -1152.34, 77.68311, 145.8775, 5.375614, 0, 0, 0, 0, 0, 0, 0, 1, 2094, 2094, 0, 1, 0, 104, 24, 17, 512, 2048, 0, 664, 664, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 10616, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+32, 8356, 1, 1638, 1638, -1252.821, 24.74381, 128.2699, 3.176499, 0, 0, 0, 0, 0, 0, 0, 1, 7621, 7621, 0, 1, 1, 104, 45, 131072, 512, 2048, 0, 5544, 5544, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 12744, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+51, 3015, 1, 1638, 1638, -1168.012, 26.12506, 145.8121, 1.692969, 0, 0, 0, 0, 0, 0, 0, 1, 2114, 2114, 0, 1, 1, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 0, 0, 5259, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+34, 8357, 1, 1638, 1638, -1262.783, 24.00548, 128.2699, 0.1047198, 0, 0, 0, 0, 0, 0, 0, 1, 7620, 7620, 0, 1, 0, 104, 45, 131072, 512, 2048, 0, 5544, 5544, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12856, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+53, 11084, 1, 1638, 1638, -1146.479, 74.90902, 145.9493, 3.822271, 0, 0, 0, 0, 0, 0, 0, 1, 10617, 10617, 0, 1, 0, 104, 36, 1, 512, 2048, 0, 1469, 1469, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12290, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+49, 3093, 1, 1638, 1638, -1152.759, 71.40565, 145.8775, 5.585053, 0, 0, 0, 0, 0, 0, 0, 1, 2129, 2129, 0, 1, 0, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 5291, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+41, 3095, 1, 1638, 1638, -1161.713, 70.42909, 145.8775, 5.811946, 0, 0, 0, 0, 0, 0, 0, 1, 2132, 2132, 0, 1, 1, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 12297, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+27, 5189, 1, 1638, 1638, -1290.152, 123.4586, 131.6418, 0.715585, 0, 0, 0, 0, 0, 0, 0, 1, 3129, 3129, 0, 1, 0, 104, 25, 524416, 512, 2048, 0, 713, 713, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 10611, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+24, 8364, 1, 1638, 1638, -1297.2, 106.3774, 131.3429, 0.8203048, 0, 0, 0, 0, 0, 0, 0, 1, 7627, 7627, 0, 1, 1, 104, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 12744, 12745, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+45, 3050, 1, 1638, 1638, -1161.031, 53.35417, 145.8775, 1.27409, 0, 0, 0, 0, 0, 0, 0, 1, 4517, 4517, 0, 1, 0, 104, 21, 2, 512, 2048, 0, 531, 531, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 5301, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+55, 7089, 1, 1638, 1638, -1150.261, 52.81494, 144.92, 5.654867, 0, 0, 0, 0, 0, 0, 0, 1, 5847, 5847, 0, 1, 1, 104, 35, 16, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 5278, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+26, 4451, 1, 1638, 1638, -1266.915, 141.1973, 132.646, 5.183628, 0, 0, 0, 0, 0, 0, 0, 1, 4568, 4568, 0, 1, 0, 104, 28, 2, 512, 2048, 0, 896, 896, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 1908, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+47, 11051, 1, 1638, 1638, -1158.557, 54.74316, 145.9493, 1.867502, 0, 0, 0, 0, 0, 0, 0, 1, 10586, 10586, 0, 1, 0, 104, 26, 17, 512, 2048, 0, 787, 787, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+31, 15105, 1, 1638, 1638, -1277.939, 138.4697, 131.9397, 5.358161, 0, 0, 0, 0, 0, 0, 0, 1, 15249, 15249, 0, 2, 1, 1641, 30, 1, 0, 2048, 0, 852, 852, 852, 852, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+50, 3978, 1, 1638, 1638, -1176.121, 157.6149, 134.8121, 3.961897, 0, 0, 0, 0, 0, 0, 0, 1, 4518, 4518, 0, 1, 0, 104, 30, 2, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 2558, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+28, 3084, 1, 1638, 1638, -1201.92, 130.7531, 134.8664, 3.700098, 0, 0, 0, 0, 0, 0, 0, 1, 2141, 2141, 0, 1, 0, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+30, 3084, 1, 1638, 1638, -1208.413, 138.0461, 134.554, 3.944444, 0, 0, 0, 0, 0, 0, 0, 1, 9392, 9392, 0, 1, 1, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+25, 15105, 1, 1638, 1638, -1275.748, 135.8799, 132.0996, 2.321288, 0, 0, 0, 0, 0, 0, 0, 1, 15249, 15249, 0, 2, 1, 1641, 30, 1, 0, 2048, 0, 852, 852, 852, 852, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+44, 3092, 1, 1638, 1638, -1158.5, 63.23882, 145.8775, 6.038839, 0, 0, 0, 0, 0, 0, 0, 1, 2133, 2133, 0, 1, 1, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 12629, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+54, 14728, 1, 1638, 1638, -1147.28, 67.33534, 145.9493, 3.246312, 0, 0, 0, 0, 0, 0, 0, 1, 14758, 14758, 0, 1, 0, 104, 35, 3, 0, 2048, 0, 1220, 1220, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+43, 3004, 1, 1638, 1638, -1165.591, 51.93929, 145.8775, 0.7504916, 0, 0, 0, 0, 0, 0, 0, 1, 2126, 2126, 0, 1, 1, 104, 35, 1, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 12329, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+52, 3007, 1, 1638, 1638, -1146.208, 83.47656, 145.9493, 4.24115, 0, 0, 0, 0, 0, 0, 0, 1, 2127, 2127, 0, 1, 1, 104, 46, 3, 512, 2048, 0, 2399, 2399, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 2711, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+46, 2995, 1, 1638, 1638, -1196.75, 26.07769, 177.0325, 1.710423, 0, 0, 0, 0, 0, 0, 0, 1, 2098, 2098, 0, 1, 0, 104, 55, 8195, 512, 2048, 0, 7842, 7842, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 6680, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+38, 3084, 1, 1638, 1638, -1289.023, 144.4175, 129.8031, 5.061455, 0, 0, 0, 0, 0, 0, 0, 1, 9392, 9392, 0, 1, 1, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+37, 3001, 1, 1638, 1638, -1252.902, 157.9649, 133.6302, 5.8294, 0, 0, 0, 0, 0, 0, 0, 1, 2083, 2083, 0, 1, 0, 104, 35, 16, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 1910, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+33, 5054, 1, 1638, 1638, -1291.813, 127.2062, 131.4954, 6.056293, 0, 0, 0, 0, 0, 0, 0, 1, 3002, 3002, 0, 1, 0, 104, 50, 786433, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 5301, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+29, 8362, 1, 1638, 1638, -1300.173, 110.5405, 131.4518, 6.126106, 0, 0, 0, 0, 0, 0, 0, 1, 7626, 7626, 0, 1, 0, 104, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 2197, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+39, 6746, 1, 1638, 1638, -1300.277, 38.48579, 129.2918, 0.5585054, 0, 0, 0, 0, 0, 0, 0, 1, 5487, 5487, 0, 1, 1, 104, 30, 65667, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 3362, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+35, 2996, 1, 1638, 1638, -1257.633, 19.55767, 128.2699, 1.727876, 0, 0, 0, 0, 0, 0, 0, 1, 2104, 2104, 0, 1, 0, 104, 45, 131072, 512, 2048, 0, 5544, 5544, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12854, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+233, 3100, 1, 14, 14, 1210.913, -4439.458, 21.79144, 5.296871, 6.734775, 1, 0, 0, 0, 0, 0, 1, 193, 193, 0, 1, 2, 189, 9, 0, 0, 2048, 0, 176, 176, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0.8571429, 1, 1, 1, 1, 1, 1.176, 1, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+238, 4311, 1, 14, 14, 1352.447, -4395.704, 29.27125, 2.286381, 0, 0, 0, 0, 0, 0, 0, 1, 4515, 4515, 0, 1, 0, 29, 30, 0, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.4092, 1.65, 1, 2000, 2000, 5288, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+237, 5951, 1, 14, 14, 1202.238, -4341.378, 25.82244, 5.292533, 10.07157, 1, 0, 0, 0, 0, 0, 1, 1560, 1560, 0, 1, 2, 31, 1, 0, 0, 2048, 0, 8, 8, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0.8571429, 1, 1, 1, 1, 1, 0.17625, 0.75, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+236, 3100, 1, 14, 14, 1230.807, -4333.156, 27.57174, 0.1707684, 0, 1, 0, 0, 0, 0, 0, 1, 193, 193, 0, 1, 2, 189, 9, 0, 0, 2048, 0, 176, 176, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0.8571429, 1, 1, 1, 1, 1, 1.176, 1, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+235, 3100, 1, 14, 14, 1199.713, -4395.253, 23.5699, 5.848229, 2.03732, 1, 0, 0, 0, 0, 0, 1, 193, 193, 0, 1, 2, 189, 9, 0, 0, 2048, 0, 176, 176, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0.8571429, 1, 1, 1, 1, 1, 1.176, 1, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+234, 3100, 1, 14, 14, 1231.247, -4403.404, 26.04586, 2.089458, 5.535847, 1, 0, 0, 0, 0, 0, 1, 193, 193, 0, 1, 2, 189, 8, 0, 0, 2048, 0, 156, 156, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0.8571429, 1, 1, 1, 1, 1, 1.176, 1, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+101, 15383, 0, 1537, 1537, -4924.366, -1222.73, 501.7176, 3.926991, 0, 0, 0, 0, 0, 0, 0, 1, 15441, 15441, 0, 1, 0, 55, 56, 1, 0, 2048, 0, 13495, 13495, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 17942, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+112, 15445, 0, 1537, 1537, -4948.334, -1273.797, 501.7552, 1.064651, 0, 0, 0, 0, 0, 0, 0, 1, 15449, 15449, 0, 1, 1, 12, 60, 1, 0, 2048, 0, 15260, 15260, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.208, 1.5, 1, 2000, 2000, 1899, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+99, 5595, 0, 1537, 1537, -4917.702, -1250.291, 501.7428, 2.687807, 0, 0, 0, 0, 0, 0, 0, 1, 3527, 3527, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+102, 15663, 0, 1537, 1537, -4903.872, -1225.961, 501.6536, 1.062359, 14.56239, 1, 0, 0, 0, 0, 0, 1, 15599, 15599, 0, 1, 1, 55, 30, 0, 0, 2048, 0, 4775, 4775, 0, 0, 0, 69, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+106, 15455, 0, 1537, 1537, -4938.002, -1275.12, 501.752, 2.460914, 0, 0, 0, 0, 0, 0, 0, 1, 15457, 15457, 0, 1, 0, 875, 56, 1, 0, 2048, 0, 13495, 13495, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 6228, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+105, 15735, 0, 1537, 1537, -4934.985, -1214.309, 501.7179, 3.333579, 0, 0, 0, 0, 0, 0, 0, 1, 15719, 15719, 0, 1, 1, 12, 55, 3, 0, 2048, 0, 2614, 2614, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.208, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+109, 15456, 0, 1537, 1537, -4940.392, -1277.704, 501.7544, 1.989675, 0, 0, 0, 0, 0, 0, 0, 1, 15458, 15458, 0, 1, 1, 875, 58, 1, 0, 2048, 0, 14355, 14355, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+107, 15457, 0, 1537, 1537, -4933.803, -1279.162, 501.7495, 2.426008, 0, 0, 0, 0, 0, 0, 0, 1, 15459, 15459, 0, 1, 1, 80, 60, 1, 0, 2048, 0, 15260, 15260, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 5258, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+110, 15663, 0, 1537, 1537, -4937.826, -1280.138, 501.6709, 1.459022, 14.74881, 1, 0, 0, 0, 0, 0, 1, 15597, 15597, 0, 1, 0, 55, 30, 0, 0, 2048, 0, 4775, 4775, 0, 0, 0, 69, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+104, 2695, 0, 1537, 1537, -4924.317, -1215.646, 502.5935, 3.874631, 0, 0, 0, 0, 0, 0, 0, 1, 1670, 1670, 0, 1, 1, 55, 15, 2, 512, 2048, 0, 328, 328, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 2714, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+98, 5595, 0, 1537, 1537, -4912.534, -1240.42, 501.7428, 2.670354, 0, 0, 0, 0, 0, 0, 0, 1, 3524, 3524, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+113, 15663, 0, 1537, 1537, -4944.852, -1277.703, 501.7559, 3.211406, 0, 1, 0, 0, 0, 0, 0, 1, 15597, 15597, 0, 1, 0, 55, 30, 0, 0, 2048, 0, 4775, 4775, 0, 0, 0, 69, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+108, 5122, 0, 1537, 1537, -4921.134, -1280.97, 512.044, 5.8294, 0, 0, 0, 0, 0, 0, 0, 1, 3077, 3077, 0, 1, 0, 55, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 5262, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+111, 5123, 0, 1537, 1537, -4913.433, -1284.47, 505.3769, 4.206244, 0, 0, 0, 0, 0, 0, 0, 1, 5408, 5408, 0, 1, 1, 55, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+100, 15431, 0, 1537, 1537, -4914.172, -1227.495, 501.7328, 3.595378, 0, 0, 0, 0, 0, 0, 0, 1, 15442, 15442, 0, 1, 0, 12, 58, 1, 0, 2048, 0, 14355, 14355, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 1899, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+103, 15432, 0, 1537, 1537, -4930.287, -1218.748, 501.7188, 3.752458, 0, 0, 0, 0, 0, 0, 0, 1, 15443, 15443, 0, 1, 1, 55, 60, 1, 0, 2048, 0, 15260, 15260, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+123, 5140, 0, 1537, 1537, -4969.116, -1284.818, 510.3862, 0.9948376, 0, 0, 0, 0, 0, 0, 0, 1, 3065, 3065, 0, 1, 1, 55, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 2703, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+114, 15731, 0, 1537, 1537, -4935.174, -1197.698, 501.622, 2.460914, 0, 0, 0, 0, 0, 0, 0, 1, 15708, 15708, 0, 1, 1, 80, 55, 3, 0, 2048, 0, 2614, 2614, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+124, 5595, 0, 1537, 1537, -4982.469, -1216.806, 501.7562, 3.874631, 0, 0, 0, 0, 0, 0, 0, 1, 3527, 3527, 0, 1, 0, 57, 55, 0, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+128, 15733, 0, 1537, 1537, -4952.526, -1176.974, 501.6392, 5.393067, 0, 0, 0, 0, 0, 0, 0, 1, 15712, 15712, 0, 1, 1, 875, 55, 3, 0, 2048, 0, 2614, 2614, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+127, 15734, 0, 1537, 1537, -4975.337, -1196.757, 501.7459, 1.884956, 0, 0, 0, 0, 0, 0, 0, 1, 15714, 15714, 0, 1, 0, 55, 55, 3, 0, 2048, 0, 2614, 2614, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+122, 15539, 0, 1537, 1537, -4981.252, -1218.378, 501.7562, 3.804818, 0, 0, 0, 0, 0, 0, 0, 1, 15548, 15548, 14575, 1, 0, 35, 60, 1, 0, 2048, 0, 15260, 15260, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.385714, 1, 1, 1, 1, 1, 0.4092, 1.65, 1, 2000, 2000, 17383, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+129, 5570, 0, 1537, 1537, -4975.229, -1286.968, 502.0527, 0.9599311, 0, 0, 0, 0, 0, 0, 0, 1, 3458, 3458, 0, 1, 0, 55, 50, 128, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 3361, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+121, 5595, 0, 1537, 1537, -4980.02, -1219.984, 501.7563, 3.822271, 0, 0, 0, 0, 0, 0, 0, 1, 3526, 3526, 0, 1, 0, 57, 55, 0, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+118, 1246, 0, 1537, 1537, -4863.043, -1238.05, 501.8069, 2.199115, 0, 0, 0, 0, 0, 0, 0, 1, 10635, 10635, 0, 1, 0, 55, 30, 17, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+117, 5177, 0, 1537, 1537, -4863.042, -1240.297, 501.8069, 3.752458, 0, 0, 0, 0, 0, 0, 0, 1, 3124, 3124, 0, 1, 1, 875, 35, 1, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 2716, 3695, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+120, 5178, 0, 1537, 1537, -4856.877, -1237.258, 501.8069, 0.5235988, 0, 0, 0, 0, 0, 0, 0, 1, 3125, 3125, 0, 1, 1, 875, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 2200, 3695, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+126, 5595, 0, 1537, 1537, -4988.808, -1232.078, 501.769, 0.7853982, 0, 0, 0, 0, 0, 0, 0, 1, 3526, 3526, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+119, 5595, 0, 1537, 1537, -4941.848, -1185.65, 501.6834, 0.6994009, 74.18708, 2, 0, 0, 0, 0, 0, 1, 3526, 3526, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+115, 15434, 0, 1537, 1537, -4952.255, -1274.449, 501.7566, 1.797689, 0, 0, 0, 0, 0, 0, 0, 1, 15445, 15445, 0, 1, 0, 875, 56, 1, 0, 2048, 0, 13495, 13495, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 1896, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+125, 5605, 0, 1537, 1537, -4974.749, -1283.125, 502.0532, 4.171337, 0, 0, 0, 0, 0, 0, 0, 1, 3591, 3591, 0, 1, 1, 55, 30, 0, 0, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.208, 1.5, 1, 2000, 2000, 2147, 1984, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+116, 15437, 0, 1537, 1537, -4945.42, -1282.021, 501.7579, 1.029744, 0, 0, 0, 0, 0, 0, 0, 1, 15447, 15447, 0, 1, 0, 80, 58, 1, 0, 2048, 0, 14355, 14355, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.389, 1.5, 1, 2000, 2000, 21121, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+139, 15446, 0, 1537, 1537, -4972.202, -1169.059, 501.72, 3.281219, 0, 0, 0, 0, 0, 0, 0, 1, 15450, 15450, 0, 1, 1, 55, 56, 1, 0, 2048, 0, 13495, 13495, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 2184, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+134, 15448, 0, 1537, 1537, -4966.094, -1176.06, 501.7426, 3.298672, 0, 0, 0, 0, 0, 0, 0, 1, 15451, 15451, 0, 1, 0, 12, 58, 1, 0, 2048, 0, 14355, 14355, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 12890, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+133, 15450, 0, 1537, 1537, -4969.457, -1180.242, 501.7428, 3.246312, 0, 0, 0, 0, 0, 0, 0, 1, 15453, 15453, 0, 1, 1, 875, 60, 1, 0, 2048, 0, 15260, 15260, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 5284, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+131, 5595, 0, 1537, 1537, -4995.096, -1224.346, 501.769, 0.715585, 0, 0, 0, 0, 0, 0, 0, 1, 3527, 3527, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+146, 5116, 0, 1537, 1537, -5010.387, -1274.048, 507.8349, 2.268928, 0, 0, 0, 0, 0, 0, 0, 1, 3072, 3072, 0, 1, 0, 55, 50, 51, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 2552, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+145, 9984, 0, 1537, 1537, -5010.221, -1261.459, 507.8394, 3.769911, 0, 0, 0, 0, 0, 0, 0, 1, 9258, 9258, 0, 1, 0, 55, 30, 4194304, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+141, 5117, 0, 1537, 1537, -5006.603, -1266.038, 507.8369, 3.787364, 0, 0, 0, 0, 0, 0, 0, 1, 3073, 3073, 0, 1, 0, 55, 40, 49, 512, 2048, 0, 1753, 1753, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 2552, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+138, 5569, 0, 1537, 1537, -4850.698, -1295.238, 501.9512, 1.396263, 0, 0, 0, 0, 0, 0, 0, 1, 3457, 3457, 0, 1, 0, 875, 40, 128, 512, 2048, 0, 1753, 1753, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 4994, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+142, 7937, 0, 1537, 1537, -4827.627, -1257.16, 506.1186, 4.572762, 0, 0, 0, 0, 0, 0, 0, 1, 7006, 7006, 0, 1, 0, 64, 63, 2, 64, 2048, 0, 666200, 666200, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.42228, 2.07, 1, 2000, 2000, 1911, 11587, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+137, 7944, 0, 1537, 1537, -4834.773, -1263.453, 501.9512, 4.729842, 0, 0, 0, 0, 0, 0, 0, 1, 7028, 7028, 0, 1, 0, 64, 57, 67, 512, 2048, 0, 3758, 3758, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 1903, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+135, 6569, 0, 1537, 1537, -4835.974, -1260.582, 501.9512, 4.555309, 0, 0, 0, 0, 0, 0, 0, 1, 5377, 5377, 0, 1, 0, 55, 20, 2, 512, 2048, 0, 484, 484, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+143, 5137, 0, 1537, 1537, -4881.243, -1155.519, 505.8533, 5.340707, 0, 0, 0, 0, 0, 0, 0, 1, 3063, 3063, 0, 1, 1, 55, 35, 16, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 1908, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+147, 7950, 0, 1537, 1537, -4823.045, -1265.699, 501.9512, 4.607669, 0, 0, 0, 0, 0, 0, 0, 1, 7041, 7041, 0, 1, 0, 875, 57, 2, 512, 2048, 0, 3758, 3758, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 1903, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+148, 5138, 0, 1537, 1537, -4883.197, -1149.063, 505.8532, 5.305801, 0, 0, 0, 0, 0, 0, 0, 1, 3064, 3064, 0, 1, 1, 55, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 2707, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+136, 4081, 0, 1537, 1537, -4842.957, -1283.511, 501.9512, 1.553343, 0, 0, 0, 0, 0, 0, 0, 1, 2184, 2184, 0, 1, 0, 875, 29, 2, 512, 2048, 0, 950, 950, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+144, 5595, 0, 1537, 1537, -5001.827, -1199.476, 501.6689, 5.182424, 83.91091, 2, 0, 0, 0, 0, 0, 1, 3527, 3527, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+130, 15701, 0, 1537, 1537, -4968.452, -1184.254, 501.6581, 2.2686, 79.56121, 2, 0, 0, 0, 0, 0, 1, 15662, 15662, 14347, 1, 0, 55, 60, 3, 0, 2048, 0, 30520, 30520, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.385714, 1, 1, 1, 1, 1, 0.3817, 1.65, 1, 2000, 2000, 21286, 0, 0, 0, 0, '', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+132, 5124, 0, 1537, 1537, -4991.916, -1213.94, 501.6779, 5.397577, 73.51977, 2, 0, 0, 0, 0, 0, 1, 3078, 3078, 0, 1, 0, 55, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 2196, 0, 0, 0, 0, '', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+140, 15663, 0, 1537, 1537, -4969.639, -1166.74, 501.6364, 6.142398, 8.289452, 1, 0, 0, 0, 0, 0, 1, 15599, 15599, 0, 1, 1, 55, 30, 0, 0, 2048, 0, 4775, 4775, 0, 0, 0, 69, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+56, 3083, 1, 1638, 1638, -1201.778, 6.029535, 165.3041, 4.55371, 106.8526, 2, 0, 0, 0, 0, 0, 1, 2140, 2140, 0, 1, 0, 105, 60, 0, 0, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 5288, 0, 0, 0, 0, '', @SNIFFID+0, 35186), --  (possible waypoints or random movement)
(@CGUID+239, 3296, 1, 14, 14, 1387.279, -4379.893, 27.09825, 3.298672, 0, 0, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+240, 3296, 1, 14, 14, 1384.616, -4358.556, 27.09825, 3.385939, 0, 0, 0, 0, 0, 0, 0, 1, 4601, 4601, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+241, 3296, 1, 14, 14, 1390.268, -4368.613, 26.38113, 3.25185, 74.77864, 2, 0, 0, 0, 0, 0, 1, 4601, 4601, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+150, 10090, 0, 1537, 1537, -5022.094, -1273.845, 507.8394, 5.480334, 0, 0, 0, 0, 0, 0, 0, 1, 9338, 9338, 0, 1, 1, 55, 40, 51, 512, 2048, 0, 1753, 1753, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+151, 15102, 0, 1537, 1537, -5030.936, -1269.319, 505.3834, 0.296706, 0, 0, 0, 0, 0, 0, 0, 1, 15255, 15255, 0, 1, 1, 1642, 23, 1048577, 0, 2048, 0, 617, 617, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+152, 15102, 0, 1537, 1537, -5026.13, -1267.754, 505.3834, 3.473205, 0, 0, 0, 0, 0, 0, 0, 1, 15256, 15256, 0, 1, 1, 1642, 22, 1048577, 0, 2048, 0, 573, 573, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+149, 7298, 0, 1537, 1537, -5015.661, -1279.059, 507.8357, 5.340707, 0, 0, 0, 0, 0, 0, 0, 1, 6062, 6062, 0, 1, 0, 55, 45, 0, 512, 2048, 0, 2218, 2218, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 6680, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+154, 14982, 0, 1537, 1537, -5038.579, -1272.526, 510.4077, 2.600541, 0, 0, 0, 0, 0, 0, 0, 1, 15100, 15100, 0, 1, 1, 1514, 61, 1048577, 576, 2048, 0, 157200, 157200, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3366, 1.65, 1, 2000, 2000, 5598, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+153, 857, 0, 1537, 1537, -5038.542, -1266.414, 510.4077, 3.822271, 0, 0, 0, 0, 0, 0, 0, 1, 15114, 15114, 0, 1, 0, 1577, 61, 1048577, 576, 2048, 0, 157200, 157200, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3366, 1.65, 1, 2000, 2000, 2176, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+58, 15105, 1, 1638, 1638, -1328.672, 20.76249, 138.571, 0.7945713, 77.28511, 2, 0, 0, 0, 0, 0, 1, 15250, 15250, 0, 2, 1, 1641, 30, 1, 0, 2048, 0, 852, 852, 852, 852, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186), --  (possible waypoints or random movement)
(@CGUID+57, 15105, 1, 1638, 1638, -1327.235, 19.37166, 138.5522, 0.7945995, 77.96861, 2, 0, 0, 0, 0, 0, 1, 15250, 15250, 0, 2, 1, 1641, 30, 1, 0, 2048, 0, 852, 852, 852, 852, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186), --  (possible waypoints or random movement)
(@CGUID+242, 3296, 1, 14, 14, 1479.385, -4406.25, 25.31873, 0.01745329, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+243, 3296, 1, 14, 14, 1481.772, -4427.792, 25.31874, 0.1919862, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+245, 14720, 1, 1637, 1637, 1542.308, -4425.426, 10.92703, 0.5235988, 0, 0, 0, 0, 0, 0, 0, 1, 14732, 14732, 0, 1, 0, 29, 62, 3, 0, 4196352, 0, 647400, 647400, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 2.285714, 1, 1, 1, 1, 1, 0.4092, 1.65, 1, 2000, 2000, 21580, 0, 0, 0, 0, '26341', @SNIFFID+2, 35186),
(@CGUID+244, 14392, 1, 1637, 1637, 1567.993, -4405.871, 8.051704, 3.316126, 0, 0, 0, 0, 0, 0, 0, 1, 14429, 14429, 0, 1, 0, 29, 60, 3, 0, 4196352, 0, 48832, 48832, 0, 0, 4194304, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.4092, 1.65, 1, 2000, 2000, 18419, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+66, 3025, 1, 1638, 1638, -1182.531, -29.266, 164.5613, 3.525565, 0, 0, 0, 0, 0, 0, 0, 1, 2111, 2111, 0, 1, 1, 104, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 2196, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+61, 3026, 1, 1638, 1638, -1219.571, -12.69732, 165.9453, 5.375614, 0, 0, 0, 0, 0, 0, 0, 1, 2107, 2107, 0, 1, 1, 104, 45, 81, 512, 2048, 0, 2218, 2218, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 2196, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+62, 3027, 1, 1638, 1638, -1214.992, -15.53396, 166.0533, 4.729842, 0, 0, 0, 0, 0, 0, 0, 1, 2095, 2095, 0, 1, 0, 104, 40, 128, 512, 2048, 0, 1753, 1753, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 5278, 2081, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+70, 11071, 1, 1638, 1638, -1117.908, 51.01318, 141.18, 5.375614, 0, 0, 0, 0, 0, 0, 0, 1, 10614, 10614, 0, 1, 0, 104, 21, 17, 512, 2048, 0, 531, 531, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12742, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+68, 3012, 1, 1638, 1638, -1119.672, 47.10281, 141.5279, 4.782202, 0, 0, 0, 0, 0, 0, 0, 1, 2118, 2118, 0, 1, 1, 104, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 1906, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+69, 3017, 1, 1638, 1638, -1145.67, 22.57086, 145.3632, 0.9075712, 0, 0, 0, 0, 0, 0, 0, 1, 2117, 2117, 0, 1, 1, 104, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 2184, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+63, 3019, 1, 1638, 1638, -1248.228, -47.73736, 164.3637, 1.797689, 0, 0, 0, 0, 0, 0, 0, 1, 2084, 2084, 0, 1, 0, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 10611, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+64, 3020, 1, 1638, 1638, -1255.63, -38.53662, 164.3637, 6.161012, 0, 0, 0, 0, 0, 0, 0, 1, 2085, 2085, 0, 1, 0, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 9659, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+65, 3021, 1, 1638, 1638, -1244.07, -36.34885, 164.3637, 3.857178, 0, 0, 0, 0, 0, 0, 0, 1, 2089, 2089, 0, 1, 0, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 10878, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+60, 8398, 1, 1638, 1638, -1250.063, -35.40218, 164.3637, 4.974188, 0, 0, 0, 0, 0, 0, 0, 1, 10689, 10689, 0, 1, 0, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12889, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+71, 3084, 1, 1638, 1638, -1128.43, 66.57938, 143.3426, 4.380776, 0, 0, 0, 0, 0, 0, 0, 1, 8572, 8572, 0, 1, 1, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+67, 3022, 1, 1638, 1638, -1188.963, -1.302897, 165.5629, 3.001966, 0, 0, 0, 0, 0, 0, 0, 1, 2124, 2124, 0, 1, 1, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 5277, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+59, 3023, 1, 1638, 1638, -1232.86, -21.83941, 164.95, 5.72468, 0, 0, 0, 0, 0, 0, 0, 1, 2125, 2125, 0, 1, 1, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 1907, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+74, 3084, 1, 1638, 1638, -1118.812, 64.69927, 141.1743, 4.433136, 0, 0, 0, 0, 0, 0, 0, 1, 9391, 9391, 0, 1, 0, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+73, 3013, 1, 1638, 1638, -1131.185, -4.708713, 143.6437, 0.08726646, 0, 0, 0, 0, 0, 0, 0, 1, 2091, 2091, 0, 1, 0, 104, 35, 16, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 1907, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+72, 3014, 1, 1638, 1638, -1125.351, -0.686252, 143.7774, 5.235988, 0, 0, 0, 0, 0, 0, 0, 1, 2119, 2119, 0, 1, 1, 104, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 6233, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+76, 3024, 1, 1638, 1638, -1177.366, -48.4012, 162.7548, 3.351032, 0, 0, 0, 0, 0, 0, 0, 1, 2097, 2097, 0, 1, 0, 104, 30, 0, 768, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12801, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+75, 4721, 1, 1638, 1638, -1207.747, -57.03939, 158.6008, 4.747295, 0, 0, 0, 0, 0, 0, 0, 1, 2738, 2738, 0, 1, 0, 104, 25, 2, 512, 2048, 0, 713, 713, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 13337, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+77, 3011, 1, 1638, 1638, -1110.881, 47.89507, 140.5212, 5.288348, 0, 0, 0, 0, 0, 0, 0, 1, 2101, 2101, 0, 1, 0, 104, 35, 1, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 13061, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+248, 3313, 1, 1637, 1637, 1520.537, -4355.584, 18.85088, 6.021386, 0, 0, 0, 0, 0, 0, 0, 1, 1313, 1313, 0, 1, 0, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 1906, 12745, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+247, 3296, 1, 1637, 1637, 1523.92, -4429.439, 16.73491, 0.5061455, 0, 0, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+249, 5817, 1, 1637, 1637, 1522.303, -4352.535, 18.90473, 5.480334, 0, 0, 0, 0, 0, 0, 0, 1, 4356, 4356, 0, 1, 1, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 1910, 2081, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+246, 3296, 1, 1637, 1637, 1518.152, -4425.354, 18.79862, 1.27409, 0, 0, 0, 0, 0, 0, 0, 1, 4601, 4601, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+78, 3029, 1, 1638, 1638, -1177.187, -65.616, 162.3122, 4.433136, 0, 0, 0, 0, 0, 0, 0, 1, 2120, 2120, 0, 1, 1, 104, 40, 128, 512, 2048, 0, 1753, 1753, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 1117, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+79, 3084, 1, 1638, 1638, -1112.912, -11.73009, 142.6063, 2.042035, 0, 0, 0, 0, 0, 0, 0, 1, 2141, 2141, 0, 1, 0, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+80, 3028, 1, 1638, 1638, -1172.761, -69.23318, 162.2841, 3.263766, 0, 0, 0, 0, 0, 0, 0, 1, 2088, 2088, 0, 1, 0, 104, 45, 81, 512, 2048, 0, 2218, 2218, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 6229, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+82, 3084, 1, 1638, 1638, -1106.718, 61.19081, 140.764, 3.947931, 63.64552, 2, 0, 0, 0, 0, 0, 1, 9391, 9391, 0, 1, 0, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186), --  (possible waypoints or random movement)
(@CGUID+81, 3084, 1, 1638, 1638, -1103.651, -9.826444, 142.362, 1.850049, 0, 0, 0, 0, 0, 0, 0, 1, 2141, 2141, 0, 1, 0, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+155, 2043, 0, 1537, 1537, -5009.69, -1261.765, 507.756, 4.752738, 198.6615, 2, 1, 0, 1, 1, 0, 1, 14318, 14318, 0, 1, 2, 4, 34, 0, 8, 2048, 0, 100, 100, 100, 100, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.7343644, 1.385593, 1, 1400, 1400, 0, 0, 0, 0, 0, '8875', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+83, 15164, 1, 1638, 1638, -1224.261, -70.93924, 161.0177, 4.834562, 0, 0, 0, 0, 0, 0, 0, 1, 11686, 11686, 0, 1, 2, 114, 60, 0, 33555200, 2048, 0, 4120, 4120, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.5, 1, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+250, 173758, 1, 1637, 1637, 1565.634, -4406.391, 7.996006, 0, 0, 0, 0, 1, 0, 0, 0, 1, 15435, 15435, 0, 1, 2, 29, 60, 0, 33555200, 2048, 0, 4120, 4120, 0, 0, 0, 0, 0, 0, 1, 0, 0, 512, 1, 0.9920629, 1, 1, 1, 1, 1, 0.39, 0, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+251, 3296, 1, 1637, 1637, 1537.405, -4380.752, 16.7599, 3.420845, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+257, 3317, 1, 1637, 1637, 1583.802, -4473.314, 7.812714, 3.700098, 0, 0, 0, 0, 0, 0, 0, 1, 1317, 1317, 0, 1, 0, 29, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+260, 3319, 1, 1637, 1637, 1593.544, -4465.647, 7.751027, 2.391101, 0, 0, 0, 0, 0, 0, 0, 1, 1319, 1319, 0, 1, 1, 29, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 1985, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+259, 3321, 1, 1637, 1637, 1589.021, -4469.478, 7.748639, 2.076942, 0, 0, 0, 0, 0, 0, 0, 1, 1321, 1321, 0, 1, 0, 29, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+253, 3296, 1, 1637, 1637, 1576.204, -4394.433, 6.555048, 4.572762, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+255, 3296, 1, 1637, 1637, 1561.793, -4360.498, 1.194546, 4.852015, 0, 0, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+261, 3296, 1, 1637, 1637, 1603.479, -4449.948, 8.116498, 2.391101, 0, 0, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+256, 3296, 1, 1637, 1637, 1596.646, -4388.667, 9.983233, 5.986479, 0, 0, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+254, 3296, 1, 1637, 1637, 1557.742, -4364.247, 1.079711, 0.2268928, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+252, 5597, 1, 1637, 1637, 1568.654, -4386.243, 5.395496, 3.036873, 0, 0, 0, 0, 0, 0, 0, 1, 3546, 3546, 0, 1, 0, 29, 38, 0, 512, 2048, 0, 1604, 1604, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5287, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+258, 5603, 1, 1637, 1637, 1594.382, -4378.3, 9.699944, 3.455752, 0, 0, 0, 0, 0, 0, 0, 1, 3564, 3564, 0, 1, 1, 29, 38, 0, 512, 2048, 0, 1604, 1604, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5287, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+262, 3296, 1, 1637, 1637, 1552.415, -4324.754, 21.80293, 5.51524, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+263, 13842, 1, 1637, 1637, 1607.919, -4376.444, 9.657358, 4.066617, 0, 0, 0, 0, 0, 0, 0, 1, 13843, 13843, 0, 1, 1, 1215, 60, 2, 0, 2048, 0, 3052, 3052, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 13339, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+265, 1860, 1, 1637, 1637, 1615.905, -4375.98, 12.31633, 1.232799, 0, 0, 0, 0, 1, 1, 0, 1, 1132, 1132, 0, 2, 2, 2, 52, 0, 8, 2048, 0, 100, 100, 1481, 1481, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8, 2, 1, 2000, 2000, 0, 0, 0, 0, 0, '18727 18735 18742', @SNIFFID+2, 35186),
(@CGUID+266, 3296, 1, 1637, 1637, 1615.635, -4376.113, 12.4018, 4.24115, 0, 0, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+264, 6929, 1, 1637, 1637, 1633.986, -4439.369, 15.51666, 2.75762, 0, 0, 0, 0, 0, 0, 0, 1, 5706, 5706, 0, 1, 1, 29, 30, 65539, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 6334, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+268, 5606, 1, 1637, 1637, 1634.163, -4447.176, 15.48982, 1.64061, 0, 0, 0, 0, 0, 0, 0, 1, 3604, 3604, 0, 1, 0, 29, 12, 0, 512, 2048, 0, 247, 247, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2703, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+267, 5609, 1, 1637, 1637, 1633.945, -4445.616, 15.48982, 4.869469, 0, 0, 0, 0, 0, 0, 0, 1, 3605, 3605, 0, 1, 0, 29, 14, 0, 512, 2048, 0, 300, 300, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2703, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+269, 6466, 1, 1637, 1637, 1637.523, -4438.055, 15.48982, 2.076942, 0, 0, 0, 0, 0, 0, 0, 1, 5205, 5205, 0, 1, 0, 7, 12, 0, 512, 2048, 0, 247, 247, 0, 0, 0, 0, 8, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+270, 5613, 1, 1637, 1637, 1638.284, -4444.996, 15.48982, 5.585053, 0, 0, 0, 0, 0, 0, 0, 1, 3608, 3608, 0, 1, 0, 126, 11, 0, 512, 2048, 0, 222, 222, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 2703, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+274, 5610, 1, 1637, 1637, 1640.715, -4442.187, 15.48982, 2.96706, 0, 0, 0, 0, 0, 0, 0, 1, 7137, 7137, 0, 1, 0, 29, 12, 0, 512, 2048, 0, 247, 247, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 2703, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+276, 5611, 1, 1637, 1637, 1640.826, -4446.989, 15.48982, 1.972222, 0, 0, 0, 0, 0, 0, 0, 1, 3606, 3606, 0, 1, 0, 29, 13, 128, 512, 2048, 0, 273, 273, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 2551, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+273, 5614, 1, 1637, 1637, 1639.563, -4443.737, 15.48982, 5.183628, 0, 0, 0, 0, 0, 0, 0, 1, 3609, 3609, 0, 1, 0, 29, 25, 0, 512, 2048, 0, 713, 713, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2716, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+271, 3309, 1, 1637, 1637, 1627.317, -4376.068, 11.814, 3.438299, 0, 0, 0, 0, 0, 0, 0, 1, 1310, 1310, 0, 1, 0, 29, 45, 131075, 512, 2048, 0, 5544, 5544, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 12852, 12855, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+275, 3318, 1, 1637, 1637, 1632.387, -4381.969, 11.80029, 3.577925, 0, 0, 0, 0, 0, 0, 0, 1, 1318, 1318, 0, 1, 0, 29, 45, 131073, 512, 2048, 0, 5544, 5544, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 12856, 12859, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+272, 3320, 1, 1637, 1637, 1622.903, -4369.064, 11.80993, 3.577925, 0, 0, 0, 0, 0, 0, 0, 1, 1320, 1320, 0, 1, 0, 29, 45, 131073, 512, 2048, 0, 5544, 5544, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 12850, 12745, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+156, 15663, 0, 1537, 1537, -4978.268, -1152.801, 501.6557, 2.854714, 10.82954, 0, 0, 0, 0, 0, 0, 1, 15596, 15596, 0, 1, 0, 55, 30, 0, 0, 2048, 0, 4775, 4775, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+278, 15105, 1, 1637, 1637, 1658.863, -4389.012, 23.76944, 1.134464, 0, 0, 0, 0, 0, 0, 0, 1, 15249, 15249, 0, 2, 1, 1641, 30, 1, 0, 2048, 0, 852, 852, 852, 852, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+277, 3314, 1, 1637, 1637, 1634.229, -4347.62, 4.379599, 2.6529, 0, 0, 0, 0, 0, 0, 0, 1, 1314, 1314, 0, 1, 0, 29, 30, 4225, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 10611, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+84, 3083, 1, 1638, 1638, -1213.668, -107.0814, 162.9737, 1.64061, 0, 0, 0, 0, 0, 0, 0, 1, 2140, 2140, 0, 1, 0, 105, 60, 0, 0, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 5288, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+87, 3084, 1, 1638, 1638, -1234.989, -94.87533, 163.5264, 0.4363323, 0, 0, 0, 0, 0, 0, 0, 1, 9391, 9391, 0, 1, 0, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+86, 3084, 1, 1638, 1638, -1239.263, -86.02843, 162.9738, 0.5934119, 0, 0, 0, 0, 0, 0, 0, 1, 8572, 8572, 0, 1, 1, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+88, 3018, 1, 1638, 1638, -1247.132, -63.11442, 162.9738, 0.1396263, 0, 0, 0, 0, 0, 0, 0, 1, 2086, 2086, 0, 1, 0, 104, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 0, 0, 2552, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+90, 3084, 1, 1638, 1638, -1177.854, -89.2105, 162.7256, 2.548181, 0, 0, 0, 0, 0, 0, 0, 1, 8572, 8572, 0, 1, 1, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+85, 3083, 1, 1638, 1638, -1205.456, -107.777, 162.9738, 1.500983, 0, 0, 0, 0, 0, 0, 0, 1, 2140, 2140, 0, 1, 0, 105, 60, 0, 0, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 5288, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+89, 3084, 1, 1638, 1638, -1183.259, -97.20426, 162.7397, 2.146755, 0, 0, 0, 0, 0, 0, 0, 1, 9391, 9391, 0, 1, 0, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+279, 9696, 1, 1637, 1637, 1666.926, -4411.485, 17.56216, 4.942255, 0, 0, 0, 0, 1, 1, 0, 1, 741, 741, 0, 1, 2, 116, 60, 0, 8, 2048, 0, 100, 100, 100, 100, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 1, 1.25, 1, 1500, 1500, 0, 0, 0, 0, 0, '21927 20906 8875 17223 19580 19581 19582 19589 19591 20782 20784 24445 24497 24507 24502 4189', @SNIFFID+2, 35186),
(@CGUID+281, 15105, 1, 1637, 1637, 1660.665, -4385.633, 23.97983, 4.118977, 0, 0, 0, 0, 0, 0, 0, 1, 15248, 15248, 0, 2, 0, 1641, 30, 1, 0, 2048, 0, 852, 852, 852, 852, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+280, 10259, 1, 1637, 1637, 1664.696, -4424.776, 17.47737, 2.011237, 41.00268, 2, 0, 0, 1, 0, 15999, 1, 9572, 9572, 0, 1, 2, 6, 1, 0, 776, 2048, 0, 42, 42, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.4, 0.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+283, 14375, 1, 1637, 1637, 1630.485, -4326.688, 1.187435, 3.875676, 50.39468, 2, 0, 0, 0, 0, 0, 1, 14413, 14413, 0, 1, 0, 85, 60, 0, 32768, 2048, 0, 9156, 9156, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 10612, 10612, 0, 0, 0, '18950', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+282, 731, 1, 1637, 1637, 1684.534, -4414.027, 21.77412, 3.589722, 47.28701, 2, 0, 0, 1, 1, 883, 1, 616, 616, 0, 1, 0, 116, 60, 0, 8, 2048, 0, 100, 100, 100, 100, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.8745, 1.65, 1, 1400, 1400, 0, 0, 0, 0, 0, '8875 17210 19580 19581 19582 19589 19591 20782 20784 24630 4192 24439', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+284, 15188, 1, 1637, 1637, 1658.711, -4348.799, 29.25742, 4.39823, 0, 0, 0, 0, 0, 0, 0, 1, 15322, 15322, 0, 8, 0, 994, 55, 2, 0, 2048, 0, 1830, 1830, 5013, 5013, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+285, 3312, 1, 1637, 1637, 1618.961, -4307.285, 3.190289, 5.410521, 0, 0, 0, 0, 0, 0, 0, 1, 1312, 1312, 0, 1, 1, 29, 50, 128, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 2827, 2196, 2551, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+287, 15105, 1, 1637, 1637, 1667.639, -4346.96, 61.32949, 2.373648, 0, 0, 0, 0, 0, 0, 0, 1, 15249, 15249, 0, 2, 1, 1641, 30, 1, 0, 2048, 0, 852, 852, 852, 852, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+286, 15105, 1, 1637, 1637, 1665.836, -4344.939, 61.32949, 5.375614, 0, 0, 0, 0, 0, 0, 0, 1, 15248, 15248, 0, 2, 0, 1641, 30, 1, 0, 2048, 0, 852, 852, 852, 852, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+289, 14377, 1, 1637, 1637, 1695.918, -4378.58, 24.74563, 0.362366, 343.0448, 2, 0, 0, 0, 0, 0, 1, 14415, 14415, 0, 1, 0, 85, 60, 0, 32768, 2048, 0, 9156, 9156, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 10612, 10612, 0, 0, 0, '18950', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+288, 3322, 1, 1637, 1637, 1692.694, -4412.032, 21.70186, 3.892084, 0, 0, 0, 0, 0, 0, 0, 1, 1322, 1322, 0, 1, 1, 29, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 1.047, 4.5, 1, 2000, 2000, 0, 0, 2552, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+290, 417, 1, 1637, 1637, 1671.543, -4458.97, 18.83848, 5.102377, 14.78222, 1, 0, 0, 1, 1, 0, 1, 850, 850, 0, 2, 2, 2, 60, 0, 8, 2048, 0, 100, 100, 1874, 1874, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.2429, 1.05, 1, 2000, 2000, 0, 0, 0, 0, 0, '19480 18730 18738 18739 19007', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+291, 8724, 1, 1637, 1637, 1667.619, -4463.757, 20.14751, 1.710423, 0, 0, 0, 0, 0, 0, 0, 1, 8000, 8000, 0, 1, 0, 29, 50, 2097152, 0, 2048, 0, 6645, 6645, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+295, 3296, 1, 1637, 1637, 1668.558, -4323.664, 61.3295, 5.969026, 0, 0, 0, 0, 0, 0, 0, 1, 4601, 4601, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+293, 5188, 1, 1637, 1637, 1579.356, -4294.5, 26.10461, 3.752458, 0, 0, 0, 0, 0, 0, 0, 1, 3128, 3128, 0, 1, 1, 29, 30, 524416, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5284, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+292, 417, 1, 1637, 1637, 1682.922, -4446.798, 18.98325, 1.733305, 0, 0, 0, 0, 1, 1, 0, 1, 850, 850, 0, 2, 2, 5, 60, 0, 8, 2048, 0, 100, 100, 1874, 1874, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.2429, 1.05, 1, 2000, 2000, 0, 0, 0, 0, 0, '19480 18730 18738 18739 19007', @SNIFFID+2, 35186),
(@CGUID+294, 9696, 1, 1637, 1637, 1685.238, -4345.681, 62.02935, 4.159127, 99.8684, 2, 0, 0, 1, 1, 0, 1, 9562, 9562, 0, 1, 2, 2, 60, 0, 8, 2048, 0, 100, 100, 100, 100, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 1, 1.25, 1, 1500, 1500, 0, 0, 0, 0, 0, '21927 20906 8875 17223 19580 19581 19582 19589 19591 20782 20784 24445 24507 4190', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+95, 3083, 1, 1638, 1638, -1217.523, -126.2814, 163.882, 1.291544, 0, 0, 0, 0, 0, 0, 0, 1, 2140, 2140, 0, 1, 0, 105, 60, 0, 0, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 5288, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+94, 3083, 1, 1638, 1638, -1233.045, -121.4936, 163.882, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2140, 2140, 0, 1, 0, 105, 60, 0, 0, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 5288, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+93, 3057, 1, 1638, 1638, -1209.638, -112.6983, 163.882, 1.570796, 0, 0, 0, 0, 0, 0, 0, 1, 4307, 4307, 0, 1, 0, 104, 63, 3, 64, 2048, 0, 999300, 999300, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 1.16964, 4.860001, 1, 2000, 2000, 14084, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+91, 8401, 1, 1638, 1638, -1256.154, -130.285, 162.9738, 4.433136, 0, 0, 0, 0, 0, 0, 0, 1, 7629, 7629, 0, 1, 0, 104, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12329, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+96, 3083, 1, 1638, 1638, -1203.351, -127.2139, 163.882, 1.64061, 0, 0, 0, 0, 0, 0, 0, 1, 2140, 2140, 0, 1, 0, 105, 60, 0, 0, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 5288, 0, 0, 0, 0, '', @SNIFFID+0, 35186),
(@CGUID+92, 12383, 1, 1638, 1638, -1252.41, -131.0989, 162.8904, 5.069962, 0.6432049, 1, 0, 0, 0, 0, 0, 1, 1072, 1072, 0, 1, 2, 31, 1, 0, 768, 2048, 0, 8, 8, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0.8571429, 1, 1, 1, 1, 1, 0.122, 1, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+0, 35186), --  (possible waypoints or random movement)
(@CGUID+296, 772, 1, 1637, 1637, 1664.257, -4388.93, 23.38066, 0, 3.059874, 1, 0, 0, 1, 1, 23498, 1, 614, 614, 0, 1, 2, 2, 60, 0, 8, 2048, 0, 100, 100, 26, 100, 4194304, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8745, 1.65, 1, 1300, 1300, 0, 0, 0, 0, 0, '8875 17210 19580 19581 19582 19589 19591 20782 20784 24504 4194', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+97, 3084, 1, 1638, 1638, -1242.883, -150.7009, 162.9176, 5.963224, 0, 1, 0, 0, 0, 0, 0, 1, 9391, 9391, 0, 1, 0, 105, 55, 1, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+0, 35186), --  (possible waypoints or random movement)
(@CGUID+301, 3296, 1, 1637, 1637, 1688.527, -4474.579, 20.15368, 1.954769, 0, 0, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+297, 3296, 1, 1637, 1637, 1672.278, -4473.198, 20.15369, 1.448623, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+300, 3296, 1, 1637, 1637, 1696.024, -4463.707, 20.1522, 2.391101, 0, 0, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+299, 8673, 1, 1637, 1637, 1687.257, -4464.714, 20.14757, 2.007129, 0, 0, 0, 0, 0, 0, 0, 1, 8001, 8001, 0, 1, 0, 29, 50, 2097152, 0, 2048, 0, 6645, 6645, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+298, 9856, 1, 1637, 1637, 1695.919, -4455.554, 20.14748, 2.007129, 0, 0, 0, 0, 0, 0, 0, 1, 9133, 9133, 0, 1, 0, 29, 50, 2097152, 0, 2048, 0, 6645, 6645, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+302, 3310, 1, 1637, 1637, 1676.252, -4313.452, 61.71756, 5.253441, 0, 0, 0, 0, 0, 0, 0, 1, 1311, 1311, 0, 1, 0, 29, 55, 8195, 512, 2048, 0, 7842, 7842, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 3433, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+303, 4949, 1, 1637, 1637, 1920.07, -4125.685, 42.99758, 4.799655, 0, 0, 0, 0, 0, 0, 0, 1, 4527, 4527, 0, 2, 0, 125, 63, 3, 64, 4196352, 0, 799500, 799500, 39300, 39300, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.4464, 1.8, 1, 2000, 2000, 12183, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+159, 15451, 0, 1537, 1537, -4971.575, -1151.557, 501.7394, 3.560472, 0, 0, 0, 0, 0, 0, 0, 1, 15454, 15454, 0, 1, 1, 80, 56, 1, 0, 2048, 0, 13495, 13495, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 5598, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+160, 5150, 0, 1537, 1537, -4876.625, -1149.139, 512.5201, 3.577925, 0, 0, 0, 0, 0, 0, 0, 1, 3068, 3068, 0, 1, 1, 55, 35, 83, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+157, 15452, 0, 1537, 1537, -4979.116, -1149.51, 501.7331, 3.368485, 0, 0, 0, 0, 0, 0, 0, 1, 15455, 15455, 0, 1, 1, 12, 58, 1, 0, 2048, 0, 14355, 14355, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.208, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+158, 15453, 0, 1537, 1537, -4979.929, -1142.171, 501.7428, 3.682645, 0, 0, 0, 0, 0, 0, 0, 1, 15456, 15456, 0, 1, 0, 80, 60, 1, 0, 2048, 0, 15260, 15260, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.389, 1.5, 1, 2000, 2000, 1907, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+305, 3296, 1, 1637, 1637, 1714.741, -4329.214, 21.77937, 1.986932, 127.2923, 2, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+304, 7565, 1, 1637, 1637, 1707.056, -4330.635, 22.29125, 2.49081, 0, 0, 0, 0, 1, 0, 10714, 1, 1206, 1206, 0, 1, 2, 2, 1, 0, 33544, 2048, 0, 42, 42, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.35, 0.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+306, 3296, 1, 1637, 1637, 1724.015, -4311.945, 29.18717, 5.037895, 43.98998, 2, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+161, 5119, 0, 1537, 1537, -5034.4, -1205.305, 502.3183, 2.024582, 0, 0, 0, 0, 0, 0, 0, 1, 3075, 3075, 0, 1, 0, 55, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+309, 3329, 1, 1637, 1637, 1766.713, -4367.359, -15.93829, 5.61996, 0, 0, 0, 0, 0, 0, 0, 1, 1329, 1329, 0, 1, 0, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 3346, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+310, 3331, 1, 1637, 1637, 1750.376, -4320.909, 5.994374, 0.8726646, 0, 0, 0, 0, 0, 0, 0, 1, 1331, 1331, 0, 1, 0, 29, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2178, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+307, 3189, 1, 1637, 1637, 1772.716, -4343.18, -7.815777, 0.715585, 0, 0, 0, 0, 0, 0, 0, 1, 4073, 4073, 0, 1, 0, 126, 7, 2, 512, 2048, 0, 137, 137, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 2023, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+308, 3323, 1, 1637, 1637, 1744.899, -4317.858, 33.3935, 4.223697, 0, 0, 0, 0, 0, 0, 0, 1, 1323, 1323, 0, 1, 0, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2200, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+311, 3296, 1, 1637, 1637, 1689.994, -4279.855, 32.13035, 4.118977, 0, 0, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+163, 5120, 0, 1537, 1537, -5037.142, -1206.699, 502.3183, 2.129302, 0, 0, 0, 0, 0, 0, 0, 1, 3057, 3057, 0, 1, 1, 55, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 1899, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+162, 5121, 0, 1537, 1537, -5037.284, -1208.093, 508.9856, 2.146755, 0, 0, 0, 0, 0, 0, 0, 1, 3076, 3076, 0, 1, 0, 55, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 2809, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+313, 3216, 1, 1637, 1637, 1800.665, -4374.515, -17.34753, 4.572762, 0, 0, 0, 0, 0, 0, 0, 1, 3754, 3754, 0, 1, 0, 29, 37, 3, 512, 2048, 0, 1536, 1536, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2559, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+314, 3296, 1, 1637, 1637, 1759.029, -4301.895, 7.01614, 5.462881, 0, 0, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+312, 3296, 1, 1637, 1637, 1775.075, -4319.913, -7.878551, 5.602507, 0, 0, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+315, 3328, 1, 1637, 1637, 1762.876, -4296.377, 7.530856, 5.410521, 0, 0, 0, 0, 0, 0, 0, 1, 1328, 1328, 0, 1, 0, 29, 50, 3, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5278, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+316, 15105, 1, 1637, 1637, 1820.839, -4372.717, -7.808234, 2.178841, 327.8423, 2, 0, 0, 0, 0, 0, 1, 15248, 15248, 0, 2, 0, 1641, 30, 1, 0, 2048, 0, 852, 852, 852, 852, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+317, 15105, 1, 1637, 1637, 1819.206, -4373.871, -8.024653, 2.178816, 330.2963, 2, 0, 0, 0, 0, 0, 1, 15250, 15250, 0, 2, 1, 1641, 30, 1, 0, 2048, 0, 852, 852, 852, 852, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+321, 3296, 1, 1637, 1637, 1817.077, -4357.137, -9.816406, 2.303835, 0, 0, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+318, 3399, 1, 1637, 1637, 1769.164, -4485.63, 45.5038, 1.797689, 0, 0, 0, 0, 0, 0, 0, 1, 2734, 2734, 0, 1, 1, 126, 35, 83, 512, 2048, 0, 1342, 1342, 0, 0, 0, 69, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 2827, 0, 0, 0, 0, '', @SNIFFID+2, 35186);

INSERT INTO `creature` (`guid`, `id`, `map`, `zone_id`, `area_id`, `position_x`, `position_y`, `position_z`, `orientation`, `wander_distance`, `movement_type`, `is_spawn`, `is_hovering`, `is_temporary`, `is_pet`, `summon_spell`, `scale`, `display_id`, `native_display_id`, `mount_display_id`, `class`, `gender`, `faction`, `level`, `npc_flags`, `unit_flags`, `unit_flags2`, `dynamic_flags`, `current_health`, `max_health`, `current_mana`, `max_mana`, `aura_state`, `emote_state`, `stand_state`, `vis_flags`, `sheath_state`, `pvp_flags`, `shapeshift_form`, `move_flags`, `speed_walk`, `speed_run`, `speed_run_back`, `speed_swim`, `speed_swim_back`, `speed_fly`, `speed_fly_back`, `bounding_radius`, `combat_reach`, `mod_melee_haste`, `main_hand_attack_time`, `off_hand_attack_time`, `main_hand_slot_item`, `off_hand_slot_item`, `ranged_slot_item`, `channel_spell_id`, `channel_visual_id`, `auras`, `sniff_id`, `sniff_build`) VALUES
(@CGUID+319, 3400, 1, 1637, 1637, 1779.084, -4488.079, 45.5038, 4.694936, 0, 0, 0, 0, 0, 0, 0, 1, 2735, 2735, 0, 1, 0, 126, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 3351, 4993, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+320, 3368, 1, 1637, 1637, 1775.096, -4482.907, 45.5038, 2.181662, 0, 0, 0, 0, 0, 0, 0, 1, 1390, 1390, 0, 1, 0, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2827, 2196, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+322, 3369, 1, 1637, 1637, 1780.634, -4505.506, 27.60195, 3.769911, 0, 0, 0, 0, 0, 0, 0, 1, 1391, 1391, 0, 1, 0, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 12745, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+166, 7976, 0, 1537, 1537, -5041.101, -1200.227, 502.3179, 0.6283185, 0, 0, 0, 0, 0, 0, 0, 1, 7120, 7120, 0, 1, 0, 55, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 2552, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+168, 1901, 0, 1537, 1537, -5044.874, -1243.064, 507.8366, 5.462881, 0, 0, 0, 0, 0, 0, 0, 1, 3053, 3053, 0, 1, 0, 55, 45, 1, 512, 2048, 0, 2218, 2218, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 1500, 1500, 5286, 1984, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+172, 5113, 0, 1537, 1537, -5047.537, -1269.686, 510.4077, 6.248279, 0, 0, 0, 0, 0, 0, 0, 1, 3054, 3054, 0, 1, 0, 55, 45, 3, 512, 2048, 0, 2218, 2218, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 1500, 1500, 5301, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+164, 5114, 0, 1537, 1537, -5035.671, -1234.642, 507.8347, 5.358161, 0, 0, 0, 0, 0, 0, 0, 1, 3055, 3055, 0, 1, 0, 875, 45, 1, 512, 2048, 0, 2218, 2218, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 1500, 1500, 1897, 2053, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+171, 5115, 0, 1537, 1537, -5043.042, -1274.668, 510.4077, 1.518436, 0, 0, 0, 0, 0, 0, 0, 1, 3056, 3056, 0, 1, 1, 55, 60, 49, 512, 2048, 0, 4120, 4120, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 3433, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+167, 11865, 0, 1537, 1537, -5041.534, -1197.252, 508.9846, 5.270895, 0, 0, 0, 0, 0, 0, 0, 1, 11806, 11806, 0, 1, 0, 55, 50, 17, 0, 2048, 0, 15505, 15505, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 1500, 1500, 14534, 14533, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+170, 12197, 0, 1537, 1537, -5046.109, -1265.851, 510.4077, 5.462881, 0, 0, 0, 0, 0, 0, 0, 1, 12289, 12289, 0, 1, 0, 1216, 61, 1048577, 576, 2048, 0, 157200, 157200, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3817, 1.65, 1, 2000, 2000, 2557, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+169, 15351, 0, 1537, 1537, -5042.524, -1264.576, 510.4077, 4.468043, 0, 0, 0, 0, 0, 0, 0, 1, 15389, 15389, 0, 1, 0, 55, 60, 3, 0, 2048, 0, 30520, 30520, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+165, 13084, 0, 1537, 1537, -5042.057, -1205.558, 508.9006, 0.9773844, 13.89034, 0, 0, 0, 0, 0, 0, 1, 12992, 12992, 0, 1, 1, 55, 50, 17, 0, 2048, 0, 15505, 15505, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 1500, 1500, 5278, 5278, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+173, 6114, 0, 1537, 1537, -5045.53, -1273.094, 510.4077, 0.8377581, 0, 0, 0, 0, 0, 0, 0, 1, 4995, 4995, 0, 1, 0, 55, 50, 2, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 1909, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+176, 5125, 0, 1537, 1537, -5032.96, -1139.377, 505.3961, 3.438299, 0, 0, 0, 0, 0, 0, 0, 1, 3079, 3079, 0, 1, 0, 55, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+174, 5126, 0, 1537, 1537, -5030.412, -1147.296, 512.0629, 2.042035, 0, 0, 0, 0, 0, 0, 0, 1, 3080, 3080, 0, 1, 0, 55, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 11041, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+175, 5129, 0, 1537, 1537, -5033.392, -1146.076, 505.3962, 3.176499, 0, 0, 0, 0, 0, 0, 0, 1, 3106, 3106, 0, 1, 1, 55, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+323, 7010, 1, 1637, 1637, 1837.273, -4469.647, 47.51986, 1.605703, 0, 0, 0, 0, 0, 0, 0, 1, 6839, 6839, 0, 8, 0, 126, 35, 3, 512, 2048, 0, 992, 992, 2680, 2680, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 5303, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+324, 3372, 1, 1637, 1637, 1836.769, -4461.591, 47.45414, 1.500983, 0, 0, 0, 0, 0, 0, 0, 1, 1394, 1394, 0, 1, 0, 29, 30, 0, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+325, 3296, 1, 1637, 1637, 1829.262, -4507.266, 21.4564, 4.956735, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+326, 3364, 1, 1637, 1637, 1792.654, -4565.394, 22.86275, 0.9773844, 0, 0, 0, 0, 0, 0, 0, 1, 1386, 1386, 0, 1, 0, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+328, 3367, 1, 1637, 1637, 1823.914, -4530.412, 20.01482, 0.01459073, 155.841, 2, 0, 0, 0, 0, 0, 1, 1389, 1389, 0, 1, 1, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 2197, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+327, 3371, 1, 1637, 1637, 1843.114, -4468.534, 47.52476, 0.9599311, 0, 0, 0, 0, 0, 0, 0, 1, 1393, 1393, 0, 1, 0, 29, 30, 0, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+330, 14726, 1, 1637, 1637, 1794.684, -4572.714, 22.86275, 0.9250245, 0, 0, 0, 0, 0, 0, 0, 1, 14757, 14757, 0, 1, 1, 29, 35, 3, 0, 2048, 0, 1220, 1220, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+329, 3315, 1, 1637, 1637, 1802.08, -4561.554, 22.86275, 1.518436, 0, 0, 0, 0, 0, 0, 0, 1, 1315, 1315, 0, 1, 0, 29, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 1896, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+332, 3363, 1, 1637, 1637, 1806.853, -4573.324, 22.86275, 1.605703, 0, 0, 0, 0, 0, 0, 0, 1, 1385, 1385, 0, 1, 0, 29, 35, 1, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 1908, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+331, 2855, 1, 1637, 1637, 1813.256, -4563.326, 22.86275, 2.530727, 0, 0, 0, 0, 0, 0, 0, 1, 4384, 4384, 0, 1, 0, 29, 24, 17, 512, 2048, 0, 664, 664, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 12745, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+333, 7088, 1, 1637, 1637, 1849.043, -4569.229, 24.84341, 4.729842, 0, 0, 0, 0, 0, 0, 0, 1, 5846, 5846, 0, 1, 0, 29, 35, 16, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5278, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+335, 3316, 1, 1637, 1637, 1855.819, -4562.491, 24.84341, 2.268928, 0, 0, 0, 0, 0, 0, 0, 1, 1316, 1316, 0, 1, 0, 29, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+334, 3366, 1, 1637, 1637, 1848.012, -4564.891, 24.84341, 1.413717, 0, 0, 0, 0, 0, 0, 0, 1, 1388, 1388, 0, 1, 0, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 3699, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+337, 5811, 1, 1637, 1637, 1855.315, -4568.119, 24.84341, 2.129302, 0, 0, 0, 0, 0, 0, 0, 1, 4350, 4350, 0, 1, 1, 29, 26, 17, 512, 2048, 0, 787, 787, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 2184, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+336, 3365, 1, 1637, 1637, 1860.897, -4561.514, 24.84341, 2.583087, 0, 0, 0, 0, 0, 0, 0, 1, 1387, 1387, 0, 1, 0, 29, 35, 1, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+339, 3296, 1, 1637, 1637, 1882.155, -4483.992, 20.6388, 2.094395, 0, 0, 0, 0, 0, 0, 0, 1, 4601, 4601, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+338, 3296, 1, 1637, 1637, 1889.527, -4485.082, 21.3103, 1.448623, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+340, 3296, 1, 1637, 1637, 1886.196, -4546.68, 28.5148, 1.099557, 0, 0, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+342, 3405, 1, 1637, 1637, 1904.864, -4451.633, 53.27764, 3.682645, 0, 0, 0, 0, 0, 0, 0, 1, 4362, 4362, 0, 1, 1, 126, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 3696, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+341, 3404, 1, 1637, 1637, 1904.761, -4460.687, 53.27764, 2.86234, 0, 0, 0, 0, 0, 0, 0, 1, 4358, 4358, 0, 1, 1, 126, 35, 16, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 6233, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+346, 3296, 1, 1637, 1637, 1923.846, -4474.886, 22.83742, 1.069371, 138.4889, 2, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+343, 3345, 1, 1637, 1637, 1912.182, -4436.606, 24.65537, 2.86234, 0, 0, 0, 0, 0, 0, 0, 1, 1366, 1366, 0, 1, 0, 29, 35, 1, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+347, 3296, 1, 1637, 1637, 1845.492, -4395.949, 5.192642, 3.804818, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+345, 3296, 1, 1637, 1637, 1886.461, -4415.855, 11.71567, 3.769911, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+344, 6987, 1, 1637, 1637, 1928.333, -4517.215, 29.14256, 0.9599311, 0, 0, 0, 0, 0, 0, 0, 1, 5770, 5770, 0, 1, 0, 125, 40, 2, 512, 2048, 0, 1753, 1753, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 1903, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+348, 3296, 1, 1637, 1637, 1906.253, -4564.206, 33.97581, 0.6283185, 0, 0, 0, 0, 0, 0, 0, 1, 4601, 4601, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+349, 3346, 1, 1637, 1637, 1918.263, -4436.256, 24.63019, 1.989675, 0, 0, 0, 0, 0, 0, 0, 1, 1367, 1367, 0, 1, 1, 29, 35, 128, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+352, 3296, 1, 1637, 1637, 1923.984, -4447.801, 44.96836, 0.715585, 0, 0, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+350, 6986, 1, 1637, 1637, 1931.781, -4514.994, 29.14256, 3.403392, 0, 0, 0, 0, 0, 0, 0, 1, 5769, 5769, 0, 1, 0, 29, 45, 2, 512, 2048, 0, 2218, 2218, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 1911, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+351, 11066, 1, 1637, 1637, 1913.247, -4430.543, 24.64769, 3.682645, 0, 0, 0, 0, 0, 0, 0, 1, 10589, 10589, 0, 1, 0, 29, 26, 17, 512, 2048, 0, 787, 787, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 12860, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+177, 14365, 0, 1537, 1537, -5015.144, -1102.373, 501.673, 5.015528, 172.1257, 2, 0, 0, 0, 0, 0, 1, 14404, 14404, 0, 1, 0, 57, 60, 0, 32768, 2048, 0, 9156, 9156, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 11763, 11763, 0, 0, 0, '18950', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+354, 3296, 1, 1637, 1637, 1913.709, -4559.359, 33.97587, 3.717551, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+353, 3296, 1, 1637, 1637, 1912.458, -4564.957, 33.89375, 2.141493, 63.81053, 2, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+355, 3348, 1, 1637, 1637, 1954.746, -4466.788, 25.79164, 3.508112, 0, 0, 0, 0, 0, 0, 0, 1, 1369, 1369, 0, 1, 0, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 69, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2198, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+358, 3347, 1, 1637, 1637, 1964.884, -4477.84, 25.78141, 5.253441, 0, 0, 0, 0, 0, 0, 0, 1, 1368, 1368, 0, 1, 0, 29, 35, 1, 512, 2048, 0, 1342, 1342, 0, 0, 0, 69, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 3699, 3697, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+356, 3296, 1, 1637, 1637, 1902.629, -4628.793, 33.97628, 0.5934119, 0, 0, 0, 0, 0, 0, 0, 1, 4601, 4601, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+357, 3296, 1, 1637, 1637, 1910.24, -4623.916, 33.9762, 3.735005, 0, 0, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+359, 3359, 1, 1637, 1637, 1878.641, -4708.125, 39.35098, 0.5235988, 0, 0, 0, 0, 0, 0, 0, 1, 1381, 1381, 0, 1, 1, 29, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+360, 15105, 1, 1637, 1637, 1937.182, -4707.446, 35.54527, 4.363323, 0, 0, 0, 0, 0, 0, 0, 1, 15248, 15248, 0, 2, 0, 1641, 30, 1, 0, 2048, 0, 852, 852, 852, 852, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+361, 3296, 1, 1637, 1637, 1897.855, -4713.552, 35.0753, 1.131393, 159.8006, 2, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+363, 3333, 1, 1637, 1637, 1995.41, -4662.317, 26.89061, 1.361357, 0, 0, 0, 0, 0, 0, 0, 1, 1333, 1333, 0, 1, 1, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 1117, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+362, 15105, 1, 1637, 1637, 1936.911, -4712.061, 37.1041, 1.186824, 0, 0, 0, 0, 0, 0, 0, 1, 15250, 15250, 0, 2, 1, 1641, 30, 1, 0, 2048, 0, 852, 852, 852, 852, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+364, 3332, 1, 1637, 1637, 2000.62, -4659.656, 26.49537, 5.305801, 0, 0, 0, 0, 0, 0, 0, 1, 1332, 1332, 0, 1, 0, 29, 35, 83, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 1117, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+365, 4485, 1, 1637, 1637, 1953.593, -4735.768, 48.51053, 1.099557, 0, 0, 0, 0, 0, 0, 0, 1, 5535, 5535, 0, 2, 0, 29, 35, 2, 512, 2048, 0, 1110, 1110, 1067, 1067, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2183, 2183, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+366, 3296, 1, 1637, 1637, 1963.01, -4730.905, 48.96085, 2.495821, 0, 0, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+367, 3296, 1, 1637, 1637, 2004.181, -4719.799, 26.29965, 0.9599311, 0, 0, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+368, 3358, 1, 1637, 1637, 2025.084, -4708.906, 26.88646, 1.815142, 0, 0, 0, 0, 0, 0, 0, 1, 1380, 1380, 0, 1, 1, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 2714, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+370, 3357, 1, 1637, 1637, 2029.908, -4706.16, 26.88646, 3.351032, 0, 0, 0, 0, 0, 0, 0, 1, 1379, 1379, 0, 1, 0, 29, 35, 16, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 1910, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+369, 14451, 1, 1637, 1637, 2038.21, -4672.546, 25.15359, 3.996804, 0, 0, 0, 0, 0, 0, 0, 1, 14499, 14499, 0, 1, 1, 29, 10, 3, 768, 2048, 0, 198, 198, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+372, 14499, 1, 1637, 1637, 2040.917, -4679.772, 24.8328, 3.360977, 27.06309, 2, 0, 0, 0, 0, 0, 1, 14589, 14589, 0, 1, 0, 29, 1, 0, 768, 2048, 0, 42, 42, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0.5, 1, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+371, 3296, 1, 1637, 1637, 2044.36, -4694.986, 31.54138, 2.476614, 55.65958, 2, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+373, 14499, 1, 1637, 1637, 2056.905, -4677.977, 25.46589, 1.184834, 2.837253, 1, 0, 0, 0, 0, 0, 1, 14616, 14616, 0, 1, 1, 29, 2, 0, 768, 2048, 0, 55, 55, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0.5, 1, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+380, 2857, 1, 1637, 1637, 2047.991, -4746.009, 29.24313, 4.625123, 0, 0, 0, 0, 0, 0, 0, 1, 4386, 4386, 0, 1, 0, 29, 23, 17, 512, 2048, 0, 617, 617, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 1906, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+376, 11017, 1, 1637, 1637, 2038.401, -4748.98, 29.24313, 4.276057, 0, 0, 0, 0, 0, 0, 0, 1, 10472, 10472, 0, 1, 0, 29, 46, 1, 512, 2048, 0, 2399, 2399, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 1903, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+381, 9317, 1, 1637, 1637, 2045.527, -4753.813, 29.24313, 1.117011, 0, 0, 0, 0, 0, 0, 0, 1, 8631, 8631, 0, 1, 0, 29, 22, 2, 0, 2048, 0, 573, 573, 0, 0, 4194304, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 1911, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+379, 3410, 1, 1637, 1637, 1914.157, -4775.868, 36.33809, 1.117011, 0, 0, 0, 0, 0, 0, 0, 1, 4359, 4359, 0, 1, 0, 29, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 5259, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+377, 416, 1, 1637, 1637, 1991.759, -4784.508, 56.75919, 2.045937, 0, 0, 0, 0, 1, 1, 23503, 1, 4449, 4449, 0, 8, 0, 5, 60, 0, 65544, 2048, 0, 100, 100, 1898, 1898, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.5, 0.75, 1, 2000, 2000, 0, 0, 0, 0, 0, '4511 11767 18728 18737 18740', @SNIFFID+2, 35186),
(@CGUID+378, 14942, 1, 1637, 1637, 1980.901, -4787.776, 55.87959, 5.131268, 0, 0, 0, 0, 0, 0, 0, 1, 15033, 15033, 0, 1, 1, 1214, 61, 1, 576, 2048, 0, 157200, 157200, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.2596, 1.65, 1, 2000, 2000, 19623, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+375, 3412, 1, 1637, 1637, 2036.224, -4746.497, 29.24313, 4.677482, 0, 0, 0, 0, 0, 0, 0, 1, 7135, 7135, 0, 1, 0, 29, 35, 3, 512, 2048, 0, 1342, 1342, 0, 0, 0, 69, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 4994, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+374, 3413, 1, 1637, 1637, 2036.628, -4739.487, 29.24313, 4.827798, 0, 0, 0, 0, 0, 0, 0, 1, 7136, 7136, 0, 1, 0, 29, 30, 131, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 1911, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+383, 14498, 1, 1637, 1637, 2052.266, -4670.936, 25.54922, 5.288348, 0, 0, 0, 0, 0, 0, 0, 1, 3850, 3850, 0, 1, 1, 29, 34, 0, 512, 2048, 0, 1279, 1279, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+384, 3353, 1, 1637, 1637, 1980.004, -4799.735, 55.88128, 1.32645, 0, 0, 0, 0, 0, 0, 0, 1, 1374, 1374, 0, 1, 0, 29, 60, 17, 512, 2048, 0, 4120, 4120, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.4092, 1.65, 1, 2000, 2000, 10612, 10611, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+382, 3890, 1, 1637, 1637, 1990.415, -4794.146, 55.90359, 3.071779, 0, 0, 0, 0, 0, 0, 0, 1, 15032, 15032, 0, 1, 0, 1515, 61, 1, 576, 2048, 0, 157200, 157200, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.4092, 1.65, 1, 2000, 2000, 18419, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+385, 15006, 1, 1637, 1637, 2002.26, -4796.741, 56.8471, 3.001966, 0, 0, 0, 0, 0, 0, 0, 1, 15112, 15112, 0, 1, 1, 412, 61, 1, 576, 2048, 0, 157200, 157200, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.4213, 1.65, 1, 2000, 2000, 10616, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+388, 3354, 1, 1637, 1637, 1970.946, -4808.167, 56.84803, 0.8377581, 0, 0, 0, 0, 0, 0, 0, 1, 1375, 1375, 0, 1, 0, 29, 50, 19, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 1983, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+387, 15350, 1, 1637, 1637, 1988.498, -4812.283, 56.84937, 1.570796, 0, 0, 0, 0, 0, 0, 0, 1, 15387, 15387, 0, 1, 0, 1074, 60, 3, 0, 2048, 0, 3052, 3052, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 13706, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+386, 3408, 1, 1637, 1637, 1997.926, -4807.953, 56.84803, 2.443461, 0, 0, 0, 0, 0, 0, 0, 1, 4242, 4242, 0, 1, 0, 29, 40, 17, 512, 2048, 0, 1753, 1753, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 12348, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+390, 11177, 1, 1637, 1637, 2048.797, -4799.861, 22.8961, 6.003932, 0, 0, 0, 0, 0, 0, 0, 1, 10696, 10696, 0, 1, 0, 29, 52, 3, 0, 2048, 0, 3082, 3082, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5491, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+389, 11178, 1, 1637, 1637, 2051.843, -4794.393, 23.26726, 5.358161, 0, 0, 0, 0, 0, 0, 0, 1, 10697, 10697, 0, 1, 0, 29, 51, 3, 0, 2048, 0, 2980, 2980, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 1903, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+392, 1383, 1, 1637, 1637, 2055.833, -4797.069, 22.90629, 5.445427, 0, 0, 0, 0, 0, 0, 0, 1, 4382, 4382, 0, 1, 0, 29, 31, 1, 512, 2048, 0, 1107, 1107, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+391, 11176, 1, 1637, 1637, 2055.533, -4802.112, 22.46616, 5.951573, 0, 0, 0, 0, 0, 0, 0, 1, 10695, 10695, 0, 1, 0, 29, 53, 1, 0, 2048, 0, 3189, 3189, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5532, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+393, 11357, 1, 1637, 1637, 1991.932, -4791.738, 55.82035, 0, 20.79612, 2, 0, 0, 1, 1, 23498, 1, 15275, 15275, 0, 1, 2, 2, 60, 0, 8, 2048, 0, 100, 100, 0, 100, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.7, 0.7, 1, 2000, 2000, 0, 0, 0, 0, 0, '0', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+396, 10266, 1, 1637, 1637, 2052.206, -4813.458, 22.49753, 0.296706, 0, 0, 0, 0, 0, 0, 0, 1, 9739, 9739, 0, 1, 0, 29, 25, 17, 512, 2048, 0, 713, 713, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5532, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+398, 7790, 1, 1637, 1637, 2064.325, -4791.98, 22.96957, 5.759586, 0, 0, 0, 0, 0, 0, 0, 1, 6873, 6873, 0, 1, 0, 29, 45, 2, 512, 2048, 0, 2218, 2218, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 1903, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+395, 7792, 1, 1637, 1637, 2055.712, -4815.897, 22.92756, 0.4886922, 0, 0, 0, 0, 0, 0, 0, 1, 6843, 6843, 0, 1, 0, 29, 50, 2, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2182, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+394, 7793, 1, 1637, 1637, 2053.862, -4808.948, 22.44391, 5.202496, 0, 0, 0, 0, 0, 0, 0, 1, 6854, 6854, 0, 1, 0, 104, 53, 2, 512, 2048, 0, 3189, 3189, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 5491, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+397, 7230, 1, 1637, 1637, 2054.631, -4805.991, 22.41951, 3.316126, 0, 0, 0, 0, 0, 0, 0, 1, 6005, 6005, 0, 1, 1, 29, 60, 1, 512, 2048, 0, 4120, 4120, 0, 0, 0, 233, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 2182, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+399, 3356, 1, 1637, 1637, 2049.791, -4839.131, 24.43416, 0.1745329, 0, 0, 0, 0, 0, 0, 0, 1, 1378, 1378, 0, 1, 1, 29, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 233, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 1903, 13611, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+401, 5812, 1, 1637, 1637, 2053.396, -4838.876, 24.43416, 3.089233, 0, 0, 0, 0, 0, 0, 0, 1, 4351, 4351, 0, 1, 1, 29, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 233, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 1903, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+400, 3355, 1, 1637, 1637, 2058.969, -4835.583, 24.43416, 3.316126, 0, 0, 0, 0, 0, 0, 0, 1, 1377, 1377, 0, 1, 0, 29, 45, 1, 512, 2048, 0, 2218, 2218, 0, 0, 0, 233, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 1903, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+403, 14182, 1, 1637, 1637, 2038.242, -4690.106, 29.17087, 2.578267, 38.67619, 2, 0, 0, 0, 0, 0, 1, 14216, 14216, 0, 2, 0, 104, 60, 2, 0, 2048, 0, 2442, 2442, 2434, 2434, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12951, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+402, 3296, 1, 1637, 1637, 2050.847, -4699.78, 33.29106, 2.451144, 155.8414, 2, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+178, 1860, 0, 1537, 1537, -4992.723, -1092.633, 501.6594, 4.629035, 208.0732, 2, 0, 0, 1, 1, 697, 1, 1132, 1132, 0, 2, 2, 1, 58, 0, 8, 2048, 0, 100, 100, 1763, 1763, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.8, 2, 1, 2000, 2000, 0, 0, 0, 0, 0, '18727 18735 18742', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+405, 14499, 1, 1637, 1637, 2061.245, -4670.162, 25.46589, 4.403364, 2.037113, 1, 0, 0, 0, 0, 0, 1, 14589, 14589, 0, 1, 0, 29, 1, 0, 768, 2048, 0, 42, 42, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0.5, 1, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+404, 14499, 1, 1637, 1637, 2063.307, -4676.96, 25.46589, 2.168574, 2.514002, 1, 0, 0, 0, 0, 0, 1, 14589, 14589, 0, 1, 0, 29, 3, 0, 768, 2048, 0, 71, 71, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0.5, 1, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+406, 14499, 1, 1637, 1637, 2063.893, -4673.865, 25.46589, 2.02644, 2.410456, 1, 0, 0, 0, 0, 0, 1, 14589, 14589, 0, 1, 0, 29, 1, 0, 768, 2048, 0, 42, 42, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0.5, 1, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+412, 3406, 1, 1637, 1637, 2084.964, -4623.775, 58.67611, 0.1570796, 0, 0, 0, 0, 0, 0, 0, 1, 4239, 4239, 0, 1, 0, 29, 50, 1, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 3433, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+411, 3407, 1, 1637, 1637, 2107.35, -4633.776, 58.73709, 2.111848, 0, 0, 0, 0, 0, 0, 0, 1, 4241, 4241, 0, 1, 1, 29, 40, 3, 512, 2048, 0, 1753, 1753, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 3433, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+407, 3296, 1, 1637, 1637, 2126.414, -4738.087, 50.44913, 2.740167, 0, 0, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+409, 9988, 1, 1637, 1637, 2133.442, -4667.445, 46.51219, 1.518436, 0, 0, 0, 0, 0, 0, 0, 1, 9261, 9261, 0, 1, 0, 29, 30, 4194304, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 1908, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+408, 3296, 1, 1637, 1637, 2131.148, -4729.884, 50.4302, 2.600541, 0, 0, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+410, 7294, 1, 1637, 1637, 2067.856, -4598.879, 54.32269, 5.026548, 0, 0, 0, 0, 0, 0, 0, 1, 6064, 6064, 0, 1, 1, 29, 35, 0, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 3433, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+413, 3352, 1, 1637, 1637, 2100.581, -4606.961, 58.78632, 4.520403, 0, 0, 0, 0, 0, 0, 0, 1, 1373, 1373, 0, 1, 0, 29, 60, 3, 512, 2048, 0, 4120, 4120, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 5262, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+414, 4752, 1, 1637, 1637, 2151.365, -4654.135, 50.11429, 1.937315, 0, 0, 0, 0, 0, 0, 0, 1, 4464, 4464, 2327, 1, 0, 29, 50, 81, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.385714, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 10611, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+415, 14539, 1, 1637, 1637, 2153.649, -4657.141, 49.99923, 1.518436, 0, 0, 0, 0, 0, 0, 0, 1, 14575, 14575, 0, 1, 2, 35, 10, 0, 0, 2048, 0, 198, 198, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.385714, 1, 1, 1, 1, 1, 0.42, 1.8, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+416, 5195, 1, 1637, 1637, 2158.74, -4661.515, 49.70003, 2.007129, 0, 0, 0, 0, 0, 0, 0, 1, 2328, 2328, 0, 1, 2, 35, 10, 0, 0, 2048, 0, 198, 198, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.385714, 1, 1, 1, 1, 1, 0.42, 1.8, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+418, 12351, 1, 1637, 1637, 2162.763, -4659.62, 49.7548, 2.251475, 0, 0, 0, 0, 0, 0, 0, 1, 2327, 2327, 0, 1, 2, 35, 10, 0, 0, 2048, 0, 198, 198, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.385714, 1, 1, 1, 1, 1, 0.42, 1.8, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+417, 3362, 1, 1637, 1637, 2159.363, -4653.742, 49.74117, 2.80998, 0, 0, 0, 0, 0, 0, 0, 1, 1384, 1384, 0, 1, 0, 29, 45, 131, 512, 2048, 0, 2218, 2218, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2147, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+419, 14541, 1, 1637, 1637, 2155.594, -4649.176, 50.06181, 5.305801, 0, 0, 0, 0, 0, 0, 0, 1, 14574, 14574, 0, 1, 2, 35, 10, 0, 0, 2048, 0, 198, 198, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.385714, 1, 1, 1, 1, 1, 0.42, 1.8, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+422, 12353, 1, 1637, 1637, 2164.998, -4653.572, 50.54746, 3.176499, 0, 0, 0, 0, 0, 0, 0, 1, 247, 247, 0, 1, 2, 35, 10, 0, 0, 2048, 0, 198, 198, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.385714, 1, 1, 1, 1, 1, 0.42, 1.8, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+420, 10088, 1, 1637, 1637, 2135.327, -4610.785, 54.38645, 4.171337, 0, 0, 0, 0, 0, 0, 0, 1, 9336, 9336, 0, 1, 0, 29, 40, 1, 512, 2048, 0, 1753, 1753, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 6680, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+421, 14540, 1, 1637, 1637, 2161.671, -4648.078, 50.36319, 4.18879, 0, 0, 0, 0, 0, 0, 0, 1, 14573, 14573, 0, 1, 2, 35, 10, 0, 0, 2048, 0, 198, 198, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.385714, 1, 1, 1, 1, 1, 0.42, 1.8, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+423, 3296, 1, 1637, 1637, 1917.063, -4499.968, 24.60831, 3.877693, 41.98986, 2, 0, 0, 0, 0, 0, 1, 4601, 4601, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+424, 8659, 1, 1637, 1637, 1955.099, -4459.365, 54.77758, 2.6529, 0, 0, 0, 0, 0, 0, 0, 1, 7921, 7921, 0, 1, 0, 876, 50, 3, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 2711, 10619, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+425, 11046, 1, 1637, 1637, 1966.151, -4463.104, 25.77961, 1.570796, 0, 0, 0, 0, 0, 0, 0, 1, 10578, 10578, 0, 1, 0, 29, 23, 17, 512, 2048, 0, 617, 617, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 3699, 3697, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+426, 3296, 1, 1637, 1637, 1909.257, -4407.945, 48.02065, 4.526188, 20.748, 2, 0, 0, 0, 0, 0, 1, 4601, 4601, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+428, 3296, 1, 1637, 1637, 1928.318, -4424.406, 23.75051, 0.5585054, 0, 0, 0, 0, 0, 0, 0, 1, 4601, 4601, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+427, 3296, 1, 1637, 1637, 1953.006, -4431.153, 25.14688, 3.316126, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+429, 3296, 1, 1637, 1637, 1921.702, -4375.67, 22.57241, 5.846853, 0, 0, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+430, 3296, 1, 1637, 1637, 1950.888, -4374.689, 22.04296, 2.70526, 0, 0, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+431, 3296, 1, 1637, 1637, 1931.961, -4372.72, 21.21323, 4.75044, 35.59676, 2, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+432, 3296, 1, 1637, 1637, 1920.621, -4365.931, 22.80405, 0.296706, 0, 0, 0, 0, 0, 0, 0, 1, 4601, 4601, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+433, 3296, 1, 1637, 1637, 1952.528, -4368.574, 22.659, 3.682645, 0, 0, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+434, 15761, 1, 1637, 1637, 1945.322, -4330.305, 22.10106, 3.508112, 0, 0, 0, 0, 0, 0, 0, 1, 15731, 15731, 0, 1, 0, 126, 55, 3, 0, 2048, 0, 2614, 2614, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+435, 3326, 1, 1637, 1637, 1848.961, -4360.433, -14.79823, 0.8552113, 0, 0, 0, 0, 0, 0, 0, 1, 1326, 1326, 0, 1, 0, 29, 50, 3, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5277, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+436, 3350, 1, 1637, 1637, 1891.599, -4326.753, 23.25296, 0.2617994, 0, 0, 0, 0, 0, 0, 0, 1, 1371, 1371, 0, 1, 0, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 1906, 12745, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+437, 3351, 1, 1637, 1637, 1890.899, -4322.093, 23.25297, 4.101524, 0, 0, 0, 0, 0, 0, 0, 1, 1372, 1372, 0, 1, 0, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2717, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+438, 5875, 1, 1637, 1637, 1850.307, -4357.304, -14.79823, 5.323254, 0, 0, 0, 0, 0, 0, 0, 1, 4492, 4492, 0, 1, 0, 83, 40, 2, 512, 2048, 0, 1753, 1753, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 12864, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+440, 3335, 1, 1637, 1637, 1846.535, -4325.67, -15.61929, 3.804818, 0, 0, 0, 0, 0, 0, 0, 1, 1335, 1335, 0, 1, 0, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2199, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+443, 5909, 1, 1637, 1637, 1839.544, -4340.732, -15.43438, 3.595378, 0, 0, 0, 0, 0, 0, 0, 1, 4545, 4545, 0, 1, 0, 83, 40, 2, 512, 2048, 0, 1753, 1753, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+445, 3296, 1, 1637, 1637, 1902.14, -4275.213, 31.79866, 4.171337, 0, 0, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+441, 5815, 1, 1637, 1637, 1836.857, -4347.132, -14.76212, 3.333579, 0, 0, 0, 0, 0, 0, 0, 1, 4354, 4354, 0, 8, 0, 29, 45, 3, 512, 2048, 0, 1553, 1553, 3801, 3801, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5304, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+442, 3324, 1, 1637, 1637, 1844.208, -4353.609, -14.79823, 3.316126, 0, 0, 0, 0, 0, 0, 0, 1, 1324, 1324, 0, 1, 0, 29, 50, 1, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5277, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+439, 3325, 1, 1637, 1637, 1834.659, -4362.522, -14.78248, 2.094395, 0, 0, 0, 0, 0, 0, 0, 1, 1325, 1325, 0, 1, 1, 29, 50, 1, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5277, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+444, 15765, 1, 1637, 1637, 1911.704, -4276.771, 31.65568, 4.886922, 0, 0, 0, 0, 0, 0, 0, 1, 15724, 15724, 0, 1, 1, 29, 55, 3, 0, 2048, 0, 2614, 2614, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 13718, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+447, 14304, 1, 1637, 1637, 1924.731, -4245.422, 41.9408, 6.248279, 0, 0, 0, 0, 0, 0, 0, 1, 14361, 14361, 0, 1, 0, 85, 60, 0, 32768, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.4092, 1.65, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+446, 14304, 1, 1637, 1637, 1931.518, -4244.775, 41.92098, 2.984513, 0, 0, 0, 0, 0, 0, 0, 1, 14363, 14363, 0, 1, 1, 85, 60, 0, 32768, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.2596, 1.65, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+449, 14304, 1, 1637, 1637, 1930.458, -4238.259, 42.0164, 4.39823, 0, 0, 0, 0, 0, 0, 0, 1, 14360, 14360, 0, 1, 0, 85, 60, 0, 32768, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.4092, 1.65, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+448, 14304, 1, 1637, 1637, 1924.789, -4238.431, 42.01454, 5.201081, 0, 0, 0, 0, 0, 0, 0, 1, 14361, 14361, 0, 1, 0, 85, 60, 0, 32768, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.4092, 1.65, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+450, 13417, 1, 1637, 1637, 1937.842, -4222.84, 42.17813, 3.787364, 0, 0, 0, 0, 0, 0, 0, 1, 13341, 13341, 0, 1, 0, 104, 50, 3, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 2558, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+452, 4047, 1, 1637, 1637, 1914.652, -4226.583, 42.17891, 0.6632251, 0, 0, 0, 0, 0, 0, 0, 1, 4514, 4514, 0, 1, 0, 29, 62, 2, 512, 2048, 0, 4370, 4370, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5304, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+451, 3344, 1, 1637, 1637, 1933.694, -4224.861, 42.17821, 0.05235988, 0, 0, 0, 0, 0, 0, 0, 1, 1360, 1360, 0, 1, 1, 29, 60, 1, 512, 2048, 0, 4120, 4120, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 3361, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+454, 3403, 1, 1637, 1637, 1932.878, -4211.299, 42.17821, 6.248279, 0, 0, 0, 0, 0, 0, 0, 1, 4231, 4231, 0, 1, 1, 29, 40, 1, 512, 2048, 0, 1753, 1753, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 5300, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+453, 3330, 1, 1637, 1637, 1823.879, -4302.592, -12.314, 3.787364, 0, 0, 0, 0, 0, 0, 0, 1, 1330, 1330, 0, 1, 0, 29, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5304, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+455, 5892, 1, 1637, 1637, 1920.953, -4212.993, 42.17821, 5.410521, 0, 0, 0, 0, 0, 0, 0, 1, 4534, 4534, 0, 1, 0, 126, 15, 2, 512, 2048, 0, 328, 328, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 5291, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+457, 14304, 1, 1637, 1637, 1922.2, -4204.384, 42.07032, 4.921828, 0, 0, 0, 0, 0, 0, 0, 1, 14363, 14363, 0, 1, 1, 85, 60, 0, 32768, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.2596, 1.65, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+456, 5816, 1, 1637, 1637, 1820.773, -4300.225, -12.314, 4.485496, 0, 0, 0, 0, 0, 0, 0, 1, 4355, 4355, 0, 1, 1, 29, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 6231, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+458, 14304, 1, 1637, 1637, 1928.188, -4203.37, 42.04974, 4.694936, 0, 0, 0, 0, 0, 0, 0, 1, 14362, 14362, 0, 1, 1, 85, 60, 0, 32768, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.2596, 1.65, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+179, 2790, 0, 1537, 1537, -5028.902, -1022.518, 508.8757, 4.461609, 0.7344279, 0, 0, 0, 0, 0, 0, 1, 5410, 5410, 0, 1, 0, 55, 44, 2, 512, 2048, 0, 2138, 2138, 0, 0, 0, 233, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 1903, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+180, 5101, 0, 1537, 1537, -4962.096, -1023.771, 503.952, 1.134464, 0, 0, 0, 0, 0, 0, 0, 1, 3041, 3041, 0, 1, 1, 55, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 1906, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+183, 5100, 0, 1537, 1537, -4958.074, -1015.154, 503.9496, 4.171337, 0, 0, 0, 0, 0, 0, 0, 1, 3040, 3040, 0, 1, 0, 875, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 1911, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+182, 5049, 0, 1537, 1537, -5020.17, -1000.654, 503.9644, 1.989675, 0, 0, 0, 0, 0, 0, 0, 1, 2999, 2999, 0, 1, 1, 55, 25, 128, 512, 2048, 0, 713, 713, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+185, 5595, 0, 1537, 1537, -4946.285, -1013.475, 501.5236, 1.186824, 0, 0, 0, 0, 0, 0, 0, 1, 3524, 3524, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+184, 5130, 0, 1537, 1537, -5016.194, -997.4417, 503.9663, 2.792527, 0, 0, 0, 0, 0, 0, 0, 1, 3081, 3081, 0, 1, 0, 55, 60, 786433, 512, 2048, 0, 4120, 4120, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5303, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+181, 5132, 0, 1537, 1537, -4963.588, -1014.19, 503.9517, 5.235988, 0, 0, 0, 0, 0, 0, 0, 1, 3107, 3107, 0, 1, 0, 875, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+459, 3334, 1, 1637, 1637, 1811.042, -4270.902, 7.169196, 3.944444, 0, 0, 0, 0, 0, 0, 0, 1, 1334, 1334, 0, 1, 0, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2199, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+187, 5102, 0, 1537, 1537, -4915.998, -996.6329, 502.0799, 4.031711, 0, 0, 0, 0, 0, 0, 0, 1, 3042, 3042, 0, 1, 0, 55, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 1896, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+186, 5595, 0, 1537, 1537, -4995.79, -969.6661, 501.7427, 5.846853, 0, 0, 0, 0, 0, 0, 0, 1, 3527, 3527, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+188, 7434, 0, 1537, 1537, -4927.597, -973.1913, 501.5174, 0.1168513, 42.45866, 2, 0, 0, 1, 1, 0, 1, 9954, 9954, 0, 1, 1, 4, 60, 0, 8, 2048, 0, 100, 100, 100, 100, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.385, 1.65, 1, 1500, 1500, 0, 0, 0, 0, 0, '21925 8875 17210 19580 19581 19582 19589 19591 20782 20784 24555 24445 4190 24497', @SNIFFID+1, 35186),
(@CGUID+460, 3327, 1, 1637, 1637, 1792.341, -4279.377, 7.337334, 4.747295, 0, 0, 0, 0, 0, 0, 0, 1, 1327, 1327, 0, 1, 0, 29, 40, 1, 512, 2048, 0, 1753, 1753, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2184, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+192, 5099, 0, 1537, 1537, -4895.643, -1004.662, 504.0237, 2.234021, 0, 0, 0, 0, 0, 0, 0, 1, 3039, 3039, 0, 1, 1, 55, 45, 131072, 512, 2048, 0, 5544, 5544, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+189, 5595, 0, 1537, 1537, -4981.892, -949.8979, 501.7429, 5.637414, 0, 0, 0, 0, 0, 0, 0, 1, 3526, 3526, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+191, 5103, 0, 1537, 1537, -4914.137, -998.0253, 502.0799, 4.101524, 0, 0, 0, 0, 0, 0, 0, 1, 3043, 3043, 0, 1, 0, 55, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 1909, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+194, 5595, 0, 1537, 1537, -4906.753, -977.5198, 501.5236, 2.251475, 0, 0, 0, 0, 0, 0, 0, 1, 3525, 3525, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+193, 5595, 0, 1537, 1537, -4902.074, -973.7961, 501.5237, 2.268928, 0, 0, 0, 0, 0, 0, 0, 1, 3524, 3524, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+190, 14363, 0, 1537, 1537, -4959.048, -941.7676, 501.6594, 0.5451725, 56.06449, 2, 0, 0, 0, 0, 0, 1, 14396, 14396, 0, 1, 0, 57, 60, 0, 32768, 2048, 0, 9156, 9156, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 11763, 11763, 0, 0, 0, '18950', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+462, 14304, 1, 1637, 1637, 1919.356, -4176.048, 41.00497, 0.05235988, 0, 0, 0, 0, 0, 0, 0, 1, 14361, 14361, 0, 1, 0, 85, 60, 0, 32768, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.4092, 1.65, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+461, 14304, 1, 1637, 1637, 1901.269, -4171.156, 43.5635, 0.9948376, 0, 0, 0, 0, 0, 0, 0, 1, 14362, 14362, 0, 1, 1, 85, 60, 0, 32768, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.2596, 1.65, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+463, 14304, 1, 1637, 1637, 1923.451, -4178.627, 40.92688, 4.793837, 0, 1, 0, 0, 0, 0, 0, 1, 14363, 14363, 0, 1, 1, 85, 60, 0, 32768, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.2596, 1.65, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+196, 7292, 0, 1537, 1537, -4886.969, -978.3104, 504.0237, 5.393067, 0, 0, 0, 0, 0, 0, 0, 1, 6588, 6588, 0, 1, 1, 55, 55, 2, 512, 2048, 0, 3006, 3006, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+199, 5109, 0, 1537, 1537, -4925.134, -947.5443, 501.5633, 3.683619, 40.8218, 2, 0, 0, 0, 0, 0, 1, 3050, 3050, 0, 1, 1, 55, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 2197, 0, 0, 0, 0, '', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+202, 15102, 0, 1537, 1537, -5033.752, -931.2869, 501.7427, 1.32645, 0, 0, 0, 0, 0, 0, 0, 1, 15255, 15255, 0, 1, 1, 1642, 22, 1048577, 0, 2048, 0, 573, 573, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+200, 1201, 0, 1537, 1537, -4963.322, -917.041, 503.837, 4.110091, 0, 0, 0, 0, 1, 1, 883, 1, 954, 954, 0, 1, 2, 3, 20, 0, 8, 2048, 0, 100, 100, 100, 100, 4194304, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.6589068, 1.24322, 1, 2000, 2000, 0, 0, 0, 0, 0, '8875 17210 19580 19581 19582 19589 19591 20782 20784', @SNIFFID+1, 35186),
(@CGUID+198, 5595, 0, 1537, 1537, -4910.847, -946.5162, 501.4901, 3.823704, 20.3719, 2, 0, 0, 0, 0, 0, 1, 3527, 3527, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+203, 5595, 0, 1537, 1537, -5002.076, -915.2388, 501.6594, 0.703986, 21.33793, 2, 0, 0, 0, 0, 0, 1, 3524, 3524, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+197, 13843, 0, 1537, 1537, -4903.006, -968.2373, 501.5329, 2.478368, 0, 0, 0, 0, 0, 0, 0, 1, 13850, 13850, 0, 1, 0, 1217, 60, 2, 0, 2048, 0, 3052, 3052, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 12742, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+195, 2461, 0, 1537, 1537, -4886.55, -997.5938, 504.0237, 2.234021, 0, 0, 0, 0, 0, 0, 0, 1, 3038, 3038, 0, 1, 0, 55, 45, 131072, 512, 2048, 0, 5544, 5544, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+201, 9859, 0, 1537, 1537, -4967.856, -917.619, 505.1687, 0.7853982, 0, 0, 0, 0, 0, 0, 0, 1, 9131, 9131, 0, 1, 1, 55, 50, 2097152, 0, 2048, 0, 6645, 6645, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+464, 3402, 1, 1637, 1637, 1778.553, -4279.878, 7.591963, 4.625123, 0, 0, 0, 0, 0, 0, 0, 1, 4361, 4361, 0, 1, 0, 126, 35, 3, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 10617, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+465, 14304, 1, 1637, 1637, 1910.206, -4169.479, 41.00837, 0.8377581, 0, 0, 0, 0, 0, 0, 0, 1, 14361, 14361, 0, 1, 0, 85, 60, 0, 32768, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.4092, 1.65, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+207, 15102, 0, 1537, 1537, -5032.969, -926.6805, 501.7427, 4.642576, 0, 0, 0, 0, 0, 0, 0, 1, 15257, 15257, 0, 1, 1, 1642, 23, 1048577, 0, 2048, 0, 617, 617, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+205, 8720, 0, 1537, 1537, -4963.188, -904.619, 505.1697, 5.427974, 0, 0, 0, 0, 0, 0, 0, 1, 7989, 7989, 0, 1, 1, 55, 50, 2097152, 0, 2048, 0, 6645, 6645, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+204, 2460, 0, 1537, 1537, -4877.426, -990.0336, 504.0237, 2.303835, 0, 0, 0, 0, 0, 0, 0, 1, 3037, 3037, 0, 1, 0, 55, 45, 131072, 512, 2048, 0, 5544, 5544, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+206, 5595, 0, 1537, 1537, -4879.809, -1031.883, 502.2731, 6.003932, 0, 0, 0, 0, 0, 0, 0, 1, 3524, 3524, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+208, 5106, 0, 1537, 1537, -4876.678, -964.3713, 511.8243, 5.201081, 0, 0, 0, 0, 0, 0, 0, 1, 3044, 3044, 0, 1, 0, 55, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 1985, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+210, 5107, 0, 1537, 1537, -4874.866, -966.2003, 505.157, 3.700098, 0, 0, 0, 0, 0, 0, 0, 1, 3045, 3045, 0, 1, 0, 55, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 2053, 0, 0, 0, '8114', @SNIFFID+1, 35186),
(@CGUID+209, 8671, 0, 1537, 1537, -4948.009, -901.5277, 505.1716, 3.804818, 0, 0, 0, 0, 0, 0, 0, 1, 7990, 7990, 0, 1, 0, 55, 50, 2097152, 0, 2048, 0, 6645, 6645, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+211, 1274, 0, 1537, 1537, -4872.563, -1026.281, 505.7978, 5.602507, 0, 0, 0, 0, 0, 0, 0, 1, 1655, 1655, 0, 1, 0, 55, 50, 2, 512, 2048, 0, 2769, 2769, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 1500, 1500, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+212, 5108, 0, 1537, 1537, -4872.032, -971.5286, 505.1569, 3.630285, 0, 0, 0, 0, 0, 0, 0, 1, 3049, 3049, 0, 1, 1, 55, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+466, 6446, 1, 1637, 1637, 1772.944, -4279.927, 7.950991, 5.358161, 0, 0, 0, 0, 0, 0, 0, 1, 5190, 5190, 0, 1, 0, 83, 20, 2, 512, 2048, 0, 484, 484, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 2711, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+469, 16012, 1, 1637, 1637, 1915.672, -4170.772, 40.91818, 0.7387071, 0, 0, 0, 0, 0, 0, 0, 1, 15966, 15966, 0, 1, 0, 1619, 60, 3, 0, 2048, 0, 6104, 6104, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 14824, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+468, 3342, 1, 1637, 1637, 1784.442, -4205.354, 40.09032, 4.537856, 0, 0, 0, 0, 0, 0, 0, 1, 1358, 1358, 0, 1, 1, 29, 35, 128, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 12329, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+467, 3401, 1, 1637, 1637, 1771.211, -4284.415, 7.840539, 5.759586, 0, 0, 0, 0, 0, 0, 0, 1, 4360, 4360, 0, 1, 0, 126, 60, 3, 512, 2048, 0, 4120, 4120, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 1900, 5281, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+216, 8879, 0, 1537, 1537, -4861.041, -1016.932, 505.7978, 5.270895, 0, 0, 0, 0, 0, 0, 0, 1, 8171, 8171, 0, 2, 1, 55, 50, 3, 512, 2048, 0, 2215, 2215, 1807, 1807, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 12742, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+213, 2784, 0, 1537, 1537, -4865.73, -1022.668, 505.7978, 5.427974, 0, 0, 0, 0, 0, 0, 0, 1, 3597, 3597, 0, 1, 0, 55, 63, 2, 64, 2048, 0, 999300, 999300, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.4164, 1.8, 1, 2000, 2000, 12883, 12883, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+220, 5595, 0, 1537, 1537, -4902.17, -895.577, 501.6592, 5.122557, 61.06097, 2, 0, 0, 0, 0, 0, 1, 3524, 3524, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+217, 5595, 0, 1537, 1537, -4859.467, -941.6909, 501.5236, 3.385939, 0, 0, 0, 0, 0, 0, 0, 1, 3527, 3527, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+215, 5595, 0, 1537, 1537, -4854.637, -1010.239, 502.2731, 4.817109, 0, 0, 0, 0, 0, 0, 0, 1, 3527, 3527, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+214, 5595, 0, 1537, 1537, -4874.556, -1047.949, 502.2731, 0.3316126, 0, 0, 0, 0, 0, 0, 0, 1, 3526, 3526, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+219, 6175, 0, 1537, 1537, -4895.609, -898.0984, 501.6592, 2.286381, 54.5916, 2, 0, 0, 0, 0, 0, 1, 4889, 4889, 0, 1, 0, 12, 8, 2, 0, 2048, 0, 156, 156, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+218, 5595, 0, 1537, 1537, -4914.67, -894.8654, 501.7427, 5.183628, 0, 0, 0, 0, 0, 0, 0, 1, 3525, 3525, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+221, 5595, 0, 1537, 1537, -4975.548, -875.6268, 501.7427, 3.839724, 0, 0, 0, 0, 0, 0, 0, 1, 3524, 3524, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+222, 5595, 0, 1537, 1537, -4989.413, -887.2303, 501.7427, 0.6981317, 0, 0, 0, 0, 0, 0, 0, 1, 3525, 3525, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+223, 5595, 0, 1537, 1537, -4893.072, -884.8754, 501.7426, 5.096361, 0, 0, 0, 0, 0, 0, 0, 1, 3527, 3527, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+224, 5595, 0, 1537, 1537, -4871.809, -888.3698, 501.6593, 3.456403, 103.9221, 2, 0, 0, 0, 0, 0, 1, 3527, 3527, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186), --  (possible waypoints or random movement)
(@CGUID+225, 5110, 0, 1537, 1537, -4865.232, -865.3307, 502.2749, 5.009095, 0, 0, 0, 0, 0, 0, 0, 1, 3046, 3046, 0, 1, 0, 55, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 2707, 3694, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+227, 15102, 0, 1537, 1537, -4916.426, -848.374, 501.7446, 4.729842, 0, 0, 0, 0, 0, 0, 0, 1, 15257, 15257, 0, 1, 1, 1642, 22, 1048577, 0, 2048, 0, 573, 573, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+226, 15102, 0, 1537, 1537, -4916.615, -852.3054, 501.7446, 1.48353, 0, 0, 0, 0, 0, 0, 0, 1, 15256, 15256, 0, 1, 1, 1642, 22, 1048577, 0, 2048, 0, 573, 573, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+472, 10880, 1, 1637, 1637, 1745.259, -4216.553, 43.88711, 3.258013, 187.3701, 2, 0, 0, 0, 0, 0, 1, 10186, 10186, 0, 1, 0, 29, 3, 3, 512, 2048, 0, 71, 71, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+470, 3296, 1, 1637, 1637, 1751.45, -4208.817, 42.73262, 5.340707, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+471, 3296, 1, 1637, 1637, 1748.526, -4260.131, 27.07219, 2.338741, 0, 0, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+228, 14183, 0, 1537, 1537, -4842.396, -868.6484, 501.9971, 2.827433, 0, 0, 0, 0, 0, 0, 0, 1, 14235, 14235, 0, 2, 0, 55, 60, 2, 0, 2048, 0, 2442, 2442, 2434, 2434, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 0, 0, 15460, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+473, 5910, 1, 1637, 1637, 1717.783, -4200.109, 51.73675, 4.433136, 0, 0, 0, 0, 0, 0, 0, 1, 4546, 4546, 0, 1, 1, 83, 15, 2, 512, 2048, 0, 328, 328, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 12329, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+230, 5111, 0, 1537, 1537, -4840.674, -857.094, 501.9971, 4.869469, 0, 0, 0, 0, 0, 0, 0, 1, 3047, 3047, 0, 1, 0, 55, 30, 65667, 512, 2048, 0, 1003, 1003, 0, 0, 4194304, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 2705, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+229, 5112, 0, 1537, 1537, -4842.342, -860.9337, 501.997, 4.572762, 0, 0, 0, 0, 0, 0, 0, 1, 3051, 3051, 0, 1, 1, 55, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 2703, 0, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+474, 3296, 1, 1637, 1637, 1698.966, -4238.154, 50.49994, 0.5347008, 44.51326, 2, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+475, 3296, 1, 1637, 1637, 1690.52, -4262.622, 53.77575, 2.617994, 0, 0, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+476, 3296, 1, 1637, 1637, 1673.196, -4250.004, 51.87652, 5.044002, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+477, 12799, 1, 1637, 1637, 1632.208, -4262.188, 49.02697, 3.630285, 0, 0, 0, 0, 0, 0, 0, 1, 12681, 12681, 0, 1, 1, 29, 55, 4224, 0, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 10612, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+479, 3296, 1, 1637, 1637, 1628.893, -4274.761, 24.08548, 5.131268, 0, 0, 0, 0, 0, 0, 0, 1, 4601, 4601, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+478, 3296, 1, 1637, 1637, 1620.455, -4252.837, 47.52733, 3.700098, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+480, 3296, 1, 1637, 1637, 1623.147, -4279.637, 22.5694, 6.161012, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+481, 3296, 1, 1637, 1637, 1585.895, -4216.301, 43.47758, 5.014763, 234.2849, 2, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+482, 3370, 1, 1637, 1637, 1575.802, -4292.672, 26.03908, 4.380776, 0, 0, 0, 0, 0, 0, 0, 1, 1392, 1392, 0, 1, 0, 29, 45, 786433, 512, 2048, 0, 2218, 2218, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5303, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+485, 7562, 1, 1637, 1637, 1578.472, -4195.09, 40.61976, 1.635241, 189.3455, 2, 0, 0, 0, 0, 0, 1, 2957, 2957, 0, 1, 2, 188, 1, 0, 33536, 2048, 0, 42, 42, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.35, 0.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+484, 7565, 1, 1637, 1637, 1579.966, -4196.628, 40.87437, 1.567943, 185.7487, 2, 0, 0, 0, 0, 0, 1, 1206, 1206, 0, 1, 2, 188, 1, 0, 33536, 2048, 0, 42, 42, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.35, 0.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+483, 7567, 1, 1637, 1637, 1578.459, -4195.958, 40.72939, 1.658552, 202.1914, 2, 0, 0, 0, 0, 0, 1, 6303, 6303, 0, 1, 2, 188, 1, 0, 33536, 2048, 0, 42, 42, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.35, 0.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+488, 15696, 1, 1637, 1637, 1596.631, -4171.539, 39.23572, 6.140767, 10.19224, 1, 0, 0, 0, 0, 0, 1, 15653, 15653, 0, 1, 1, 29, 30, 0, 0, 2048, 0, 4775, 4775, 0, 0, 0, 69, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+486, 15515, 1, 1637, 1637, 1588.173, -4179.901, 39.98489, 2.897247, 0, 0, 0, 0, 0, 0, 0, 1, 15508, 15508, 0, 1, 1, 126, 56, 1, 0, 2048, 0, 13495, 13495, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 5278, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+489, 15525, 1, 1637, 1637, 1595.762, -4174.396, 39.76667, 2.722714, 0, 0, 0, 0, 0, 0, 0, 1, 15536, 15536, 0, 1, 0, 68, 60, 1, 0, 2048, 0, 15260, 15260, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.383, 1.5, 1, 2000, 2000, 21122, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+487, 3296, 1, 1637, 1637, 1566.22, -4194.073, 42.67085, 0.1570796, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+490, 8404, 1, 1637, 1637, 1578.916, -4168.717, 36.67879, 1.470963, 148.1718, 2, 0, 0, 0, 0, 0, 1, 7631, 7631, 0, 1, 0, 29, 30, 128, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 1906, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+495, 15696, 1, 1637, 1637, 1619.305, -4150.624, 36.44043, 5.166174, 12.90152, 1, 0, 0, 0, 0, 0, 1, 15650, 15650, 0, 1, 0, 29, 30, 0, 0, 2048, 0, 4775, 4775, 0, 0, 0, 69, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+492, 3296, 1, 1637, 1637, 1566.45, -4179.182, 41.02853, 5.427974, 0, 0, 0, 0, 0, 0, 0, 1, 4601, 4601, 0, 1, 1, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+494, 15508, 1, 1637, 1637, 1625.951, -4149.423, 36.39579, 1.902409, 0, 0, 0, 0, 0, 0, 0, 1, 15502, 15502, 0, 1, 0, 126, 58, 1, 0, 2048, 0, 14355, 14355, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 2081, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+491, 15522, 1, 1637, 1637, 1593.267, -4159.44, 36.90244, 2.949606, 0, 0, 0, 0, 0, 0, 0, 1, 15535, 15535, 0, 1, 1, 29, 58, 1, 0, 2048, 0, 14355, 14355, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 11019, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+493, 15477, 1, 1637, 1637, 1615.013, -4145.532, 35.132, 1.37881, 0, 0, 0, 0, 0, 0, 0, 1, 15472, 15472, 0, 1, 1, 104, 56, 1, 0, 2048, 0, 13495, 13495, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 21123, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+496, 15700, 1, 1637, 1637, 1598.454, -4120.487, 30.27376, 4.147731, 76.65234, 2, 0, 0, 0, 0, 0, 1, 15661, 15661, 14573, 1, 0, 29, 60, 3, 0, 2048, 0, 30520, 30520, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.385714, 1, 1, 1, 1, 1, 0.4092, 1.65, 1, 2000, 2000, 18419, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+231, 5595, 0, 1537, 1537, -4879.696, -1058.366, 502.2923, 4.153883, 0, 0, 0, 0, 0, 0, 0, 1, 3526, 3526, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+232, 5595, 0, 1537, 1537, -4858.888, -1056.431, 502.2731, 1.151917, 0, 0, 0, 0, 0, 0, 0, 1, 3526, 3526, 0, 1, 0, 57, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 5286, 6254, 0, 0, 0, '', @SNIFFID+1, 35186),
(@CGUID+500, 15736, 1, 1637, 1637, 1584.77, -4112.944, 33.37767, 5.410521, 0, 0, 0, 0, 0, 0, 0, 1, 15717, 15717, 0, 1, 1, 29, 55, 3, 0, 2048, 0, 2614, 2614, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+497, 15739, 1, 1637, 1637, 1603.886, -4142.897, 33.78176, 2.443461, 0, 0, 0, 0, 0, 0, 0, 1, 15720, 15720, 0, 1, 0, 104, 55, 3, 0, 2048, 0, 2614, 2614, 0, 0, 4194304, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+503, 15532, 1, 1637, 1637, 1565.065, -4123.986, 37.44075, 0, 0, 0, 0, 0, 0, 0, 0, 1, 15541, 15541, 0, 1, 1, 104, 60, 1, 0, 2048, 0, 15260, 15260, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.8725, 3.75, 1, 2000, 2000, 12754, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+498, 15512, 1, 1637, 1637, 1633.258, -4142.117, 34.70991, 2.111848, 0, 0, 0, 0, 0, 0, 0, 1, 15503, 15503, 0, 1, 1, 68, 60, 1, 0, 2048, 0, 15260, 15260, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.383, 1.5, 1, 2000, 2000, 2198, 12870, 0, 0, 0, '', @SNIFFID+2, 35186);

INSERT INTO `creature` (`guid`, `id`, `map`, `zone_id`, `area_id`, `position_x`, `position_y`, `position_z`, `orientation`, `wander_distance`, `movement_type`, `is_spawn`, `is_hovering`, `is_temporary`, `is_pet`, `summon_spell`, `scale`, `display_id`, `native_display_id`, `mount_display_id`, `class`, `gender`, `faction`, `level`, `npc_flags`, `unit_flags`, `unit_flags2`, `dynamic_flags`, `current_health`, `max_health`, `current_mana`, `max_mana`, `aura_state`, `emote_state`, `stand_state`, `vis_flags`, `sheath_state`, `pvp_flags`, `shapeshift_form`, `move_flags`, `speed_walk`, `speed_run`, `speed_run_back`, `speed_swim`, `speed_swim_back`, `speed_fly`, `speed_fly_back`, `bounding_radius`, `combat_reach`, `mod_melee_haste`, `main_hand_attack_time`, `off_hand_attack_time`, `main_hand_slot_item`, `off_hand_slot_item`, `ranged_slot_item`, `channel_spell_id`, `channel_visual_id`, `auras`, `sniff_id`, `sniff_build`) VALUES
(@CGUID+499, 15696, 1, 1637, 1637, 1564.185, -4128.901, 37.57561, 2.129302, 15.96709, 1, 0, 0, 0, 0, 0, 1, 15652, 15652, 0, 1, 1, 29, 30, 0, 0, 2048, 0, 4775, 4775, 0, 0, 0, 69, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+501, 15528, 1, 1637, 1637, 1580.174, -4116.106, 34.41577, 5.602507, 0, 0, 0, 0, 0, 0, 0, 1, 15537, 15537, 0, 1, 0, 104, 56, 1, 0, 2048, 0, 13495, 13495, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 12937, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+502, 15529, 1, 1637, 1637, 1571.207, -4118.8, 36.49723, 5.026548, 0, 0, 0, 0, 0, 0, 0, 1, 15539, 15539, 0, 1, 1, 68, 58, 1, 0, 2048, 0, 14355, 14355, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.383, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+504, 15458, 1, 1637, 1637, 1630.693, -4118.458, 31.26578, 1.972222, 0, 0, 0, 0, 0, 0, 0, 1, 15460, 15460, 14346, 1, 0, 35, 60, 1, 0, 2048, 0, 15260, 15260, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.385714, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2000, 2000, 2557, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+505, 3296, 1, 1637, 1637, 1632.306, -4117.596, 31.29346, 2.042035, 0, 0, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 0, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+506, 3296, 1, 1637, 1637, 1628.956, -4119.176, 31.18564, 2.094395, 0, 0, 0, 0, 0, 0, 0, 1, 4260, 4260, 0, 1, 1, 85, 55, 0, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+508, 15737, 1, 1637, 1637, 1618.441, -4101.765, 32.95245, 5.235988, 0, 0, 0, 0, 0, 0, 0, 1, 15702, 15702, 0, 1, 1, 126, 55, 3, 0, 2048, 0, 2614, 2614, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+507, 3349, 1, 1637, 1637, 1580.053, -4097.679, 36.3245, 5.183628, 0, 0, 0, 0, 0, 0, 0, 1, 1370, 1370, 0, 1, 0, 29, 30, 4224, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5304, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+509, 15459, 1, 1637, 1637, 1650.328, -4124.286, 31.45227, 2.6529, 0, 0, 0, 0, 0, 0, 0, 1, 15461, 15461, 0, 1, 0, 68, 56, 1, 0, 2048, 0, 13495, 13495, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.383, 1.5, 1, 2000, 2000, 1910, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+511, 15469, 1, 1637, 1637, 1655.773, -4119.163, 32.69511, 1.32645, 0, 0, 0, 0, 0, 0, 0, 1, 15466, 15466, 0, 1, 1, 126, 60, 1, 0, 2048, 0, 15260, 15260, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 6680, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+510, 3373, 1, 1637, 1637, 1482.723, -4159.951, 43.87708, 0.8377581, 0, 0, 0, 0, 0, 0, 0, 1, 1395, 1395, 0, 1, 0, 29, 35, 83, 512, 2048, 0, 1342, 1342, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 1907, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+512, 15534, 1, 1637, 1637, 1629.785, -4089.148, 35.63287, 5.253441, 0, 0, 0, 0, 0, 0, 0, 1, 15543, 15543, 0, 1, 0, 126, 58, 1, 0, 2048, 0, 14355, 14355, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 1117, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+513, 15738, 1, 1637, 1637, 1660.358, -4107.452, 34.62027, 2.059489, 0, 0, 0, 0, 0, 0, 0, 1, 15722, 15722, 0, 1, 0, 68, 55, 3, 0, 2048, 0, 2614, 2614, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.383, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+516, 14376, 1, 1637, 1637, 1652.431, -4097.776, 33.75541, 3.459149, 151.536, 2, 0, 0, 0, 0, 0, 1, 14414, 14414, 0, 1, 1, 85, 60, 0, 32768, 2048, 0, 9156, 9156, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 10612, 10612, 0, 0, 0, '18950', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+514, 15460, 1, 1637, 1637, 1665.762, -4117.497, 34.37464, 2.443461, 0, 0, 0, 0, 0, 0, 0, 1, 15462, 15462, 0, 1, 0, 29, 58, 1, 0, 2048, 0, 14355, 14355, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 12629, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+515, 15535, 1, 1637, 1637, 1634.122, -4084.991, 36.52574, 5.218534, 0, 0, 0, 0, 0, 0, 0, 1, 15544, 15544, 0, 1, 0, 104, 60, 1, 0, 2048, 0, 15260, 15260, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 6228, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+517, 15533, 1, 1637, 1637, 1643.434, -4085.086, 37.33722, 4.677482, 0, 0, 0, 0, 0, 0, 0, 1, 15542, 15542, 0, 1, 1, 29, 56, 1, 0, 2048, 0, 13495, 13495, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 2202, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+518, 15696, 1, 1637, 1637, 1666.252, -4109.438, 35.00458, 4.820095, 11.01158, 1, 0, 0, 0, 0, 0, 1, 15650, 15650, 0, 1, 0, 29, 30, 0, 0, 2048, 0, 4775, 4775, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+519, 15696, 1, 1637, 1637, 1639.42, -4082.152, 37.4822, 2.129302, 18.06842, 1, 0, 0, 0, 0, 0, 1, 15650, 15650, 0, 1, 0, 29, 30, 0, 0, 2048, 0, 4775, 4775, 0, 0, 0, 69, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', @SNIFFID+2, 35186), --  (possible waypoints or random movement)
(@CGUID+521, 3296, 1, 1637, 1637, 1682.142, -4099.991, 37.79473, 1.570796, 0, 0, 0, 0, 0, 0, 0, 1, 4602, 4602, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186),
(@CGUID+520, 3296, 1, 1637, 1637, 1696.313, -4096.761, 39.33681, 1.518436, 0, 0, 0, 0, 0, 0, 0, 1, 4259, 4259, 0, 1, 0, 85, 55, 1, 32768, 2048, 0, 5228, 5228, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.372, 1.5, 1, 2000, 2000, 5289, 0, 0, 0, 0, '', @SNIFFID+2, 35186);

DELETE FROM `creature_guid_values` WHERE `guid` BETWEEN @CGUID+0 AND @CGUID+521;
INSERT INTO `creature_guid_values` (`guid`, `charm_guid`, `charm_id`, `charm_type`, `summon_guid`, `summon_id`, `summon_type`, `charmer_guid`, `charmer_id`, `charmer_type`, `summoner_guid`, `summoner_id`, `summoner_type`, `creator_guid`, `creator_id`, `creator_type`, `demon_creator_guid`, `demon_creator_id`, `demon_creator_type`, `target_guid`, `target_id`, `target_type`) VALUES
(@CGUID+155, 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+12, 0, 'Player', @PGUID+12, 0, 'Player', 0, 0, '', 0, 0, ''),
(@CGUID+265, 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+107, 0, 'Player', @PGUID+107, 0, 'Player', 0, 0, '', 0, 0, ''),
(@CGUID+279, 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+159, 0, 'Player', @PGUID+159, 0, 'Player', 0, 0, '', 0, 0, ''),
(@CGUID+280, 0, 0, '', 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+160, 0, 'Player', @PGUID+160, 0, 'Player', 0, 0, ''),
(@CGUID+282, 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+167, 0, 'Player', @PGUID+167, 0, 'Player', 0, 0, '', 0, 0, ''),
(@CGUID+290, 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+186, 0, 'Player', @PGUID+186, 0, 'Player', 0, 0, '', 0, 0, ''),
(@CGUID+292, 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+192, 0, 'Player', @PGUID+192, 0, 'Player', 0, 0, '', 0, 0, ''),
(@CGUID+294, 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+193, 0, 'Player', @PGUID+193, 0, 'Player', 0, 0, '', 0, 0, ''),
(@CGUID+296, 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+198, 0, 'Player', @PGUID+198, 0, 'Player', 0, 0, '', 0, 0, ''),
(@CGUID+304, 0, 0, '', 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+222, 0, 'Player', @PGUID+222, 0, 'Player', 0, 0, ''),
(@CGUID+377, 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+250, 0, 'Player', @PGUID+250, 0, 'Player', 0, 0, '', 0, 0, ''),
(@CGUID+393, 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+269, 0, 'Player', @PGUID+269, 0, 'Player', 0, 0, '', 0, 0, ''),
(@CGUID+178, 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+20, 0, 'Player', @PGUID+20, 0, 'Player', 0, 0, '', 0, 0, ''),
(@CGUID+188, 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+25, 0, 'Player', @PGUID+25, 0, 'Player', 0, 0, '', 0, 0, ''),
(@CGUID+200, 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+43, 0, 'Player', @PGUID+43, 0, 'Player', 0, 0, '', 0, 0, '');


DELETE FROM `gameobject` WHERE `guid` BETWEEN @OGUID+0 AND @OGUID+557;
INSERT INTO `gameobject` (`guid`, `id`, `map`, `zone_id`, `area_id`, `position_x`, `position_y`, `position_z`, `orientation`, `rotation0`, `rotation1`, `rotation2`, `rotation3`, `is_temporary`, `creator_guid`, `creator_id`, `creator_type`, `display_id`, `level`, `faction`, `flags`, `dynamic_flags`, `path_progress`, `state`, `type`, `artkit`, `custom_param`, `sniff_id`, `sniff_build`) VALUES
(@OGUID+6, 177270, 1, 1638, 1638, -1278.976, 49.23162, 135.3255, 0.4712366, 0, 0, 0.2334442, 0.9723702, 0, 0, 0, '', 4718, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+0, 35186),
(@OGUID+2, 50468, 1, 1638, 1638, -1240.232, 112.1875, 129.6535, 3.455756, 0, 0, -0.9876881, 0.1564362, 0, 0, 0, '', 273, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+0, 35186),
(@OGUID+1, 50469, 1, 1638, 1638, -1240.523, 104.8438, 128.5923, 2.809975, 0, 0, 0.9862852, 0.1650499, 0, 0, 0, '', 305, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+0, 35186),
(@OGUID+4, 3298, 1, 1638, 1638, -1241.88, 41.97514, 127.152, 3.874631, 0, 0, -0.9335804, 0.358368, 0, 0, 0, '', 192, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+0, 35186),
(@OGUID+7, 175885, 1, 1638, 1638, -1212.68, 41.83084, 131.1574, 5.183629, 0, 0, -0.5224981, 0.8526405, 0, 0, 0, '', 3972, 0, 114, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+0, 35186),
(@OGUID+5, 143985, 1, 1638, 1638, -1263.311, 44.54541, 127.5446, 4.729844, 0, 0, -0.7009087, 0.7132511, 0, 0, 0, '', 2128, 0, 104, 0, 0, 65535, 1, 19, 0, 0, @SNIFFID+0, 35186),
(@OGUID+3, 180394, 1, 1638, 1638, -1249.684, 52.44569, 127.1802, 1.902409, 0, 0, 0.8141155, 0.580703, 0, 0, 0, '', 6707, 0, 1375, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+0, 35186),
(@OGUID+12, 175885, 1, 1638, 1638, -1182.851, 46.10249, 145.7744, 1.780234, 0, 0, 0.7771454, 0.6293211, 0, 0, 0, '', 3972, 0, 114, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+0, 35186),
(@OGUID+16, 4170, 1, 1638, 1638, -1286.243, 189.7202, 130.0798, 5.209807, 0, 0, -0.5112934, 0.8594062, 0, 0, 0, '', 360, 0, 0, 40, 0, 58816, 24, 11, 0, 0, @SNIFFID+0, 35186),
(@OGUID+17, 4171, 1, 1638, 1638, -1308.379, 185.2901, 68.58578, 6.012661, 0, 0, -0.1348505, 0.9908659, 0, 0, 0, '', 360, 0, 0, 40, 0, 34135, 24, 11, 0, 0, @SNIFFID+0, 35186),
(@OGUID+10, 152583, 1, 1638, 1638, -1257.844, 24.41409, 128.2174, 2.888511, 0, 0, 0.9920044, 0.1262032, 0, 0, 0, '', 2572, 0, 6, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+0, 35186),
(@OGUID+18, 47296, 1, 1638, 1638, -1028.043, -28.35687, 69.02256, 2.91469, 0, 0, 0.9935713, 0.1132084, 0, 0, 0, '', 360, 0, 0, 40, 0, 34135, 24, 11, 0, 0, @SNIFFID+0, 35186),
(@OGUID+19, 47297, 1, 1638, 1638, -1037.266, -49.23555, 140.4946, 3.071766, 0, 0, 0.9993906, 0.03490613, 0, 0, 0, '', 360, 0, 0, 40, 0, 58816, 24, 11, 0, 0, @SNIFFID+0, 35186),
(@OGUID+9, 177269, 1, 1638, 1638, -1204.251, 134.8047, 140.6939, 3.839725, 0, 0, -0.9396925, 0.3420205, 0, 0, 0, '', 4716, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+0, 35186),
(@OGUID+14, 175885, 1, 1638, 1638, -1201.881, 13.38466, 164.1364, 4.904376, 0, 0, -0.6360779, 0.7716249, 0, 0, 0, '', 3972, 0, 114, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+0, 35186),
(@OGUID+11, 3296, 1, 1638, 1638, -1299.784, 129.1942, 131.5722, 1.317723, 0, 0, 0.6122169, 0.7906898, 0, 0, 0, '', 192, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+0, 35186),
(@OGUID+13, 3286, 1, 1638, 1638, -1155.981, 66.81184, 145.9603, 0.09599365, 0, 0, 0.0479784, 0.9988484, 0, 0, 0, '', 192, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+0, 35186),
(@OGUID+8, 180394, 1, 1638, 1638, -1273.505, 134.1567, 132.0776, 3.926996, 0, 0, -0.9238787, 0.3826855, 0, 0, 0, '', 6707, 0, 1375, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+0, 35186),
(@OGUID+15, 175885, 1, 1638, 1638, -1197.373, 21.85172, 176.9492, 2.530723, 0, 0, 0.9537163, 0.3007079, 0, 0, 0, '', 3972, 0, 114, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+0, 35186),
-- (@OGUID+239, 164871, 1, 14, 14, 0, 0, 0, 4.538615, 0, 0, -0.7658005, 0.6430782, 0, 0, 0, '', 3031, 356287, 0, 1048616, 0, 6721, 1, 15, 0, 0, @SNIFFID+2, 35186), --  - !!! transport !!!
(@OGUID+234, 180813, 1, 14, 14, 1590.875, -4155.335, 36.29802, 3.68265, 0, 0, -0.9636297, 0.267241, 0, 0, 0, '', 6575, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+236, 180815, 1, 14, 14, 1590.853, -4155.339, 36.29916, 3.700105, 0, 0, -0.9612608, 0.2756405, 0, 0, 0, '', 6577, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
-- (@OGUID+238, 175080, 1, 14, 14, 0, 0, 0, 2.169941, 0, 0, 0.8842897, 0.4669386, 0, 0, 0, '', 3031, 303466, 0, 1048616, 0, 56770, 1, 15, 0, 0, @SNIFFID+2, 35186), --  - !!! transport !!!
(@OGUID+237, 180816, 1, 14, 14, 1590.852, -4155.341, 36.29949, 3.700105, 0, 0, -0.9612608, 0.2756405, 0, 0, 0, '', 6578, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+233, 180812, 1, 14, 14, 1590.825, -4155.328, 36.29258, 3.700105, 0, 0, -0.9612608, 0.2756405, 0, 0, 0, '', 6574, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+235, 180814, 1, 14, 14, 1590.851, -4155.342, 36.29963, 3.700105, 0, 0, -0.9612608, 0.2756405, 0, 0, 0, '', 6576, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+34, 180782, 0, 1537, 1537, -4913.723, -1225.917, 501.6507, 2.268925, 0, 0, 0.9063072, 0.4226195, 0, 0, 0, '', 6553, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+32, 180780, 0, 1537, 1537, -4913.729, -1225.951, 501.6506, 2.268925, 0, 0, 0.9063072, 0.4226195, 0, 0, 0, '', 6551, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+37, 180679, 0, 1537, 1537, -4937.289, -1282.736, 501.6721, 2.268925, 0, 0, 0.9063072, 0.4226195, 0, 0, 0, '', 6498, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+31, 180680, 0, 1537, 1537, -4913.854, -1225.997, 501.6508, 2.251473, 0, 0, 0.902585, 0.4305117, 0, 0, 0, '', 6499, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+33, 180781, 0, 1537, 1537, -4913.737, -1225.928, 501.6507, 2.268925, 0, 0, 0.9063072, 0.4226195, 0, 0, 0, '', 6552, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+30, 171553, 0, 1537, 1537, -4911.823, -1227.696, 501.606, 5.401796, 0, 0, -0.426568, 0.9044555, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+36, 171554, 0, 1537, 1537, -4931.684, -1279.032, 501.6806, 5.401796, 0, 0, -0.426568, 0.9044555, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+38, 180806, 0, 1537, 1537, -4937.136, -1282.895, 501.6721, 2.268925, 0, 0, 0.9063072, 0.4226195, 0, 0, 0, '', 6566, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+35, 143251, 0, 1537, 1537, -4925.657, -1269.889, 506.5374, 1.893679, 0, 0, 0.811573, 0.584251, 0, 0, 0, '', 636, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+44, 143255, 0, 1537, 1537, -4955.593, -1270.565, 508.418, 1.003564, 0, 0, 0.4809885, 0.8767269, 0, 0, 0, '', 639, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+71, 171525, 0, 1537, 1537, -4979.237, -1197.915, 503.9238, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 660, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+65, 171748, 0, 1537, 1537, -4845.308, -1247.751, 506.022, 5.288348, 0, 0, -0.4771585, 0.8788173, 0, 0, 0, '', 666, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+70, 171527, 0, 1537, 1537, -4979.336, -1199.216, 504.0239, 0.6894043, 0, 0, 0.3379164, 0.9411761, 0, 0, 0, '', 660, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+40, 180800, 0, 1537, 1537, -4937.282, -1282.874, 501.6723, 2.251473, 0, 0, 0.902585, 0.4305117, 0, 0, 0, '', 6560, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+48, 149412, 0, 1537, 1537, -4857.792, -1232.981, 501.726, 3.769912, 0, 0, -0.9510565, 0.3090171, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+67, 180693, 0, 1537, 1537, -4958.528, -1179.335, 501.6595, 2.251473, 0, 0, 0.902585, 0.4305117, 0, 0, 0, '', 6504, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+59, 142911, 0, 1537, 1537, -4971.469, -1281.552, 501.9786, 0.9599299, 0, 0, 0.4617481, 0.8870111, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+39, 180807, 0, 1537, 1537, -4937.286, -1282.869, 501.6723, 2.251473, 0, 0, 0.902585, 0.4305117, 0, 0, 0, '', 6567, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+60, 142912, 0, 1537, 1537, -4973.22, -1280.349, 501.9786, 0.9599299, 0, 0, 0.4617481, 0.8870111, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+53, 142914, 0, 1537, 1537, -4964.063, -1285.029, 510.31, 5.681047, 0, 0, -0.2965412, 0.9550201, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+56, 142915, 0, 1537, 1537, -4963.465, -1287.172, 510.31, 0.9686551, 0, 0, 0.4656134, 0.8849882, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+50, 142916, 0, 1537, 1537, -4960.929, -1286.992, 510.31, 2.539448, 0, 0, 0.955019, 0.2965446, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+42, 180803, 0, 1537, 1537, -4935.594, -1284.833, 501.6711, 2.251473, 0, 0, 0.902585, 0.4305117, 0, 0, 0, '', 6563, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+68, 180681, 0, 1537, 1537, -4958.509, -1179.32, 501.6595, 2.268925, 0, 0, 0.9063072, 0.4226195, 0, 0, 0, '', 6500, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+49, 171552, 0, 1537, 1537, -4970.592, -1209.667, 501.7783, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 2470, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+47, 171555, 0, 1537, 1537, -4960.584, -1274.095, 501.6389, 5.401796, 0, 0, -0.426568, 0.9044555, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+45, 171556, 0, 1537, 1537, -4949.823, -1277.372, 501.5834, 2.530723, 0, 0, 0.9537163, 0.3007079, 0, 0, 0, '', 1947, 0, 55, 0, 0, 65535, 1, 19, 0, 0, @SNIFFID+1, 35186),
(@OGUID+52, 171664, 0, 1537, 1537, -4969.41, -1278.771, 501.9786, 4.101525, 0, 0, -0.8870106, 0.4617491, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+54, 171665, 0, 1537, 1537, -4971.161, -1277.569, 501.9786, 4.101525, 0, 0, -0.8870106, 0.4617491, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+57, 171666, 0, 1537, 1537, -4966.401, -1285.253, 501.9786, 5.681047, 0, 0, -0.2965412, 0.9550201, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+58, 171667, 0, 1537, 1537, -4965.735, -1287.7, 501.9786, 0.9686551, 0, 0, 0.4656134, 0.8849882, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+55, 171668, 0, 1537, 1537, -4963.396, -1287.289, 501.9786, 2.539448, 0, 0, 0.955019, 0.2965446, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+51, 171669, 0, 1537, 1537, -4963.879, -1285.016, 501.9786, 4.11025, 0, 0, -0.8849878, 0.4656141, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+66, 180692, 0, 1537, 1537, -4958.517, -1179.334, 501.6595, 2.268925, 0, 0, 0.9063072, 0.4226195, 0, 0, 0, '', 6503, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+64, 171670, 0, 1537, 1537, -4976.345, -1283.114, 510.3231, 0.9512032, 0, 0, 0.4578733, 0.8890174, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+62, 171671, 0, 1537, 1537, -4973.886, -1282.491, 510.3231, 2.521998, 0, 0, 0.9523954, 0.3048655, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+63, 171672, 0, 1537, 1537, -4976.537, -1280.588, 510.3231, 5.663594, 0, 0, -0.3048639, 0.9523959, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+61, 171673, 0, 1537, 1537, -4974.257, -1280.145, 510.3231, 4.092797, 0, 0, -0.8890171, 0.457874, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+69, 180694, 0, 1537, 1537, -4958.526, -1179.327, 501.6595, 2.268925, 0, 0, 0.9063072, 0.4226195, 0, 0, 0, '', 6505, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+41, 180801, 0, 1537, 1537, -4935.58, -1284.82, 501.6711, 2.251473, 0, 0, 0.902585, 0.4305117, 0, 0, 0, '', 6561, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+43, 180802, 0, 1537, 1537, -4935.604, -1284.838, 501.6711, 2.251473, 0, 0, 0.902585, 0.4305117, 0, 0, 0, '', 6562, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+46, 143250, 0, 1537, 1537, -4866.551, -1238.395, 501.726, 3.769912, 0, 0, -0.9510565, 0.3090171, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+86, 180714, 0, 1537, 1537, -4976.292, -1158.748, 501.6425, 0.8552105, 0, 0, 0.4146929, 0.9099615, 0, 0, 0, '', 6448, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+75, 171746, 0, 1537, 1537, -4863.045, -1172.481, 504.1971, 0.2007113, 0, 0, 0.1001873, 0.9949686, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+78, 171747, 0, 1537, 1537, -4860.679, -1170.29, 504.1971, 3.953173, 0, 0, -0.9187908, 0.3947448, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+90, 180714, 0, 1537, 1537, -4972.807, -1145.831, 501.65, 3.612838, 0, 0, -0.9723692, 0.2334484, 0, 0, 0, '', 6448, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+72, 171526, 0, 1537, 1537, -4980.521, -1197.818, 504.0239, 3.831001, 0, 0, -0.9411755, 0.3379182, 0, 0, 0, '', 660, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+94, 180714, 0, 1537, 1537, -4979.967, -1146.89, 501.6551, 4.206246, 0, 0, -0.8616285, 0.5075394, 0, 0, 0, '', 6448, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+74, 171749, 0, 1537, 1537, -4844.61, -1282.684, 505.1968, 1.40499, 0, 0, 0.6461239, 0.7632326, 0, 0, 0, '', 659, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+76, 171750, 0, 1537, 1537, -4839.753, -1286.232, 501.8703, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+88, 180714, 0, 1537, 1537, -4977.455, -1157.944, 501.6493, 3.926996, 0, 0, -0.9238787, 0.3826855, 0, 0, 0, '', 6448, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+73, 171753, 0, 1537, 1537, -4858.435, -1300.343, 501.8703, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+79, 171754, 0, 1537, 1537, -4847.715, -1301.998, 501.8703, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+93, 180675, 0, 1537, 1537, -4969.209, -1143.843, 509.2506, 2.286379, 0, 0, 0.9099607, 0.4146944, 0, 0, 0, '', 6494, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+84, 142851, 0, 1537, 1537, -4835.162, -1187.253, 502.49, 1.256636, 0, 0, 0.5877848, 0.8090174, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+77, 176573, 0, 1537, 1537, -5007.49, -1240.816, 518.1741, 5.305802, 0, 0, -0.469471, 0.8829479, 0, 0, 0, '', 3972, 0, 114, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+97, 180714, 0, 1537, 1537, -4985.743, -1137.549, 501.6594, 3.543024, 0, 0, -0.9799242, 0.1993704, 0, 0, 0, '', 6448, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+89, 180598, 0, 1537, 1537, -4971.548, -1148.571, 501.648, 2.286379, 0, 0, 0.9099607, 0.4146944, 0, 0, 0, '', 6491, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+87, 180674, 0, 1537, 1537, -4968.327, -1152.889, 501.9254, 2.268925, 0, 0, 0.9063072, 0.4226195, 0, 0, 0, '', 6493, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+96, 180676, 0, 1537, 1537, -4983.004, -1136.219, 501.6594, 2.303831, 0, 0, 0.9135447, 0.4067384, 0, 0, 0, '', 6495, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+95, 180714, 0, 1537, 1537, -4979.926, -1139.911, 501.6595, 1.361356, 0, 0, 0.6293201, 0.7771462, 0, 0, 0, '', 6448, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+85, 171557, 0, 1537, 1537, -4973.903, -1159.038, 501.6116, 5.401796, 0, 0, -0.426568, 0.9044555, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+92, 180714, 0, 1537, 1537, -4972.919, -1145.821, 504.1289, 1.762782, 0, 0, 0.7716246, 0.6360782, 0, 0, 0, '', 6448, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+81, 171736, 0, 1537, 1537, -4838.071, -1187.068, 509.1369, 2.801249, 0, 0, 0.9855556, 0.169352, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+82, 171737, 0, 1537, 1537, -4839.203, -1185.153, 509.1369, 4.372049, 0, 0, -0.8166418, 0.5771448, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+80, 171738, 0, 1537, 1537, -4841.605, -1185.983, 509.1369, 5.942846, 0, 0, -0.1693497, 0.985556, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+83, 176573, 0, 1537, 1537, -4823.931, -1232.634, 526.6171, 1.640607, 0, 0, 0.7313528, 0.6819993, 0, 0, 0, '', 3972, 0, 114, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+91, 180714, 0, 1537, 1537, -4972.857, -1145.846, 502.8929, 2.199115, 0, 0, 0.8910065, 0.4539906, 0, 0, 0, '', 6448, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+242, 180828, 1, 14, 14, 1579.321, -4109.278, 34.55151, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 6588, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+244, 180830, 1, 14, 14, 1579.333, -4109.278, 34.5475, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 6590, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+241, 180827, 1, 14, 14, 1579.334, -4109.248, 34.54871, 3.717554, 0, 0, -0.9588194, 0.2840165, 0, 0, 0, '', 6587, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+243, 180829, 1, 14, 14, 1579.333, -4109.284, 34.54703, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 6589, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+240, 180826, 1, 14, 14, 1579.353, -4109.254, 34.54174, 3.752462, 0, 0, -0.9537163, 0.3007079, 0, 0, 0, '', 6586, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+99, 171638, 0, 1537, 1537, -5031.002, -1252.47, 505.2946, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+100, 171639, 0, 1537, 1537, -5023.399, -1261.693, 505.2946, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+98, 171559, 0, 1537, 1537, -5023.607, -1206.498, 501.6055, 5.401796, 0, 0, -0.426568, 0.9044555, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+245, 173013, 1, 14, 14, 1408.853, -4359.428, 25.28924, 4.049168, 0, 0, -0.8987932, 0.4383728, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+101, 171751, 0, 1537, 1537, -4828.336, -1287.588, 501.8703, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+102, 171752, 0, 1537, 1537, -4828.278, -1285.047, 501.8071, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 2190, 0, 55, 0, 0, 65535, 1, 19, 0, 0, @SNIFFID+1, 35186),
(@OGUID+103, 1685, 0, 1537, 1537, -4816.339, -1250.142, 501.9047, 1.954769, 0, 0, 0.8290377, 0.5591928, 0, 0, 0, '', 209, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+246, 173011, 1, 14, 14, 1426.406, -4394.383, 25.28924, 4.049168, 0, 0, -0.8987932, 0.4383728, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+247, 173009, 1, 14, 14, 1428.534, -4412.338, 25.28923, 4.049168, 0, 0, -0.8987932, 0.4383728, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+106, 180397, 0, 1537, 1537, -5035.026, -1263.471, 505.3, 0.6981314, 0, 0, 0.34202, 0.9396927, 0, 0, 0, '', 6135, 0, 1375, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+105, 180400, 0, 1537, 1537, -5034.64, -1263.188, 506.7167, 3.857183, 0, 0, -0.9366713, 0.3502098, 0, 0, 0, '', 6390, 0, 1375, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+104, 171641, 0, 1537, 1537, -5026.757, -1289.012, 507.7141, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+251, 180832, 1, 14, 14, 1619.831, -4092.43, 34.51068, 3.700105, 0, 0, -0.9612608, 0.2756405, 0, 0, 0, '', 6592, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+249, 173008, 1, 14, 14, 1457.858, -4427.24, 25.28924, 4.049168, 0, 0, -0.8987932, 0.4383728, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+248, 173010, 1, 14, 14, 1430.615, -4430.636, 25.28923, 4.049168, 0, 0, -0.8987932, 0.4383728, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+252, 180833, 1, 14, 14, 1619.8, -4092.533, 34.48882, 3.700105, 0, 0, -0.9612608, 0.2756405, 0, 0, 0, '', 6593, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+250, 173012, 1, 14, 14, 1438.433, -4373.887, 25.28924, 4.049168, 0, 0, -0.8987932, 0.4383728, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+255, 180836, 1, 14, 14, 1619.806, -4092.531, 34.48937, 3.700105, 0, 0, -0.9612608, 0.2756405, 0, 0, 0, '', 6596, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+254, 180835, 1, 14, 14, 1619.807, -4092.527, 34.49014, 3.700105, 0, 0, -0.9612608, 0.2756405, 0, 0, 0, '', 6595, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+253, 180834, 1, 14, 14, 1619.8, -4092.532, 34.4892, 3.700105, 0, 0, -0.9612608, 0.2756405, 0, 0, 0, '', 6594, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+256, 177018, 1, 14, 14, 1495.128, -4382.213, 24.24479, 1.314898, 0.1094384, 0.08594227, 0.6050262, 0.7839518, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+257, 180838, 1, 1637, 1637, 1683.115, -4134.354, 39.54191, 3.717554, 0, 0, -0.9588194, 0.2840165, 0, 0, 0, '', 6598, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+261, 180820, 1, 1637, 1637, 1637.111, -4147.253, 36.05357, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 6582, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+264, 180822, 1, 1637, 1637, 1637.079, -4147.228, 36.04483, 3.717554, 0, 0, -0.9588194, 0.2840165, 0, 0, 0, '', 6584, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+263, 180840, 1, 1637, 1637, 1683.097, -4134.3, 39.53874, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 6600, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+265, 180841, 1, 1637, 1637, 1683.106, -4134.313, 39.54028, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 6601, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+267, 176562, 1, 1637, 1637, 1634.873, -4247.857, 55.83972, 4.197518, 0, 0, -0.8638353, 0.5037743, 0, 0, 0, '', 4412, 0, 0, 32, 0, 65535, 1, 0, 0, 0, @SNIFFID+2, 35186),
(@OGUID+260, 180839, 1, 1637, 1637, 1683.098, -4134.31, 39.539, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 6599, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+268, 172957, 1, 1637, 1637, 1494.563, -4423.778, 26.77953, 0.1396264, 0, 0, 0.06975651, 0.9975641, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+269, 172958, 1, 1637, 1637, 1494.563, -4423.778, 25.69826, 0.1396264, 0, 0, 0.06975651, 0.9975641, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+270, 172959, 1, 1637, 1637, 1494.661, -4423.747, 24.58737, 0.1396264, 0, 0, 0.06975651, 0.9975641, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+271, 172960, 1, 1637, 1637, 1500.388, -4423.778, 26.14783, 6.204646, 0, 0, -0.03925991, 0.9992291, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+272, 172961, 1, 1637, 1637, 1500.388, -4423.778, 25.06656, 6.204646, 0, 0, -0.03925991, 0.9992291, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+258, 180818, 1, 1637, 1637, 1637.105, -4147.213, 36.04144, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 6580, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+259, 180819, 1, 1637, 1637, 1637.1, -4147.253, 36.05312, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 6581, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+266, 180842, 1, 1637, 1637, 1683.035, -4134.313, 39.52796, 3.717554, 0, 0, -0.9588194, 0.2840165, 0, 0, 0, '', 6602, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+262, 180821, 1, 1637, 1637, 1637.11, -4147.257, 36.05472, 3.752462, 0, 0, -0.9537163, 0.3007079, 0, 0, 0, '', 6583, 0, 0, 32, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+20, 160426, 1, 1638, 1638, -1227.377, -19.87717, 165.325, 3.141593, 0, 0, -1, 0, 0, 0, 0, '', 201, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+0, 35186),
(@OGUID+23, 177265, 1, 1638, 1638, -1123.408, 66.32016, 149.4445, 4.424408, 0, 0, -0.8012543, 0.598324, 0, 0, 0, '', 4716, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+0, 35186),
(@OGUID+22, 3303, 1, 1638, 1638, -1173.283, -26.30159, 164.4883, 1.317723, 0, 0, 0.6122169, 0.7906898, 0, 0, 0, '', 192, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+0, 35186),
(@OGUID+21, 3315, 1, 1638, 1638, -1221.876, -18.07404, 165.4112, 3.115388, 0, 0, 0.9999142, 0.01310196, 0, 0, 0, '', 216, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+0, 35186),
(@OGUID+274, 177017, 1, 1637, 1637, 1510.944, -4433.988, 19.7736, 1.300728, 0.01735353, 0.01301193, 0.6053362, 0.7956743, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+275, 173112, 1, 1637, 1637, 1516.763, -4349.397, 18.66949, 3.106652, 0, 0, 0.9998474, 0.01746928, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+273, 173200, 1, 1637, 1637, 1520.579, -4428.062, 17.66887, 0.4014249, 0, 0, 0.1993675, 0.9799248, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+276, 173203, 1, 1637, 1637, 1526.926, -4366.508, 17.87228, 5.471609, 0, 0, -0.394743, 0.9187916, 0, 0, 0, '', 710, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+24, 178571, 1, 1638, 1638, -1207.632, -66.43886, 157.4903, 3.246347, 0, 0, -0.9986286, 0.05235322, 0, 0, 0, '', 1967, 0, 114, 0, 0, 65535, 1, 1, 0, 0, @SNIFFID+0, 35186),
(@OGUID+25, 177266, 1, 1638, 1638, -1108.164, -11.29569, 148.629, 1.841321, 0, 0, 0.7960014, 0.6052947, 0, 0, 0, '', 4717, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+0, 35186),
(@OGUID+277, 173197, 1, 1637, 1637, 1568.637, -4408.592, 7.490322, 0.2530704, 0, 0, 0.1261978, 0.9920051, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+279, 173198, 1, 1637, 1637, 1555.237, -4384.333, 3.20385, 0.9512032, 0, 0, 0.4578733, 0.8890174, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+280, 173199, 1, 1637, 1637, 1537.416, -4377.832, 16.7027, 0.7853989, 0, 0, 0.3826838, 0.9238794, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+278, 179881, 1, 1637, 1637, 1537.892, -4421.62, 7.553038, 5.131269, 0, 0, -0.5446386, 0.8386708, 0, 0, 0, '', 5951, 0, 114, 0, 0, 65535, 0, 1, 0, 0, @SNIFFID+2, 35186),
(@OGUID+284, 173204, 1, 1637, 1637, 1570.728, -4355.521, 1.387888, 0.9512054, 0, 0, 0.4578743, 0.889017, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+285, 173206, 1, 1637, 1637, 1596.161, -4385.234, 9.792974, 0.4014249, 0, 0, 0.1993675, 0.9799248, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+283, 177019, 1, 1637, 1637, 1592.366, -4427.324, 8.053005, 0.087266, 0, 0, 0.04361916, 0.9990482, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+286, 177020, 1, 1637, 1637, 1608.969, -4447.554, 8.13558, 1.300268, 0, 0, 0.6052933, 0.7960025, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+281, 177024, 1, 1637, 1637, 1555.504, -4355.754, 0.4912586, 1.300268, 0, 0, 0.6052933, 0.7960025, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+282, 173202, 1, 1637, 1637, 1585.993, -4449.311, 5.978842, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 717, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+287, 173207, 1, 1637, 1637, 1548.712, -4325.491, 20.70066, 0.8901166, 0, 0, 0.4305105, 0.9025856, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+288, 173216, 1, 1637, 1637, 1613.294, -4388.236, 10.1155, 3.630291, 0, 0, -0.970295, 0.241925, 0, 0, 0, '', 708, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+289, 173221, 1, 1637, 1637, 1615.584, -4391.602, 10.10802, 3.944446, 0, 0, -0.9205046, 0.3907318, 0, 0, 0, '', 2128, 0, 29, 0, 0, 65535, 1, 19, 0, 0, @SNIFFID+2, 35186),
(@OGUID+26, 35591, 1, 1638, 1638, -1256.209, 98.33792, 127.8864, 5.384641, 0, 0, -0.43431, 0.9007635, 1, @PGUID+6, 0, 'Player', 668, 1, 6, 0, 0, 65535, 1, 17, 0, 0, @SNIFFID+0, 35186),
(@OGUID+290, 173226, 1, 1637, 1637, 1626.658, -4387.851, 12.27098, 2.670348, 0, 0, 0.9723692, 0.2334484, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+292, 173225, 1, 1637, 1637, 1618.125, -4365.355, 12.19473, 2.670348, 0, 0, 0.9723692, 0.2334484, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+291, 173114, 1, 1637, 1637, 1635.837, -4450.783, 15.53622, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+293, 173115, 1, 1637, 1637, 1639.726, -4438.375, 15.53622, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+294, 173205, 1, 1637, 1637, 1604.899, -4343.5, 3.226416, 0.9512054, 0, 0, 0.4578743, 0.889017, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+295, 173215, 1, 1637, 1637, 1613.344, -4346.475, 4.102684, 2.783795, 0, 0, 0.9840403, 0.177946, 0, 0, 0, '', 707, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+296, 173223, 1, 1637, 1637, 1644.119, -4376.146, 12.77893, 3.665196, 0, 0, -0.9659252, 0.2588213, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+297, 173224, 1, 1637, 1637, 1637.595, -4361.304, 12.33452, 2.670348, 0, 0, 0.9723692, 0.2334484, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+299, 180394, 1, 1637, 1637, 1657.461, -4385.404, 23.57973, 5.270896, 0, 0, -0.4848089, 0.8746201, 0, 0, 0, '', 6707, 0, 1375, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+298, 173106, 1, 1637, 1637, 1636.694, -4351.038, 4.470037, 3.665196, 0, 0, -0.9659252, 0.2588213, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+28, 177267, 1, 1638, 1638, -1179.594, -93.41329, 168.539, 2.539448, 0, 0, 0.955019, 0.2965446, 0, 0, 0, '', 4717, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+0, 35186),
(@OGUID+27, 177268, 1, 1638, 1638, -1237.659, -90.5968, 169.0329, 0.4886893, 0, 0, 0.2419205, 0.9702961, 0, 0, 0, '', 4718, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+0, 35186),
(@OGUID+300, 172965, 1, 1637, 1637, 1666.792, -4391.713, 24.90455, 1.727875, 0, 0, 0.7604055, 0.6494485, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+303, 173208, 1, 1637, 1637, 1617.57, -4322.309, 2.044983, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 409, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+304, 173217, 1, 1637, 1637, 1625.363, -4322.417, 1.770067, 3.900813, 0, 0, -0.9288092, 0.3705584, 0, 0, 0, '', 709, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+305, 173219, 1, 1637, 1637, 1653.815, -4350.22, 26.82525, 4.24988, 0, 0, -0.8503513, 0.5262154, 0, 0, 0, '', 710, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+302, 173220, 1, 1637, 1637, 1573.01, -4308.577, 22.63247, 3.935722, 0, 0, -0.9222002, 0.3867128, 0, 0, 0, '', 710, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+301, 173222, 1, 1637, 1637, 1671.67, -4426.377, 17.94371, 1.954769, 0, 0, 0.8290377, 0.5591928, 0, 0, 0, '', 710, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+306, 173218, 1, 1637, 1637, 1677.197, -4410.67, 19.35103, 3.612838, 0, 0, -0.9723692, 0.2334484, 0, 0, 0, '', 707, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+307, 173111, 1, 1637, 1637, 1615.659, -4314.004, 3.196878, 4.921829, 0, 0, -0.6293201, 0.7771462, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+308, 177026, 1, 1637, 1637, 1665.501, -4360.834, 26.6592, 1.306526, -0.05437326, -0.02162361, 0.6074505, 0.7921994, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+311, 173209, 1, 1637, 1637, 1637.324, -4311.271, 0.8411827, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 409, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+312, 173214, 1, 1637, 1637, 1661.732, -4339.47, 61.15748, 3.900813, 0, 0, -0.9288092, 0.3705584, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+309, 173107, 1, 1637, 1637, 1620.571, -4305.246, 3.068817, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 331, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+310, 173109, 1, 1637, 1637, 1611.804, -4302.142, 3.011496, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 409, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+313, 175885, 1, 1637, 1637, 1664.674, -4345.983, 40.36586, 4.171338, 0, 0, -0.8703556, 0.4924237, 0, 0, 0, '', 3972, 0, 114, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+314, 180394, 1, 1637, 1637, 1663.588, -4343.188, 61.24616, 0.7504908, 0, 0, 0.3665009, 0.9304177, 0, 0, 0, '', 6707, 0, 1375, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+315, 177022, 1, 1637, 1637, 1654.933, -4315.176, 2.078587, 2.347464, 0, 0, 0.9222002, 0.3867128, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+317, 173108, 1, 1637, 1637, 1627.123, -4299.514, 3.068365, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 409, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+316, 173110, 1, 1637, 1637, 1629.495, -4301.75, 3.196878, 4.459317, 0, 0, -0.7906895, 0.6122174, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+319, 173113, 1, 1637, 1637, 1581.327, -4295.075, 26.07761, 4.118979, 0, 0, -0.882947, 0.4694727, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+318, 173125, 1, 1637, 1637, 1676.384, -4336.087, 32.3788, 3.368496, 0, 0, -0.9935713, 0.1132084, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+322, 173210, 1, 1637, 1637, 1685.003, -4344.484, 61.15748, 4.214974, 0, 0, -0.8594055, 0.5112946, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+320, 173211, 1, 1637, 1637, 1657.958, -4309.969, 2.419538, 0.9512054, 0, 0, 0.4578743, 0.889017, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+321, 173212, 1, 1637, 1637, 1665.068, -4325.222, 61.15748, 3.900813, 0, 0, -0.9288092, 0.3705584, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+323, 172966, 1, 1637, 1637, 1665.113, -4318.868, 65.00435, 1.53589, 0, 0, 0.6946583, 0.7193398, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+324, 177021, 1, 1637, 1637, 1704.627, -4339.796, 24.63208, 3.796093, 0, 0, -0.9469299, 0.32144, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+328, 173213, 1, 1637, 1637, 1682.254, -4323.061, 61.15748, 3.900813, 0, 0, -0.9288092, 0.3705584, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+327, 172962, 1, 1637, 1637, 1724.033, -4375.561, 34.40444, 5.009097, 0, 0, -0.5948219, 0.8038574, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+326, 172963, 1, 1637, 1637, 1724.033, -4375.561, 33.32317, 5.009097, 0, 0, -0.5948219, 0.8038574, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+325, 172964, 1, 1637, 1637, 1724.079, -4375.653, 32.21228, 5.009097, 0, 0, -0.5948219, 0.8038574, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+108, 143336, 0, 1537, 1537, -4862.728, -1148.929, 506.6866, 0.4188786, 0, 0, 0.2079115, 0.9781476, 0, 0, 0, '', 642, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+107, 143254, 0, 1537, 1537, -5028.502, -1187.637, 506.2094, 0.5235979, 0, 0, 0.2588186, 0.9659259, 0, 0, 0, '', 638, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+331, 177025, 1, 1637, 1637, 1739.518, -4380.445, 34.72054, 3.798138, 0.02405977, -0.03101635, -0.9460239, 0.3217107, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+329, 172953, 1, 1637, 1637, 1733.02, -4424.7, 36.90484, 1.047198, 0, 0, 0.5, 0.8660254, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+330, 172967, 1, 1637, 1637, 1732.304, -4357.576, 34.28072, 1.317723, 0, 0, 0.6122169, 0.7906898, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+110, 32404, 0, 1537, 1537, -4870.763, -1135.597, 502.1872, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+111, 32429, 0, 1537, 1537, -4846.844, -1159.434, 502.1872, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+109, 143249, 0, 1537, 1537, -5023.996, -1156.325, 505.4127, 4.956738, 0, 0, -0.6156607, 0.7880114, 0, 0, 0, '', 635, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+337, 173164, 1, 1637, 1637, 1743.324, -4327.312, 5.889883, 2.617989, 0, 0, 0.9659252, 0.2588213, 0, 0, 0, '', 475, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+335, 179739, 1, 1637, 1637, 1695.054, -4290.507, 33.25554, 1.483528, 0, 0, 0.6755896, 0.7372779, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+338, 173171, 1, 1637, 1637, 1779.918, -4369.311, -16.34259, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+339, 173174, 1, 1637, 1637, 1780.968, -4365.102, -16.13359, 6.265733, 0, 0, -0.00872612, 0.9999619, 0, 0, 0, '', 713, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+340, 173176, 1, 1637, 1637, 1769.606, -4333.745, -8.319939, 4.32842, 0, 0, -0.8290367, 0.5591941, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+334, 173006, 1, 1637, 1637, 1729.757, -4315.75, 29.0657, 4.869471, 0, 0, -0.6494474, 0.7604064, 0, 0, 0, '', 711, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+336, 173116, 1, 1637, 1637, 1742.334, -4314.654, 33.21526, 3.848456, 0, 0, -0.9381905, 0.3461194, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+332, 172952, 1, 1637, 1637, 1746.712, -4415.493, 36.90484, 1.047198, 0, 0, 0.5, 0.8660254, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+333, 172968, 1, 1637, 1637, 1695.054, -4290.507, 34.24478, 1.483528, 0, 0, 0.6755896, 0.7372779, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+341, 173168, 1, 1637, 1637, 1763.933, -4317.851, 6.201803, 0.56723, 0, 0, 0.2798281, 0.9600501, 0, 0, 0, '', 707, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+343, 173166, 1, 1637, 1637, 1760.989, -4301.215, 6.975302, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+344, 175313, 1, 1637, 1637, 1800.164, -4371.602, -17.51358, 3.377225, 0, 0, -0.9930677, 0.1175435, 0, 0, 0, '', 475, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+345, 175318, 1, 1637, 1637, 1797.984, -4397.187, -17.81583, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+342, 173102, 1, 1637, 1637, 1733.049, -4285.257, 16.69807, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+346, 105576, 1, 1637, 1637, 1805.834, -4373.972, -17.49562, 5.515242, 0, 0, -0.3746061, 0.927184, 0, 0, 0, '', 465, 0, 35, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+347, 172945, 1, 1637, 1637, 1736.645, -4476.899, 32.03783, 4.572767, 0, 0, -0.7547083, 0.6560605, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+348, 179596, 1, 1637, 1637, 1818.302, -4402.073, -17.82751, 2.687807, 0, 0, 0.97437, 0.2249513, 0, 0, 0, '', 5498, 0, 35, 0, 0, 65535, 1, 23, 0, 0, @SNIFFID+2, 35186),
(@OGUID+349, 173026, 1, 1637, 1637, 1768.762, -4482.937, 45.39897, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 409, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+350, 173027, 1, 1637, 1637, 1776.197, -4480.384, 45.50554, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+353, 175317, 1, 1637, 1637, 1817.408, -4359.194, -9.826214, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+351, 172941, 1, 1637, 1637, 1766.302, -4497.006, 44.48079, 3.874631, 0, 0, -0.9335804, 0.358368, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+352, 173016, 1, 1637, 1637, 1763.442, -4494.941, 44.31033, 2.652894, 0, 0, 0.970295, 0.241925, 0, 0, 0, '', 709, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+29, 35591, 1, 1638, 1638, -1253.983, 92.078, 127.8864, 5.132061, 0, 0, -0.5443068, 0.8388863, 1, @PGUID+6, 0, 'Player', 668, 1, 6, 0, 0, 65535, 1, 17, 0, 0, @SNIFFID+0, 35186),
(@OGUID+359, 175315, 1, 1637, 1637, 1831.721, -4404.972, 4.736029, 3.463985, -0.02164173, -0.009085655, -0.9867439, 0.1605787, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+354, 172942, 1, 1637, 1637, 1798.625, -4496.636, 45.68591, 4.319691, 0, 0, -0.8314695, 0.5555704, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+355, 173014, 1, 1637, 1637, 1784.886, -4495.344, 45.17732, 3.728011, 0.01541424, 0.0666399, -0.9544926, 0.2902851, 0, 0, 0, '', 409, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+356, 173015, 1, 1637, 1637, 1782.194, -4497.987, 44.86251, 3.738895, 0.05197573, -0.005094528, -0.9547157, 0.2929001, 0, 0, 0, '', 409, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+357, 173017, 1, 1637, 1637, 1761.812, -4511.88, 26.47026, 2.417279, 0, 0, 0.9351349, 0.3542919, 0, 0, 0, '', 710, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+358, 173029, 1, 1637, 1637, 1778.936, -4495.758, 27.58802, 4.092802, 0, 0, -0.8890162, 0.4578758, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+113, 171643, 0, 1537, 1537, -5058.561, -1250.431, 507.7141, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+112, 171558, 0, 1537, 1537, -5035.626, -1158.799, 501.6228, 5.401796, 0, 0, -0.426568, 0.9044555, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+114, 171640, 0, 1537, 1537, -5048.859, -1280.776, 501.9626, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+117, 171658, 0, 1537, 1537, -5058.271, -1165.865, 503.695, 5.960299, 0, 0, -0.1607428, 0.9869964, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+116, 171659, 0, 1537, 1537, -5055.126, -1165.149, 503.695, 3.429581, 0, 0, -0.9896507, 0.1434972, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+115, 171642, 0, 1537, 1537, -5054.797, -1273.573, 501.9626, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+360, 173019, 1, 1637, 1637, 1757.449, -4533.911, 28.04874, 2.949595, 0, 0, 0.9953957, 0.09585124, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+364, 173037, 1, 1637, 1637, 1833.626, -4472.106, 47.42968, 3.455756, 0, 0, -0.9876881, 0.1564362, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+361, 172946, 1, 1637, 1637, 1826.975, -4508.035, 21.37659, 3.848456, 0, 0, -0.9381905, 0.3461194, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+362, 172954, 1, 1637, 1637, 1800.967, -4513.685, 21.56395, 3.010666, 0, 0, 0.997858, 0.06541648, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+363, 173028, 1, 1637, 1637, 1786.777, -4508.488, 27.51361, 4.293509, 0, 0, -0.8386707, 0.5446388, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+365, 173036, 1, 1637, 1637, 1841.131, -4458.719, 47.5035, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186);

INSERT INTO `gameobject` (`guid`, `id`, `map`, `zone_id`, `area_id`, `position_x`, `position_y`, `position_z`, `orientation`, `rotation0`, `rotation1`, `rotation2`, `rotation3`, `is_temporary`, `creator_guid`, `creator_id`, `creator_type`, `display_id`, `level`, `faction`, `flags`, `dynamic_flags`, `path_progress`, `state`, `type`, `artkit`, `custom_param`, `sniff_id`, `sniff_build`) VALUES
(@OGUID+366, 173018, 1, 1637, 1637, 1814.154, -4540.271, 21.17592, 1.457349, 0, 0, 0.6658812, 0.7460579, 0, 0, 0, '', 712, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+367, 173030, 1, 1637, 1637, 1791.086, -4557.931, 22.85476, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+368, 173031, 1, 1637, 1637, 1815.541, -4556.472, 22.85476, 4.520403, 0, 0, -0.7716246, 0.6360782, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+369, 173032, 1, 1637, 1637, 1796.534, -4575.206, 22.85476, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+371, 173044, 1, 1637, 1637, 1837.779, -4552.43, 22.98787, 1.954766, 0, 0, 0.8290367, 0.5591941, 0, 0, 0, '', 712, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+372, 172948, 1, 1637, 1637, 1855.11, -4474.312, 47.49619, 4.302239, 0, 0, -0.8362856, 0.5482941, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+370, 173033, 1, 1637, 1637, 1813.523, -4574.063, 22.85476, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+373, 173043, 1, 1637, 1637, 1854.696, -4546.157, 25.42025, 2.940878, 0, 0, 0.9949684, 0.100189, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+374, 173035, 1, 1637, 1637, 1844.256, -4568.069, 24.80417, 3.935722, 0, 0, -0.9222002, 0.3867128, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+375, 172955, 1, 1637, 1637, 1871.62, -4520.998, 26.79735, 4.319691, 0, 0, -0.8314695, 0.5555704, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+376, 175885, 1, 1637, 1637, 1878.076, -4505.276, 25.42028, 0.5759573, 0, 0, 0.2840147, 0.9588199, 0, 0, 0, '', 3972, 0, 114, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+378, 172982, 1, 1637, 1637, 1880.326, -4535.972, 30.8068, 3.054327, 0, 0, 0.9990482, 0.04361926, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+379, 172983, 1, 1637, 1637, 1880.711, -4535.49, 30.34355, 1.780234, 0, 0, 0.7771454, 0.6293211, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+380, 172984, 1, 1637, 1637, 1881.273, -4536.242, 29.58476, 5.628688, 0, 0, -0.3214388, 0.9469303, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+381, 172985, 1, 1637, 1637, 1881.175, -4535.693, 30.81381, 0.7330382, 0, 0, 0.3583679, 0.9335805, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+382, 172986, 1, 1637, 1637, 1880.326, -4535.972, 29.71575, 3.054327, 0, 0, 0.9990482, 0.04361926, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+383, 172987, 1, 1637, 1637, 1886.236, -4484.233, 23.68707, 1.518436, 0, 0, 0.6883545, 0.7253745, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+384, 172988, 1, 1637, 1637, 1885.634, -4484.753, 24.15032, 3.281239, 0, 0, -0.9975634, 0.06976615, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+385, 172989, 1, 1637, 1637, 1886.383, -4485.164, 22.92828, 5.070184, 0, 0, -0.5699959, 0.8216476, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+386, 172990, 1, 1637, 1637, 1886.591, -4484.646, 24.15733, 0.1745321, 0, 0, 0.08715534, 0.9961947, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+387, 172991, 1, 1637, 1637, 1885.634, -4484.753, 23.05927, 3.281239, 0, 0, -0.9975634, 0.06976615, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+377, 173034, 1, 1637, 1637, 1865.539, -4559.364, 24.86691, 3.071766, 0, 0, 0.9993906, 0.03490613, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+388, 173103, 1, 1637, 1637, 1855.125, -4422.155, 6.871222, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+389, 173020, 1, 1637, 1637, 1885.801, -4454.529, 50.83451, 2.975771, 0, 0, 0.9965649, 0.08281587, 0, 0, 0, '', 713, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+390, 173105, 1, 1637, 1637, 1888.194, -4451.45, 19.37534, 3.569199, 0, 0, -0.977231, 0.212178, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+118, 171535, 0, 1537, 1537, -4988.844, -1108.411, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+119, 171536, 0, 1537, 1537, -5022.021, -1116.977, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+120, 171650, 0, 1537, 1537, -5022.181, -1127.521, 511.9896, 3.316144, 0, 0, -0.9961939, 0.08716504, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+121, 171651, 0, 1537, 1537, -5025.386, -1127.875, 511.9896, 5.846856, 0, 0, -0.2164383, 0.9762963, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+391, 173046, 1, 1637, 1637, 1894.742, -4559.662, 30.01842, 1.352627, 0, 0, 0.6259222, 0.7798855, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+392, 173047, 1, 1637, 1637, 1894.966, -4553.875, 29.15346, 2.155482, 0, 0, 0.8808908, 0.4733195, 0, 0, 0, '', 2128, 0, 29, 0, 0, 65535, 1, 19, 0, 0, @SNIFFID+2, 35186),
(@OGUID+394, 173053, 1, 1637, 1637, 1909.752, -4461.533, 53.31352, 4.651303, 0, 0, -0.7283707, 0.6851833, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+393, 172947, 1, 1637, 1637, 1901.55, -4439.026, 49.26829, 3.848456, 0, 0, -0.9381905, 0.3461194, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+395, 173045, 1, 1637, 1637, 1912.645, -4547.586, 30.09669, 1.352627, 0, 0, 0.6259222, 0.7798855, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+399, 173055, 1, 1637, 1637, 1922.931, -4518.171, 29.11518, 4.223697, 0, 0, -0.8571672, 0.5150382, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+401, 175314, 1, 1637, 1637, 1844.566, -4394.105, 4.598091, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+400, 173104, 1, 1637, 1637, 1888.354, -4416.648, 11.97456, 3.351047, 0, 0, -0.9945211, 0.1045355, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+396, 172949, 1, 1637, 1637, 1919.03, -4453.215, 23.05253, 4.302239, 0, 0, -0.8362856, 0.5482941, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+397, 173023, 1, 1637, 1637, 1929.075, -4499.707, 27.21142, 5.506516, 0, 0, -0.3786478, 0.9255409, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+398, 173024, 1, 1637, 1637, 1925.877, -4502.005, 27.05202, 2.295104, 0, 0, 0.9117613, 0.4107205, 0, 0, 0, '', 710, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+402, 173048, 1, 1637, 1637, 1916.48, -4428.22, 24.63837, 4.153885, 0, 0, -0.8746195, 0.4848101, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+403, 173054, 1, 1637, 1637, 1933.275, -4510.886, 29.11518, 3.569199, 0, 0, -0.977231, 0.212178, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+404, 173021, 1, 1637, 1637, 1942.49, -4481.446, 25.39169, 2.940878, 0, 0, 0.9949684, 0.100189, 0, 0, 0, '', 711, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+405, 173038, 1, 1637, 1637, 1920.522, -4570.009, 33.94439, 2.95833, 0, 0, 0.9958048, 0.09150324, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+406, 173040, 1, 1637, 1637, 1901.62, -4593.539, 33.94437, 2.95833, 0, 0, 0.9958048, 0.09150324, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+407, 173041, 1, 1637, 1637, 1886.242, -4603.912, 33.94437, 2.95833, 0, 0, 0.9958048, 0.09150324, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+408, 173039, 1, 1637, 1637, 1920.584, -4591.22, 33.94439, 2.95833, 0, 0, 0.9958048, 0.09150324, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+409, 173049, 1, 1637, 1637, 1956.845, -4468.361, 42.89119, 4.668757, 0, 0, -0.7223635, 0.6915136, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+410, 173051, 1, 1637, 1637, 1956.136, -4470.624, 25.73936, 4.668757, 0, 0, -0.7223635, 0.6915136, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+411, 173052, 1, 1637, 1637, 1956.547, -4468.755, 35.71779, 4.310966, 0, 0, -0.8338852, 0.5519379, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+412, 173042, 1, 1637, 1637, 1896.276, -4618.787, 33.94437, 2.95833, 0, 0, 0.9958048, 0.09150324, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+413, 177008, 1, 1637, 1637, 1937.95, -4625.81, 31.84994, 2.028637, 0.05512571, -0.1108961, 0.8389149, 0.5299859, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+122, 171539, 0, 1537, 1537, -4989.994, -1080.22, 497.9867, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+123, 171540, 0, 1537, 1537, -5025.334, -1083.123, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+124, 171652, 0, 1537, 1537, -5037.573, -1104.634, 501.9834, 5.715953, 0, 0, -0.279829, 0.9600499, 0, 0, 0, '', 648, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+125, 171653, 0, 1537, 1537, -5037.435, -1107.789, 501.9834, 0.56723, 0, 0, 0.2798281, 0.9600501, 0, 0, 0, '', 648, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+126, 171654, 0, 1537, 1537, -5037.39, -1108.507, 508.6668, 4.433136, 0, 0, -0.7986355, 0.601815, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+127, 171655, 0, 1537, 1537, -5039.197, -1112.081, 508.6668, 1.727875, 0, 0, 0.7604055, 0.6494485, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+128, 171656, 0, 1537, 1537, -5037.011, -1112.124, 508.6668, 2.687807, 0, 0, 0.97437, 0.2249513, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+129, 171657, 0, 1537, 1537, -5039.717, -1108.764, 508.6668, 5.393069, 0, 0, -0.4305105, 0.9025856, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+130, 180728, 0, 1537, 1537, -5117.396, -791.4796, 483.5854, 6.0912, 0, 0, -0.09584522, 0.9953963, 0, 0, 0, '', 6519, 0, 0, 32, 0, 65535, 1, 1, 0, 0, @SNIFFID+1, 35186),
(@OGUID+131, 171538, 0, 1537, 1537, -4989.85, -1056.276, 497.9867, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+414, 172992, 1, 1637, 1637, 1917.91, -4659.264, 33.49194, 1.780234, 0, 0, 0.7771454, 0.6293211, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+132, 171537, 0, 1537, 1537, -5011.367, -1054.441, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+415, 173079, 1, 1637, 1637, 1884.89, -4686.292, 36.57319, 0.6632232, 0, 0, 0.3255672, 0.9455189, 0, 0, 0, '', 707, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+416, 177009, 1, 1637, 1637, 1921.678, -4693.21, 32.80072, 2.739178, 0, 0, 0.979826, 0.1998526, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+417, 173076, 1, 1637, 1637, 1893.41, -4697.277, 37.31757, 3.246347, 0, 0, -0.9986286, 0.05235322, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+418, 173087, 1, 1637, 1637, 1871.923, -4699.319, 39.35188, 2.897245, 0, 0, 0.9925461, 0.12187, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+419, 173075, 1, 1637, 1637, 1941.156, -4695.532, 29.60627, 2.225294, 0, 0, 0.8968725, 0.4422892, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+420, 180394, 1, 1637, 1637, 1933.509, -4709.623, 36.74443, 1.623156, 0, 0, 0.7253742, 0.6883547, 0, 0, 0, '', 6707, 0, 1375, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+422, 173086, 1, 1637, 1637, 1999.505, -4644.982, 25.68828, 2.95833, 0, 0, 0.9958048, 0.09150324, 0, 0, 0, '', 709, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+421, 173088, 1, 1637, 1637, 1882.761, -4718.204, 39.35188, 3.490667, 0, 0, -0.984807, 0.1736523, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+423, 35591, 1, 1637, 1637, 1996.312, -4671.999, 24.55579, 5.740175, 0, 0, -0.2681818, 0.9633683, 1, @PGUID+244, 0, 'Player', 668, 31, 5, 0, 0, 65535, 1, 17, 0, 0, @SNIFFID+2, 35186),
(@OGUID+425, 173084, 1, 1637, 1637, 1951.537, -4737.426, 48.95394, 1.946038, 0, 0, 0.8265886, 0.5628065, 0, 0, 0, '', 707, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+424, 173069, 1, 1637, 1637, 1965.149, -4733.147, 49.47668, 3.246347, 0, 0, -0.9986286, 0.05235322, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+426, 177012, 1, 1637, 1637, 1997.294, -4717.167, 26.55919, 2.735575, 0.0412178, 0.04541779, 0.977952, 0.19962, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+428, 173100, 1, 1637, 1637, 2022.511, -4635.413, 29.68032, 5.393069, 0, 0, -0.4305105, 0.9025856, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+427, 173068, 1, 1637, 1637, 2023.873, -4656.075, 27.17668, 1.422443, 0, 0, 0.6527596, 0.7575652, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+429, 173080, 1, 1637, 1637, 1918.077, -4754.226, 33.5792, 5.742133, 0, 0, -0.2672386, 0.9636304, 0, 0, 0, '', 715, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+432, 173081, 1, 1637, 1637, 2012.514, -4709.557, 25.59093, 2.993224, 0, 0, 0.9972496, 0.07411628, 0, 0, 0, '', 716, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+430, 175885, 1, 1637, 1637, 1964.042, -4749.244, 51.43352, 4.293513, 0, 0, -0.8386698, 0.5446402, 0, 0, 0, '', 3972, 0, 114, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+431, 173063, 1, 1637, 1637, 2021.615, -4688.129, 25.17789, 2.426008, 0, 0, 0.9366722, 0.3502074, 0, 0, 0, '', 305, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+433, 173077, 1, 1637, 1637, 1917.281, -4759.561, 34.21886, 3.961899, 0, 0, -0.9170599, 0.3987495, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+434, 173099, 1, 1637, 1637, 2035.21, -4638.207, 29.68032, 5.393069, 0, 0, -0.4305105, 0.9025856, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+437, 173082, 1, 1637, 1637, 2038.606, -4729.112, 25.47586, 2.818698, 0, 0, 0.9869957, 0.1607467, 0, 0, 0, '', 716, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+440, 173090, 1, 1637, 1637, 1904.412, -4773.034, 36.37546, 3.237604, 0, 0, -0.998848, 0.04798714, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+435, 173091, 1, 1637, 1637, 2034.783, -4710.6, 26.87153, 3.996807, 0, 0, -0.9099607, 0.4146944, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+436, 173093, 1, 1637, 1637, 2030.847, -4740.397, 29.22457, 3.141593, 0, 0, -1, 0, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+438, 173122, 1, 1637, 1637, 1983.138, -4781.506, 56.842, 5.873035, 0, 0, -0.2036409, 0.9790456, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+439, 173123, 1, 1637, 1637, 1973.826, -4786.463, 56.842, 1.326451, 0, 0, 0.6156616, 0.7880107, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+441, 173070, 1, 1637, 1637, 2051.747, -4734.88, 26.38188, 3.490667, 0, 0, -0.984807, 0.1736523, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+443, 173092, 1, 1637, 1637, 2046.438, -4756.555, 29.22457, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+446, 173118, 1, 1637, 1637, 1993.183, -4802.809, 56.86984, 5.646142, 0, 0, -0.3131628, 0.9496995, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+445, 173120, 1, 1637, 1637, 1975.433, -4803.198, 56.86984, 3.394674, 0, 0, -0.9920044, 0.1262032, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+442, 173121, 1, 1637, 1637, 1996.228, -4794.005, 56.86984, 5.873035, 0, 0, -0.2036409, 0.9790456, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+444, 173071, 1, 1637, 1637, 2063.595, -4700.416, 37.90006, 3.892087, 0, 0, -0.9304171, 0.3665025, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+448, 173089, 1, 1637, 1637, 1911.253, -4791.894, 36.37546, 3.237604, 0, 0, -0.998848, 0.04798714, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+447, 173119, 1, 1637, 1637, 1984.043, -4806.707, 56.86984, 4.110254, 0, 0, -0.8849869, 0.465616, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+449, 173064, 1, 1637, 1637, 2048.722, -4812.207, 22.43139, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 209, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+451, 173065, 1, 1637, 1637, 2057.707, -4798.632, 22.50335, 0.8028488, 0, 0, 0.3907299, 0.9205054, 0, 0, 0, '', 273, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+450, 173066, 1, 1637, 1637, 2052.754, -4806.182, 22.45379, 4.852017, 0, 0, -0.6560583, 0.7547102, 0, 0, 0, '', 273, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+452, 173073, 1, 1637, 1637, 2065.842, -4804.086, 21.70269, 3.490667, 0, 0, -0.984807, 0.1736523, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+453, 173083, 1, 1637, 1637, 2069.839, -4823.959, 23.34344, 1.274091, 0, 0, 0.5948229, 0.8038568, 0, 0, 0, '', 716, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+454, 173094, 1, 1637, 1637, 2056.672, -4836.098, 24.52204, 4.852017, 0, 0, -0.6560583, 0.7547102, 0, 0, 0, '', 273, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+455, 173095, 1, 1637, 1637, 2051.629, -4838.974, 24.35325, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 209, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+457, 177011, 1, 1637, 1637, 2085.805, -4769.674, 23.26888, 2.739178, 0, 0, 0.979826, 0.1998526, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+456, 173096, 1, 1637, 1637, 2056.661, -4846.357, 24.46334, 0.5759593, 0, 0, 0.2840157, 0.9588196, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+458, 35591, 1, 1637, 1637, 1995.733, -4675.599, 24.55579, 6.063903, 0, 0, -0.1094217, 0.9939954, 1, @PGUID+244, 0, 'Player', 668, 31, 5, 0, 0, 65535, 1, 17, 0, 0, @SNIFFID+2, 35186),
(@OGUID+459, 177010, 1, 1637, 1637, 2040.504, -4633.043, 50.82231, 2.739178, 0, 0, 0.979826, 0.1998526, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+460, 173072, 1, 1637, 1637, 2092.567, -4721.557, 40.98861, 3.586657, 0, 0, -0.9753418, 0.2206997, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+462, 173074, 1, 1637, 1637, 2102.427, -4706.352, 40.84852, 3.586657, 0, 0, -0.9753418, 0.2206997, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+463, 173085, 1, 1637, 1637, 2096.935, -4652.213, 49.40491, 4.886924, 0, 0, -0.642787, 0.766045, 0, 0, 0, '', 707, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+461, 173067, 1, 1637, 1637, 2103.47, -4676.45, 44.41881, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+464, 177006, 1, 1637, 1637, 2125.082, -4706.554, 40.7274, 0.8639368, 0, 0, 0.4186592, 0.9081434, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+465, 177007, 1, 1637, 1637, 2101.659, -4741.792, 37.88578, 2.556905, 0, 0, 0.957571, 0.2881973, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+467, 177013, 1, 1637, 1637, 2095.351, -4634.096, 58.21088, 1.063663, 0, 0, 0.5071125, 0.8618799, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+466, 175885, 1, 1637, 1637, 2120.036, -4726.406, 38.70186, 5.462882, 0, 0, -0.3987484, 0.9170604, 0, 0, 0, '', 3972, 0, 114, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+468, 35591, 1, 1637, 1637, 1997.852, -4676.859, 24.55579, 5.788068, 0, 0, -0.245038, 0.9695135, 1, @PGUID+244, 0, 'Player', 668, 31, 5, 0, 0, 65535, 1, 17, 0, 0, @SNIFFID+2, 35186),
(@OGUID+470, 173178, 1, 1637, 1637, 2139.869, -4731.297, 50.52977, 0.9948372, 0, 0, 0.4771585, 0.8788173, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+469, 173179, 1, 1637, 1637, 2131.417, -4744.472, 50.52977, 2.853604, 0, 0, 0.9896507, 0.1434972, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+471, 173184, 1, 1637, 1637, 2153.22, -4740.768, 67.56803, 6.230826, 0, 0, -0.02617645, 0.9996573, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+472, 173194, 1, 1637, 1637, 2145.528, -4753.152, 67.56804, 0.3665195, 0, 0, 0.1822357, 0.9832548, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+473, 173050, 1, 1637, 1637, 1968.63, -4463.087, 25.73936, 4.668757, 0, 0, -0.7223635, 0.6915136, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+474, 172944, 1, 1637, 1637, 1952.677, -4429.125, 24.73368, 5.506516, 0, 0, -0.3786478, 0.9255409, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+475, 172951, 1, 1637, 1637, 1915.354, -4417.574, 21.8341, 1.047198, 0, 0, 0.5, 0.8660254, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+476, 173022, 1, 1637, 1637, 1927.565, -4421.845, 22.55021, 0.05235888, 0, 0, 0.02617645, 0.9996573, 0, 0, 0, '', 714, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+477, 172956, 1, 1637, 1637, 1900.654, -4386.073, 48.08143, 5.698502, 0, 0, -0.2881956, 0.9575716, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+478, 172950, 1, 1637, 1637, 1954.329, -4372.813, 22.29937, 1.047198, 0, 0, 0.5, 0.8660254, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+479, 177003, 1, 1637, 1637, 1956.268, -4338.903, 21.98154, 5.227262, 0, 0, -0.5037737, 0.8638357, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+483, 175658, 1, 1637, 1637, 1949.116, -4314.662, 23.34918, 4.166199, -0.517355, -0.2090988, -0.7454653, 0.3645587, 0, 0, 0, '', 214, 0, 0, 0, 0, 65535, 1, 9, 0, 0, @SNIFFID+2, 35186),
(@OGUID+480, 175312, 1, 1637, 1637, 1850.489, -4359.16, -15.04101, 3.377225, 0, 0, -0.9930677, 0.1175435, 0, 0, 0, '', 475, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+481, 173056, 1, 1637, 1637, 1910.851, -4321.728, 21.54961, 6.161015, 0, 0, -0.06104755, 0.9981349, 0, 0, 0, '', 710, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+482, 173060, 1, 1637, 1637, 1886.553, -4328.415, 23.20864, 3.202737, 0, 0, -0.9995327, 0.03056734, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+484, 173059, 1, 1637, 1637, 1884.1, -4312.753, 23.20864, 3.202737, 0, 0, -0.9995327, 0.03056734, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+485, 173061, 1, 1637, 1637, 1875.4, -4320.835, 32.23316, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+487, 172978, 1, 1637, 1637, 1918.003, -4294.388, 31.21418, 1.396262, 0, 0, 0.642787, 0.766045, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+488, 172979, 1, 1637, 1637, 1918.12, -4295.111, 31.07154, 5.270894, 0, 0, -0.4848099, 0.8746195, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+489, 172980, 1, 1637, 1637, 1917.549, -4294.398, 30.74392, 2.356195, 0, 0, 0.9238796, 0.3826832, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+490, 172981, 1, 1637, 1637, 1918.19, -4295.178, 29.98513, 5.148723, 0, 0, -0.5372992, 0.8433917, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+493, 177004, 1, 1637, 1637, 1898.569, -4268.708, 31.32606, 5.227262, 0, 0, -0.5037737, 0.8638357, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+486, 175319, 1, 1637, 1637, 1836.03, -4364.471, -15.04512, 2.95833, 0, 0, 0.9958048, 0.09150324, 0, 0, 0, '', 714, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+491, 173057, 1, 1637, 1637, 1938.208, -4277.064, 30.10187, 1.169369, 0, 0, 0.5519361, 0.8338864, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+492, 173058, 1, 1637, 1637, 1920.609, -4279.686, 30.53626, 0.8464848, 0, 0, 0.4107189, 0.911762, 0, 0, 0, '', 374, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+496, 175885, 1, 1637, 1637, 1928.945, -4255.156, 31.80532, 5.375615, 0, 0, -0.4383707, 0.8987942, 0, 0, 0, '', 3972, 0, 114, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+495, 175316, 1, 1637, 1637, 1832.386, -4344.816, -15.32445, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+494, 173173, 1, 1637, 1637, 1831.88, -4339.107, -15.61301, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 714, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+497, 177005, 1, 1637, 1637, 1959.732, -4249.642, 31.32606, 0.8639368, 0, 0, 0.4186592, 0.9081434, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+499, 173140, 1, 1637, 1637, 1913.955, -4228.371, 42.1457, 2.391098, 0, 0, 0.9304171, 0.3665025, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+498, 173172, 1, 1637, 1637, 1827.713, -4324.881, -15.59231, 4.32842, 0, 0, -0.8290367, 0.5591941, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+500, 173141, 1, 1637, 1637, 1940.419, -4226.307, 42.1457, 2.225294, 0, 0, 0.8968725, 0.4422892, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+133, 143318, 0, 1537, 1537, -4982.64, -1041.335, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+501, 173137, 1, 1637, 1637, 1934.178, -4217.937, 42.1933, 1.64061, 0, 0, 0.7313538, 0.6819983, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+502, 173138, 1, 1637, 1637, 1918.398, -4219.04, 42.1933, 1.64061, 0, 0, 0.7313538, 0.6819983, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+503, 173139, 1, 1637, 1637, 1912.467, -4210.892, 42.1457, 1.24791, 0, 0, 0.5842495, 0.8115741, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+504, 173142, 1, 1637, 1637, 1938.888, -4208.65, 42.1457, 1.24791, 0, 0, 0.5842495, 0.8115741, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+134, 143319, 0, 1537, 1537, -5019.07, -1018.722, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+135, 143320, 0, 1537, 1537, -4972.383, -1013.902, 501.6727, 2.521998, 0, 0, 0.9523954, 0.3048655, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+137, 149413, 0, 1537, 1537, -4950.794, -1025.793, 501.4373, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+136, 143322, 0, 1537, 1537, -5004.718, -1012.767, 510.4621, 5.890487, 0, 0, -0.1950903, 0.9807853, 0, 0, 0, '', 641, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+142, 139852, 0, 1537, 1537, -5027.844, -1020.48, 502.2091, 1.274088, 0, 0, 0.5948219, 0.8038574, 0, 0, 0, '', 340, 0, 114, 0, 0, 65535, 1, 10, 0, 0, @SNIFFID+1, 35186),
(@OGUID+138, 171580, 0, 1537, 1537, -4962.613, -1022.168, 503.8728, 1.239183, 0, 0, 0.5807028, 0.8141156, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+139, 171581, 0, 1537, 1537, -4960.315, -1021.423, 503.8728, 3.944446, 0, 0, -0.9205046, 0.3907318, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+140, 171582, 0, 1537, 1537, -4960.935, -1023.36, 503.8728, 2.199111, 0, 0, 0.8910055, 0.4539925, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+141, 171583, 0, 1537, 1537, -4962.636, -1020.538, 503.8728, 4.904376, 0, 0, -0.6360779, 0.7716249, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+506, 173143, 1, 1637, 1637, 1928.462, -4198.14, 41.98694, 3.298687, 0, 0, -0.9969168, 0.07846643, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+507, 173144, 1, 1637, 1637, 1921.366, -4198.651, 41.98694, 3.298687, 0, 0, -0.9969168, 0.07846643, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+505, 173177, 1, 1637, 1637, 1818.265, -4316.225, -11.82707, 3.822273, 0, 0, -0.9426413, 0.3338076, 0, 0, 0, '', 707, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+150, 171612, 0, 1537, 1537, -5023.069, -1001.749, 503.8891, 0.5759593, 0, 0, 0.2840157, 0.9588196, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+151, 171613, 0, 1537, 1537, -5020.951, -1003.372, 503.8891, 1.274088, 0, 0, 0.5948219, 0.8038574, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+145, 171584, 0, 1537, 1537, -4955.284, -1013.965, 503.8745, 3.743731, 0, 0, -0.95502, 0.2965415, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+152, 171614, 0, 1537, 1537, -5023.252, -999.5991, 503.8891, 5.637414, 0, 0, -0.3173046, 0.9483237, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+146, 171585, 0, 1537, 1537, -4957.444, -1012.397, 503.8745, 4.441865, 0, 0, -0.7960014, 0.6052947, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+153, 171615, 0, 1537, 1537, -5017.313, -1000.575, 503.8889, 3.185267, 0, 0, -0.9997616, 0.02183524, 0, 0, 0, '', 648, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+147, 171586, 0, 1537, 1537, -4955.045, -1016.109, 503.8745, 2.521998, 0, 0, 0.9523954, 0.3048655, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+148, 171587, 0, 1537, 1537, -4961.008, -1015.289, 503.8742, 0.06981169, 0, 0, 0.03489876, 0.9993908, 0, 0, 0, '', 648, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+149, 171588, 0, 1537, 1537, -4959.624, -1012.451, 503.8742, 5.218534, 0, 0, -0.5075388, 0.8616289, 0, 0, 0, '', 648, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+143, 143321, 0, 1537, 1537, -4973.721, -1003.039, 510.5419, 2.617989, 0, 0, 0.9659252, 0.2588213, 0, 0, 0, '', 637, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+154, 171616, 0, 1537, 1537, -5018.771, -1003.376, 503.8889, 2.050762, 0, 0, 0.8549118, 0.5187734, 0, 0, 0, '', 648, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+155, 171617, 0, 1537, 1537, -5011.574, -1006.968, 503.8889, 2.705255, 0, 0, 0.9762955, 0.2164421, 0, 0, 0, '', 648, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+156, 171618, 0, 1537, 1537, -5010.819, -1005.295, 503.8889, 2.661627, 0, 0, 0.9713421, 0.2376858, 0, 0, 0, '', 648, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+144, 143326, 0, 1537, 1537, -4941.677, -1016.171, 501.4373, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+157, 171608, 0, 1537, 1537, -5015.067, -991.2496, 503.8875, 4.354598, 0, 0, -0.8216467, 0.5699971, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+158, 171609, 0, 1537, 1537, -5018.601, -993.2252, 503.8875, 0.7766697, 0, 0, 0.3786478, 0.9255409, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+159, 171610, 0, 1537, 1537, -5017.163, -990.1196, 503.8875, 5.31453, 0, 0, -0.4656134, 0.8849882, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+160, 171611, 0, 1537, 1537, -5015.821, -994.3999, 503.8875, 1.736602, 0, 0, 0.7632322, 0.6461242, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+508, 173165, 1, 1637, 1637, 1804.118, -4294.391, 5.752108, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+509, 173169, 1, 1637, 1637, 1807.502, -4290.297, 5.731733, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 713, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+166, 171524, 0, 1537, 1537, -4982.605, -974.0767, 503.9743, 5.681047, 0, 0, -0.2965412, 0.9550201, 0, 0, 0, '', 660, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+167, 143324, 0, 1537, 1537, -4926.932, -987.7189, 506.6474, 2.46964, 0, 0, 0.9440889, 0.3296909, 0, 0, 0, '', 638, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+164, 143325, 0, 1537, 1537, -4934.4, -994.1378, 501.4373, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+163, 137646, 0, 1537, 1537, -4982.572, -974.0101, 504.8531, 5.681047, 0, 0, -0.2965412, 0.9550201, 0, 0, 0, '', 660, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+161, 32427, 0, 1537, 1537, -4981.569, -972.5402, 504.0295, 2.539448, 0, 0, 0.955019, 0.2965446, 0, 0, 0, '', 660, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+162, 32431, 0, 1537, 1537, -4982.634, -974.1005, 503.1841, 5.681047, 0, 0, -0.2965412, 0.9550201, 0, 0, 0, '', 660, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+165, 144159, 0, 1537, 1537, -4996.757, -971.41, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+511, 173145, 1, 1637, 1637, 1920.594, -4184.828, 41.98694, 3.298687, 0, 0, -0.9969168, 0.07846643, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+510, 173175, 1, 1637, 1637, 1804.83, -4309.076, -11.73208, 4.32842, 0, 0, -0.8290367, 0.5591941, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+513, 173136, 1, 1637, 1637, 1920.189, -4180.519, 40.97331, 3.324856, 0, 0, -0.9958048, 0.09150324, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+514, 173146, 1, 1637, 1637, 1927.667, -4184.296, 41.98694, 3.298687, 0, 0, -0.9969168, 0.07846643, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+512, 173167, 1, 1637, 1637, 1794.18, -4301.78, 4.382412, 4.485497, 0, 0, -0.782608, 0.6225148, 0, 0, 0, '', 474, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+168, 143323, 0, 1537, 1537, -4980.895, -948.2181, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+171, 171698, 0, 1537, 1537, -4912.94, -979.0797, 501.4373, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+172, 171699, 0, 1537, 1537, -4910.382, -976.2117, 501.4079, 2.268925, 0, 0, 0.9063072, 0.4226195, 0, 0, 0, '', 1947, 0, 55, 0, 0, 65535, 1, 19, 0, 0, @SNIFFID+1, 35186),
(@OGUID+169, 171633, 0, 1537, 1537, -4896.835, -1012.273, 504.02, 5.401796, 0, 0, -0.426568, 0.9044555, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+170, 171634, 0, 1537, 1537, -4904.645, -1000.827, 504.02, 5.401796, 0, 0, -0.426568, 0.9044555, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+173, 176573, 0, 1537, 1537, -4905.577, -983.3544, 517.252, 1.553341, 0, 0, 0.7009087, 0.7132511, 0, 0, 0, '', 3972, 0, 114, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+516, 173132, 1, 1637, 1637, 1927.4, -4180.393, 40.97331, 1.021017, 0, 0, 0.4886208, 0.8724963, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+515, 173131, 1, 1637, 1637, 1905.06, -4174.181, 43.48589, 0.2356177, 0, 0, 0.1175365, 0.9930685, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+174, 171697, 0, 1537, 1537, -4899.763, -968.2446, 501.4373, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+176, 176628, 0, 1537, 1537, -4972.13, -916.2393, 504.3045, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 2699, @SNIFFID+1, 35186),
(@OGUID+177, 176629, 0, 1537, 1537, -4967.092, -922.35, 504.3045, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 3020, @SNIFFID+1, 35186),
(@OGUID+175, 26499, 0, 1537, 1537, -4953.628, -928.3318, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+517, 173130, 1, 1637, 1637, 1897.493, -4167.989, 43.48589, 2.556905, 0, 0, 0.957571, 0.2881973, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+178, 171696, 0, 1537, 1537, -4941.365, -918.296, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+183, 171702, 0, 1537, 1537, -4881.911, -955.4149, 501.4373, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+182, 171704, 0, 1537, 1537, -4887.03, -954.8184, 510.13, 1.841321, 0, 0, 0.7960014, 0.6052947, 0, 0, 0, '', 635, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+184, 176624, 0, 1537, 1537, -4960.698, -900.8433, 504.3045, 3.831001, 0, 0, -0.9411755, 0.3379182, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 2906, @SNIFFID+1, 35186),
(@OGUID+179, 171635, 0, 1537, 1537, -4879.56, -980.1483, 504.02, 5.401796, 0, 0, -0.426568, 0.9044555, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+181, 176627, 0, 1537, 1537, -4967.478, -906.2366, 504.3045, 3.831001, 0, 0, -0.9411755, 0.3379182, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 2730, @SNIFFID+1, 35186),
(@OGUID+180, 176924, 0, 1537, 1537, -4962.003, -907.0949, 503.8264, 4.197518, 0, 0, -0.8638353, 0.5037743, 0, 0, 0, '', 32, 0, 55, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+185, 176626, 0, 1537, 1537, -4943.865, -903.203, 504.3045, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 2839, @SNIFFID+1, 35186),
(@OGUID+186, 171636, 0, 1537, 1537, -4870.012, -990.1613, 504.02, 5.401796, 0, 0, -0.426568, 0.9044555, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+187, 176625, 0, 1537, 1537, -4948.903, -897.0923, 504.3045, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 3130, @SNIFFID+1, 35186),
(@OGUID+189, 180397, 0, 1537, 1537, -5036.141, -921.8038, 501.6593, 6.161013, 0, 0, -0.06104851, 0.9981348, 0, 0, 0, '', 6135, 0, 1375, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+188, 180400, 0, 1537, 1537, -5035.72, -922.0739, 502.826, 2.984498, 0, 0, 0.9969168, 0.07846643, 0, 0, 0, '', 6390, 0, 1375, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+522, 172977, 1, 1637, 1637, 1767.18, -4222.865, 42.99647, 5.838127, 0, 0, -0.2206974, 0.9753423, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+518, 173163, 1, 1637, 1637, 1776.039, -4277.562, 7.774323, 2.696529, 0, 0, 0.9753418, 0.2206997, 0, 0, 0, '', 475, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+519, 173170, 1, 1637, 1637, 1770.238, -4294.298, 6.668362, 4.991641, 0, 0, -0.6018152, 0.7986354, 0, 0, 0, '', 707, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+523, 172993, 1, 1637, 1637, 1766.424, -4222.405, 44.32041, 2.609261, 0, 0, 0.9647865, 0.2630341, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+524, 172994, 1, 1637, 1637, 1766.424, -4222.405, 43.35183, 2.609261, 0, 0, 0.9647865, 0.2630341, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+525, 172995, 1, 1637, 1637, 1766.28, -4222.359, 42.28103, 2.609261, 0, 0, 0.9647865, 0.2630341, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+527, 173062, 1, 1637, 1637, 1788.692, -4201.4, 40.08276, 5.654867, 0, 0, -0.3090172, 0.9510564, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+526, 173025, 1, 1637, 1637, 1773.824, -4215.275, 39.22102, 2.617989, 0, 0, 0.9659252, 0.2588213, 0, 0, 0, '', 709, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+520, 172975, 1, 1637, 1637, 1766.85, -4223.18, 43.52999, 4.76475, 0, 0, -0.6883545, 0.7253745, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+521, 172976, 1, 1637, 1637, 1767.18, -4222.865, 44.46281, 5.838127, 0, 0, -0.2206974, 0.9753423, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+191, 171758, 0, 1537, 1537, -4856.985, -997.963, 453.7034, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+194, 171701, 0, 1537, 1537, -4916.485, -895.2466, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+190, 171703, 0, 1537, 1537, -4857.615, -947.2179, 501.4373, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+192, 171764, 0, 1537, 1537, -4883.278, -1055.698, 502.1515, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+193, 32385, 0, 1537, 1537, -4892.574, -899.2479, 504.0117, 5.061456, 0, 0, -0.573576, 0.8191524, 0, 0, 0, '', 660, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+200, 171695, 0, 1537, 1537, -4858.639, -916.3169, 501.6727, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+196, 171757, 0, 1537, 1537, -4849.574, -1006.953, 453.7034, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+201, 171700, 0, 1537, 1537, -4891.326, -883.553, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+195, 149418, 0, 1537, 1537, -4848.266, -937.4863, 501.4373, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+198, 137644, 0, 1537, 1537, -4890.83, -898.5957, 503.95, 1.919862, 0, 0, 0.8191519, 0.5735767, 0, 0, 0, '', 660, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+197, 32424, 0, 1537, 1537, -4890.834, -898.6082, 503.1682, 1.919862, 0, 0, 0.8191519, 0.5735767, 0, 0, 0, '', 660, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+199, 142838, 0, 1537, 1537, -4890.854, -898.6151, 504.8559, 1.919862, 0, 0, 0.8191519, 0.5735767, 0, 0, 0, '', 660, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+202, 143253, 0, 1537, 1537, -4871.016, -885.1487, 505.4214, 4.89565, 0, 0, -0.6394386, 0.7688421, 0, 0, 0, '', 640, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+205, 143317, 0, 1537, 1537, -4845.298, -882.3042, 504.6846, 4.799655, 0, 0, -0.6755905, 0.737277, 0, 0, 0, '', 639, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+208, 171693, 0, 1537, 1537, -4857.201, -879.5898, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+209, 171694, 0, 1537, 1537, -4830.092, -909.8125, 501.6727, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186);

INSERT INTO `gameobject` (`guid`, `id`, `map`, `zone_id`, `area_id`, `position_x`, `position_y`, `position_z`, `orientation`, `rotation0`, `rotation1`, `rotation2`, `rotation3`, `is_temporary`, `creator_guid`, `creator_id`, `creator_type`, `display_id`, `level`, `faction`, `flags`, `dynamic_flags`, `path_progress`, `state`, `type`, `artkit`, `custom_param`, `sniff_id`, `sniff_build`) VALUES
(@OGUID+211, 180397, 0, 1537, 1537, -4919.308, -844.6155, 501.6613, 5.427975, 0, 0, -0.4146929, 0.9099615, 0, 0, 0, '', 6135, 0, 1375, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+210, 180400, 0, 1537, 1537, -4919.785, -844.9517, 503.1265, 0.6632232, 0, 0, 0.3255672, 0.9455189, 0, 0, 0, '', 6390, 0, 1375, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+1, 35186),
(@OGUID+203, 171761, 0, 1537, 1537, -4831.216, -973.3327, 464.6361, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+206, 171648, 0, 1537, 1537, -4827.556, -919.3938, 502.22, 3.804818, 0, 0, -0.9455185, 0.3255684, 0, 0, 0, '', 648, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+207, 171649, 0, 1537, 1537, -4827.116, -922.5208, 502.22, 2.670348, 0, 0, 0.9723692, 0.2334484, 0, 0, 0, '', 648, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+204, 32349, 0, 1537, 1537, -4845.779, -879.3005, 501.6142, 1.649333, 0, 0, 0.7343216, 0.6788017, 0, 0, 0, '', 1947, 0, 55, 0, 0, 65535, 1, 19, 0, 0, @SNIFFID+1, 35186),
(@OGUID+529, 177002, 1, 1637, 1637, 1757.128, -4208.727, 41.20558, 0.5664197, -0.01641941, 0.03610897, 0.2794333, 0.9593454, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+528, 173101, 1, 1637, 1637, 1750.063, -4258.668, 27.35478, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+212, 171762, 0, 1537, 1537, -4820.146, -964.2072, 464.6361, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+213, 171569, 0, 1537, 1537, -4838.778, -867.5601, 501.923, 0.1047193, 0, 0, 0.05233574, 0.9986296, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+214, 171570, 0, 1537, 1537, -4839.019, -865.4498, 501.923, 0.1047193, 0, 0, 0.05233574, 0.9986296, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+215, 171573, 0, 1537, 1537, -4845.326, -864.4749, 501.923, 3.246311, 0, 0, -0.9986296, 0.05233501, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+216, 171574, 0, 1537, 1537, -4847.422, -863.0463, 501.923, 4.81711, 0, 0, -0.6691303, 0.743145, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+217, 171575, 0, 1537, 1537, -4849.171, -864.9475, 501.923, 0.1047193, 0, 0, 0.05233574, 0.9986296, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+218, 171576, 0, 1537, 1537, -4847.09, -866.2927, 501.923, 1.675514, 0, 0, 0.743144, 0.6691315, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+219, 171577, 0, 1537, 1537, -4848.015, -865.8651, 510.2544, 3.246311, 0, 0, -0.9986296, 0.05233501, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+220, 171578, 0, 1537, 1537, -4849.861, -864.6241, 510.2544, 4.81711, 0, 0, -0.6691303, 0.743145, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+221, 171579, 0, 1537, 1537, -4851.672, -866.4078, 510.2544, 0.1047193, 0, 0, 0.05233574, 0.9986296, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+530, 173007, 1, 1637, 1637, 1722.652, -4204.29, 51.74149, 4.81711, 0, 0, -0.6691303, 0.743145, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+226, 171692, 0, 1537, 1537, -4826.514, -876.0884, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+222, 171544, 0, 1537, 1537, -4808.225, -870.3134, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+223, 171545, 0, 1537, 1537, -4808.471, -911.8838, 497.9014, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+224, 171571, 0, 1537, 1537, -4835.329, -867.2902, 501.923, 3.246311, 0, 0, -0.9986296, 0.05233501, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+225, 171572, 0, 1537, 1537, -4835.57, -865.1799, 501.923, 3.246311, 0, 0, -0.9986296, 0.05233501, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+227, 171546, 0, 1537, 1537, -4781.679, -874.9891, 501.6727, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+228, 171547, 0, 1537, 1537, -4784.52, -913.5954, 497.9014, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+531, 173117, 1, 1637, 1637, 1703.039, -4266.291, 33.12738, 3.735006, 0, 0, -0.9563046, 0.2923723, 0, 0, 0, '', 375, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+229, 171543, 0, 1537, 1537, -4764.526, -880.6956, 501.6141, 2.260197, 0, 0, 0.9044542, 0.4265707, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+230, 171660, 0, 1537, 1537, -4775.48, -927.5671, 503.699, 0.6457697, 0, 0, 0.3173037, 0.948324, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+231, 171661, 0, 1537, 1537, -4774.289, -924.5708, 503.699, 4.398232, 0, 0, -0.8090162, 0.5877863, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, @SNIFFID+1, 35186),
(@OGUID+537, 179740, 1, 1637, 1637, 1675.102, -4248.631, 53.83351, 3.543024, 0, 0, -0.9799242, 0.1993704, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+532, 172969, 1, 1637, 1637, 1675.102, -4248.631, 54.84536, 3.543024, 0, 0, -0.9799242, 0.1993704, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+533, 172972, 1, 1637, 1637, 1675.074, -4248.649, 52.84606, 3.543024, 0, 0, -0.9799242, 0.1993704, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+534, 172973, 1, 1637, 1637, 1675.933, -4248.123, 53.71037, 0.6632232, 0, 0, 0.3255672, 0.9455189, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+535, 172974, 1, 1637, 1637, 1675.946, -4248.223, 54.64318, 0.5759573, 0, 0, 0.2840147, 0.9588199, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+536, 176518, 1, 1637, 1637, 1666.916, -4213.373, 56.26083, 5.593781, 0, 0, -0.3379164, 0.9411761, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+538, 176517, 1, 1637, 1637, 1664.694, -4204.345, 56.26083, 0.02617911, 0, 0, 0.01308918, 0.9999143, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+540, 176521, 1, 1637, 1637, 1654.322, -4224.509, 56.23299, 3.525572, 0, 0, -0.9816265, 0.1908124, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+539, 176516, 1, 1637, 1637, 1656.168, -4199.242, 56.26083, 1.56207, 0, 0, 0.7040148, 0.7101853, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+541, 176519, 1, 1637, 1637, 1647.256, -4201.953, 56.26083, 1.788962, 0, 0, 0.7798843, 0.6259237, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+542, 176520, 1, 1637, 1637, 1644.838, -4219.889, 56.23299, 1.788962, 0, 0, 0.7798843, 0.6259237, 0, 0, 0, '', 408, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+543, 179741, 1, 1637, 1637, 1638.444, -4250.691, 56.54162, 4.206383, 0.01306486, 0.0007982254, -0.8615551, 0.5074953, 0, 0, 0, '', 214, 0, 0, 0, 0, 65535, 1, 9, 0, 0, @SNIFFID+2, 35186),
(@OGUID+544, 179742, 1, 1637, 1637, 1636.248, -4262.483, 49.54205, 4.171341, 0, 0, -0.8703547, 0.4924254, 0, 0, 0, '', 707, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+545, 177023, 1, 1637, 1637, 1624.878, -4275.133, 22.99336, 3.813545, 0, 0, -0.9440889, 0.3296909, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+550, 177016, 1, 1637, 1637, 1561.098, -4186.862, 41.65495, 0.8813918, 0, 0, 0.426569, 0.904455, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+548, 172996, 1, 1637, 1637, 1569.147, -4200.985, 46.15923, 5.297076, 0, 0, -0.4733191, 0.8808911, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+549, 172997, 1, 1637, 1637, 1569.147, -4200.985, 44.83858, 5.297076, 0, 0, -0.4733191, 0.8808911, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+546, 172970, 1, 1637, 1637, 1568.391, -4200.612, 46.24524, 3.167798, 0, 0, -0.9999142, 0.01310196, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+547, 172971, 1, 1637, 1637, 1569.015, -4200.205, 45.24609, 1.24791, 0, 0, 0.5842495, 0.8115741, 0, 0, 0, '', 309, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+551, 173160, 1, 1637, 1637, 1543.779, -4173.816, 40.16428, 0.087266, 0, 0, 0.04361916, 0.9990482, 0, 0, 0, '', 714, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+552, 173161, 1, 1637, 1637, 1524.846, -4219.193, 41.24287, 0.5846859, 0, 0, 0.2881966, 0.9575713, 0, 0, 0, '', 714, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+232, 26496, 0, 1537, 1537, -4883.129, -1063.894, 502.2235, 1.998401, 0, 0, 0.8410387, 0.540975, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+1, 35186),
(@OGUID+553, 173157, 1, 1637, 1637, 1594.851, -4106.7, 32.95555, 5.113814, 0, 0, -0.5519371, 0.8338857, 0, 0, 0, '', 707, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+554, 173159, 1, 1637, 1637, 1576.844, -4098.217, 36.1017, 5.358162, 0, 0, -0.4461975, 0.8949345, 0, 0, 0, '', 373, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+555, 177014, 1, 1637, 1637, 1606.917, -4095.966, 33.29412, 0.8813918, 0, 0, 0.426569, 0.904455, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186),
(@OGUID+556, 173162, 1, 1637, 1637, 1476.587, -4146.668, 40.38483, 6.003934, 0, 0, -0.1391726, 0.9902682, 0, 0, 0, '', 711, 0, 0, 0, 0, 65535, 1, 5, 0, 0, @SNIFFID+2, 35186),
(@OGUID+557, 177015, 1, 1637, 1637, 1691.876, -4103.519, 38.01554, 0.8813918, 0, 0, 0.426569, 0.904455, 0, 0, 0, '', 4572, 0, 0, 0, 0, 65535, 1, 8, 0, 0, @SNIFFID+2, 35186);

DELETE FROM `gameobject_addon` WHERE `guid` BETWEEN @OGUID+0 AND @OGUID+557;
INSERT INTO `gameobject_addon` (`guid`, `parent_rotation0`, `parent_rotation1`, `parent_rotation2`, `parent_rotation3`) VALUES
(@OGUID+6, 0, 0, 0.6122171, 0.7906898), -- 177270
(@OGUID+4, 0, 0, 0.6122171, 0.7906898), -- 3298
(@OGUID+16, 0, 0, 0.6122171, 0.7906898), -- 0
(@OGUID+17, 0, 0, 0.6122171, 0.7906898), -- 0
(@OGUID+10, 0, 0, 0.6122171, 0.7906898), -- 152583
(@OGUID+18, 0, 0, 0.6122171, 0.7906898), -- 0
(@OGUID+19, 0, 0, 0.6122171, 0.7906898), -- 0
(@OGUID+9, 0, 0, 0.6122171, 0.7906898), -- 177269
(@OGUID+11, 0, 0, 0.6122171, 0.7906898), -- 3296
(@OGUID+13, 0, 0, 0.6156614, 0.7880108), -- 3286
(@OGUID+30, 0, 0, 0.9044551, 0.4265688), -- 171553
(@OGUID+36, 0, 0, 0.9044551, 0.4265688), -- 171554
(@OGUID+35, 0, 0, 0.9044551, 0.4265688), -- 143251
(@OGUID+44, 0, 0, 0.9044551, 0.4265688), -- 143255
(@OGUID+71, 0, 0, 0.9044551, 0.4265688), -- 171525
(@OGUID+65, 0, 0, 0.9044551, 0.4265688), -- 171748
(@OGUID+70, 0, 0, 0.9044551, 0.4265688), -- 171527
(@OGUID+48, 0, 0, 0.9044551, 0.4265688), -- 149412
(@OGUID+59, 0, 0, 0.9044551, 0.4265688), -- 142911
(@OGUID+60, 0, 0, 0.9044551, 0.4265688), -- 142912
(@OGUID+53, 0, 0, 0.9044551, 0.4265688), -- 142914
(@OGUID+56, 0, 0, 0.9044551, 0.4265688), -- 142915
(@OGUID+50, 0, 0, 0.9044551, 0.4265688), -- 142916
(@OGUID+49, 0, 0, 0.9044551, 0.4265688), -- 171552
(@OGUID+47, 0, 0, 0.9044551, 0.4265688), -- 171555
(@OGUID+45, 0, 0, 0.9044551, 0.4265688), -- 171556
(@OGUID+52, 0, 0, 0.9044551, 0.4265688), -- 171664
(@OGUID+54, 0, 0, 0.9044551, 0.4265688), -- 171665
(@OGUID+57, 0, 0, 0.9044551, 0.4265688), -- 171666
(@OGUID+58, 0, 0, 0.9044551, 0.4265688), -- 171667
(@OGUID+55, 0, 0, 0.9044551, 0.4265688), -- 171668
(@OGUID+51, 0, 0, 0.9044551, 0.4265688), -- 171669
(@OGUID+64, 0, 0, 0.9044551, 0.4265688), -- 171670
(@OGUID+62, 0, 0, 0.9044551, 0.4265688), -- 171671
(@OGUID+63, 0, 0, 0.9044551, 0.4265688), -- 171672
(@OGUID+61, 0, 0, 0.9044551, 0.4265688), -- 171673
(@OGUID+46, 0, 0, 0.9044551, 0.4265688), -- 143250
(@OGUID+75, 0, 0, 0.9044551, 0.4265688), -- 171746
(@OGUID+78, 0, 0, 0.9044551, 0.4265688), -- 171747
(@OGUID+72, 0, 0, 0.9044551, 0.4265688), -- 171526
(@OGUID+74, 0, 0, 0.9044551, 0.4265688), -- 171749
(@OGUID+76, 0, 0, 0.9044551, 0.4265688), -- 171750
(@OGUID+73, 0, 0, 0.9044551, 0.4265688), -- 171753
(@OGUID+79, 0, 0, 0.9044551, 0.4265688), -- 171754
(@OGUID+84, 0, 0, 0.9044551, 0.4265688), -- 142851
(@OGUID+85, 0, 0, 0.9044551, 0.4265688), -- 171557
(@OGUID+81, 0, 0, 0.9044551, 0.4265688), -- 171736
(@OGUID+82, 0, 0, 0.9044551, 0.4265688), -- 171737
(@OGUID+80, 0, 0, 0.9044551, 0.4265688), -- 171738
(@OGUID+99, 0, 0, 0.9044551, 0.4265688), -- 171638
(@OGUID+100, 0, 0, 0.9044551, 0.4265688), -- 171639
(@OGUID+98, 0, 0, 0.9044551, 0.4265688), -- 171559
(@OGUID+245, 0, 0, 0.9563047, -0.2923717), -- 173013
(@OGUID+101, 0, 0, 0.9044551, 0.4265688), -- 171751
(@OGUID+102, 0, 0, 0.9044551, 0.4265688), -- 171752
(@OGUID+246, 0, 0, 0.9563047, -0.2923717), -- 173011
(@OGUID+247, 0, 0, 0.9563047, -0.2923717), -- 173009
(@OGUID+104, 0, 0, 0.9044551, 0.4265688), -- 171641
(@OGUID+249, 0, 0, 0.9563047, -0.2923717), -- 173008
(@OGUID+248, 0, 0, 0.9563047, -0.2923717), -- 173010
(@OGUID+250, 0, 0, 0.9563047, -0.2923717), -- 173012
(@OGUID+256, 0, 0, 0.9563047, -0.2923717), -- 177018
(@OGUID+267, 0, 0, 0.9563047, -0.2923717), -- 176562
(@OGUID+268, 0, 0, 0.9563047, -0.2923717), -- 172957
(@OGUID+269, 0, 0, 0.9563047, -0.2923717), -- 172958
(@OGUID+270, 0, 0, 0.9563047, -0.2923717), -- 172959
(@OGUID+271, 0, 0, 0.9563047, -0.2923717), -- 172960
(@OGUID+272, 0, 0, 0.9563047, -0.2923717), -- 172961
(@OGUID+23, 0, 0, 0.6156614, 0.7880108), -- 177265
(@OGUID+22, 0, 0, 0.6122171, 0.7906898), -- 3303
(@OGUID+21, 0, 0, 0.6156614, 0.7880108), -- 3315
(@OGUID+274, 0, 0, 0.9563047, -0.2923717), -- 177017
(@OGUID+275, 0, 0, 0.9563047, -0.2923717), -- 173112
(@OGUID+273, 0, 0, 0.9563047, -0.2923717), -- 173200
(@OGUID+276, 0, 0, 0.9563047, -0.2923717), -- 173203
(@OGUID+25, 0, 0, 0.6122171, 0.7906898), -- 177266
(@OGUID+277, 0, 0, 0.9563047, -0.2923717), -- 173197
(@OGUID+279, 0, 0, 0.9563047, -0.2923717), -- 173198
(@OGUID+280, 0, 0, 0.9563047, -0.2923717), -- 173199
(@OGUID+284, 0, 0, 0.9563047, -0.2923717), -- 173204
(@OGUID+285, 0, 0, 0.9563047, -0.2923717), -- 173206
(@OGUID+283, 0, 0, 0.9563047, -0.2923717), -- 177019
(@OGUID+286, 0, 0, 0.9563047, -0.2923717), -- 177020
(@OGUID+281, 0, 0, 0.9563047, -0.2923717), -- 177024
(@OGUID+282, 0, 0, 0.9563047, -0.2923717), -- 173202
(@OGUID+287, 0, 0, 0.9563047, -0.2923717), -- 173207
(@OGUID+288, 0, 0, 0.9563047, -0.2923717), -- 173216
(@OGUID+289, 0, 0, 0.9563047, -0.2923717), -- 173221
(@OGUID+290, 0, 0, 0.9563047, -0.2923717), -- 173226
(@OGUID+292, 0, 0, 0.9563047, -0.2923717), -- 173225
(@OGUID+291, 0, 0, 0.9563047, -0.2923717), -- 173114
(@OGUID+293, 0, 0, 0.9563047, -0.2923717), -- 173115
(@OGUID+294, 0, 0, 0.9563047, -0.2923717), -- 173205
(@OGUID+295, 0, 0, 0.9563047, -0.2923717), -- 173215
(@OGUID+296, 0, 0, 0.9563047, -0.2923717), -- 173223
(@OGUID+297, 0, 0, 0.9563047, -0.2923717), -- 173224
(@OGUID+298, 0, 0, 0.9563047, -0.2923717), -- 173106
(@OGUID+28, 0, 0, 0.6122171, 0.7906898), -- 177267
(@OGUID+27, 0, 0, 0.6122171, 0.7906898), -- 177268
(@OGUID+300, 0, 0, 0.9563047, -0.2923717), -- 172965
(@OGUID+303, 0, 0, 0.9563047, -0.2923717), -- 173208
(@OGUID+304, 0, 0, 0.9563047, -0.2923717), -- 173217
(@OGUID+305, 0, 0, 0.9563047, -0.2923717), -- 173219
(@OGUID+302, 0, 0, 0.9563047, -0.2923717), -- 173220
(@OGUID+301, 0, 0, 0.9563047, -0.2923717), -- 173222
(@OGUID+306, 0, 0, 0.9563047, -0.2923717), -- 173218
(@OGUID+307, 0, 0, 0.9563047, -0.2923717), -- 173111
(@OGUID+308, 0, 0, 0.9563047, -0.2923717), -- 177026
(@OGUID+311, 0, 0, 0.9563047, -0.2923717), -- 173209
(@OGUID+312, 0, 0, 0.9563047, -0.2923717), -- 173214
(@OGUID+309, 0, 0, 0.9563047, -0.2923717), -- 173107
(@OGUID+310, 0, 0, 0.9563047, -0.2923717), -- 173109
(@OGUID+315, 0, 0, 0.9563047, -0.2923717), -- 177022
(@OGUID+317, 0, 0, 0.9563047, -0.2923717), -- 173108
(@OGUID+316, 0, 0, 0.9563047, -0.2923717), -- 173110
(@OGUID+319, 0, 0, 0.9563047, -0.2923717), -- 173113
(@OGUID+318, 0, 0, 0.9563047, -0.2923717), -- 173125
(@OGUID+322, 0, 0, 0.9563047, -0.2923717), -- 173210
(@OGUID+320, 0, 0, 0.9563047, -0.2923717), -- 173211
(@OGUID+321, 0, 0, 0.9563047, -0.2923717), -- 173212
(@OGUID+323, 0, 0, 0.9563047, -0.2923717), -- 172966
(@OGUID+324, 0, 0, 0.9563047, -0.2923717), -- 177021
(@OGUID+328, 0, 0, 0.9563047, -0.2923717), -- 173213
(@OGUID+327, 0, 0, 0.9563047, -0.2923717), -- 172962
(@OGUID+326, 0, 0, 0.9563047, -0.2923717), -- 172963
(@OGUID+325, 0, 0, 0.9563047, -0.2923717), -- 172964
(@OGUID+108, 0, 0, 0.9044551, 0.4265688), -- 143336
(@OGUID+107, 0, 0, 0.9044551, 0.4265688), -- 143254
(@OGUID+331, 0, 0, 0.9563047, -0.2923717), -- 177025
(@OGUID+329, 0, 0, 0.9563047, -0.2923717), -- 172953
(@OGUID+330, 0, 0, 0.9563047, -0.2923717), -- 172967
(@OGUID+110, 0, 0, 0.9044551, 0.4265688), -- 32404
(@OGUID+111, 0, 0, 0.9044551, 0.4265688), -- 32429
(@OGUID+109, 0, 0, 0.9044551, 0.4265688), -- 143249
(@OGUID+337, 0, 0, 0.9563047, -0.2923717), -- 173164
(@OGUID+335, 0, 0, 0.9563047, -0.2923717), -- 179739
(@OGUID+338, 0, 0, 0.9563047, -0.2923717), -- 173171
(@OGUID+339, 0, 0, 0.9563047, -0.2923717), -- 173174
(@OGUID+340, 0, 0, 0.9563047, -0.2923717), -- 173176
(@OGUID+334, 0, 0, 0.9563047, -0.2923717), -- 173006
(@OGUID+336, 0, 0, 0.9563047, -0.2923717), -- 173116
(@OGUID+332, 0, 0, 0.9563047, -0.2923717), -- 172952
(@OGUID+333, 0, 0, 0.9563047, -0.2923717), -- 172968
(@OGUID+341, 0, 0, 0.9563047, -0.2923717), -- 173168
(@OGUID+343, 0, 0, 0.9563047, -0.2923717), -- 173166
(@OGUID+344, 0, 0, 0.9563047, -0.2923717), -- 175313
(@OGUID+345, 0, 0, 0.9563047, -0.2923717), -- 175318
(@OGUID+342, 0, 0, 0.9563047, -0.2923717), -- 173102
(@OGUID+347, 0, 0, 0.9563047, -0.2923717), -- 172945
(@OGUID+348, 0, 0, 0.9563047, -0.2923717), -- 179596
(@OGUID+349, 0, 0, 0.9563047, -0.2923717), -- 173026
(@OGUID+350, 0, 0, 0.9563047, -0.2923717), -- 173027
(@OGUID+353, 0, 0, 0.9563047, -0.2923717), -- 175317
(@OGUID+351, 0, 0, 0.9563047, -0.2923717), -- 172941
(@OGUID+352, 0, 0, 0.9563047, -0.2923717), -- 173016
(@OGUID+359, 0, 0, 0.9563047, -0.2923717), -- 175315
(@OGUID+354, 0, 0, 0.9563047, -0.2923717), -- 172942
(@OGUID+355, 0, 0, 0.9563047, -0.2923717), -- 173014
(@OGUID+356, 0, 0, 0.9563047, -0.2923717), -- 173015
(@OGUID+357, 0, 0, 0.9563047, -0.2923717), -- 173017
(@OGUID+358, 0, 0, 0.9563047, -0.2923717), -- 173029
(@OGUID+113, 0, 0, 0.9044551, 0.4265688), -- 171643
(@OGUID+112, 0, 0, 0.9044551, 0.4265688), -- 171558
(@OGUID+114, 0, 0, 0.9044551, 0.4265688), -- 171640
(@OGUID+117, 0, 0, 0.9044551, 0.4265688), -- 171658
(@OGUID+116, 0, 0, 0.9044551, 0.4265688), -- 171659
(@OGUID+115, 0, 0, 0.9044551, 0.4265688), -- 171642
(@OGUID+360, 0, 0, 0.9563047, -0.2923717), -- 173019
(@OGUID+364, 0, 0, 0.9563047, -0.2923717), -- 173037
(@OGUID+361, 0, 0, 0.9563047, -0.2923717), -- 172946
(@OGUID+362, 0, 0, 0.9563047, -0.2923717), -- 172954
(@OGUID+363, 0, 0, 0.9563047, -0.2923717), -- 173028
(@OGUID+365, 0, 0, 0.9563047, -0.2923717), -- 173036
(@OGUID+366, 0, 0, 0.9563047, -0.2923717), -- 173018
(@OGUID+367, 0, 0, 0.9563047, -0.2923717), -- 173030
(@OGUID+368, 0, 0, 0.9563047, -0.2923717), -- 173031
(@OGUID+369, 0, 0, 0.9563047, -0.2923717), -- 173032
(@OGUID+371, 0, 0, 0.9563047, -0.2923717), -- 173044
(@OGUID+372, 0, 0, 0.9563047, -0.2923717), -- 172948
(@OGUID+370, 0, 0, 0.9563047, -0.2923717), -- 173033
(@OGUID+373, 0, 0, 0.9563047, -0.2923717), -- 173043
(@OGUID+374, 0, 0, 0.9563047, -0.2923717), -- 173035
(@OGUID+375, 0, 0, 0.9563047, -0.2923717), -- 172955
(@OGUID+378, 0, 0, 0.9563047, -0.2923717), -- 172982
(@OGUID+379, 0, 0, 0.9563047, -0.2923717), -- 172983
(@OGUID+380, 0, 0, 0.9563047, -0.2923717), -- 172984
(@OGUID+381, 0, 0, 0.9563047, -0.2923717), -- 172985
(@OGUID+382, 0, 0, 0.9563047, -0.2923717), -- 172986
(@OGUID+383, 0, 0, 0.9563047, -0.2923717), -- 172987
(@OGUID+384, 0, 0, 0.9563047, -0.2923717), -- 172988
(@OGUID+385, 0, 0, 0.9563047, -0.2923717), -- 172989
(@OGUID+386, 0, 0, 0.9563047, -0.2923717), -- 172990
(@OGUID+387, 0, 0, 0.9563047, -0.2923717), -- 172991
(@OGUID+377, 0, 0, 0.9563047, -0.2923717), -- 173034
(@OGUID+388, 0, 0, 0.9563047, -0.2923717), -- 173103
(@OGUID+389, 0, 0, 0.9563047, -0.2923717), -- 173020
(@OGUID+390, 0, 0, 0.9563047, -0.2923717), -- 173105
(@OGUID+118, 0, 0, 0.9044551, 0.4265688), -- 171535
(@OGUID+119, 0, 0, 0.9044551, 0.4265688), -- 171536
(@OGUID+120, 0, 0, 0.9044551, 0.4265688), -- 171650
(@OGUID+121, 0, 0, 0.9044551, 0.4265688), -- 171651
(@OGUID+391, 0, 0, 0.9563047, -0.2923717), -- 173046
(@OGUID+392, 0, 0, 0.9563047, -0.2923717), -- 173047
(@OGUID+394, 0, 0, 0.9563047, -0.2923717), -- 173053
(@OGUID+393, 0, 0, 0.9563047, -0.2923717), -- 172947
(@OGUID+395, 0, 0, 0.9563047, -0.2923717), -- 173045
(@OGUID+399, 0, 0, 0.9563047, -0.2923717), -- 173055
(@OGUID+401, 0, 0, 0.9563047, -0.2923717), -- 175314
(@OGUID+400, 0, 0, 0.9563047, -0.2923717), -- 173104
(@OGUID+396, 0, 0, 0.9563047, -0.2923717), -- 172949
(@OGUID+397, 0, 0, 0.9563047, -0.2923717), -- 173023
(@OGUID+398, 0, 0, 0.9563047, -0.2923717), -- 173024
(@OGUID+402, 0, 0, 0.9563047, -0.2923717), -- 173048
(@OGUID+403, 0, 0, 0.9563047, -0.2923717), -- 173054
(@OGUID+404, 0, 0, 0.9563047, -0.2923717), -- 173021
(@OGUID+405, 0, 0, 0.9563047, -0.2923717), -- 173038
(@OGUID+406, 0, 0, 0.9563047, -0.2923717), -- 173040
(@OGUID+407, 0, 0, 0.9563047, -0.2923717), -- 173041
(@OGUID+408, 0, 0, 0.9563047, -0.2923717), -- 173039
(@OGUID+409, 0, 0, 0.9563047, -0.2923717), -- 173049
(@OGUID+410, 0, 0, 0.9563047, -0.2923717), -- 173051
(@OGUID+411, 0, 0, 0.9563047, -0.2923717), -- 173052
(@OGUID+412, 0, 0, 0.9563047, -0.2923717), -- 173042
(@OGUID+413, 0, 0, 0.9563047, -0.2923717), -- 177008
(@OGUID+122, 0, 0, 0.9044551, 0.4265688), -- 171539
(@OGUID+123, 0, 0, 0.9044551, 0.4265688), -- 171540
(@OGUID+124, 0, 0, 0.9044551, 0.4265688), -- 171652
(@OGUID+125, 0, 0, 0.9044551, 0.4265688), -- 171653
(@OGUID+126, 0, 0, 0.9044551, 0.4265688), -- 171654
(@OGUID+127, 0, 0, 0.9044551, 0.4265688), -- 171655
(@OGUID+128, 0, 0, 0.9044551, 0.4265688), -- 171656
(@OGUID+129, 0, 0, 0.9044551, 0.4265688), -- 171657
(@OGUID+131, 0, 0, 0.9044551, 0.4265688), -- 171538
(@OGUID+414, 0, 0, 0.9563047, -0.2923717), -- 172992
(@OGUID+132, 0, 0, 0.9044551, 0.4265688), -- 171537
(@OGUID+415, 0, 0, 0.9563047, -0.2923717), -- 173079
(@OGUID+416, 0, 0, 0.9563047, -0.2923717), -- 177009
(@OGUID+417, 0, 0, 0.9563047, -0.2923717), -- 173076
(@OGUID+418, 0, 0, 0.9563047, -0.2923717), -- 173087
(@OGUID+419, 0, 0, 0.9563047, -0.2923717), -- 173075
(@OGUID+422, 0, 0, 0.9563047, -0.2923717), -- 173086
(@OGUID+421, 0, 0, 0.9563047, -0.2923717), -- 173088
(@OGUID+425, 0, 0, 0.9563047, -0.2923717), -- 173084
(@OGUID+424, 0, 0, 0.9563047, -0.2923717), -- 173069
(@OGUID+426, 0, 0, 0.9563047, -0.2923717), -- 177012
(@OGUID+428, 0, 0, 0.9563047, -0.2923717), -- 173100
(@OGUID+427, 0, 0, 0.9563047, -0.2923717), -- 173068
(@OGUID+429, 0, 0, 0.9563047, -0.2923717), -- 173080
(@OGUID+432, 0, 0, 0.9563047, -0.2923717), -- 173081
(@OGUID+431, 0, 0, 0.9563047, -0.2923717); -- 173063

INSERT INTO `gameobject_addon` (`guid`, `parent_rotation0`, `parent_rotation1`, `parent_rotation2`, `parent_rotation3`) VALUES
(@OGUID+433, 0, 0, 0.9563047, -0.2923717), -- 173077
(@OGUID+434, 0, 0, 0.9563047, -0.2923717), -- 173099
(@OGUID+437, 0, 0, 0.9563047, -0.2923717), -- 173082
(@OGUID+440, 0, 0, 0.9563047, -0.2923717), -- 173090
(@OGUID+435, 0, 0, 0.9563047, -0.2923717), -- 173091
(@OGUID+436, 0, 0, 0.9563047, -0.2923717), -- 173093
(@OGUID+438, 0, 0, 0.9563047, -0.2923717), -- 173122
(@OGUID+439, 0, 0, 0.9563047, -0.2923717), -- 173123
(@OGUID+441, 0, 0, 0.9563047, -0.2923717), -- 173070
(@OGUID+443, 0, 0, 0.9563047, -0.2923717), -- 173092
(@OGUID+446, 0, 0, 0.9563047, -0.2923717), -- 173118
(@OGUID+445, 0, 0, 0.9563047, -0.2923717), -- 173120
(@OGUID+442, 0, 0, 0.9563047, -0.2923717), -- 173121
(@OGUID+444, 0, 0, 0.9563047, -0.2923717), -- 173071
(@OGUID+448, 0, 0, 0.9563047, -0.2923717), -- 173089
(@OGUID+447, 0, 0, 0.9563047, -0.2923717), -- 173119
(@OGUID+449, 0, 0, 0.9563047, -0.2923717), -- 173064
(@OGUID+451, 0, 0, 0.9563047, -0.2923717), -- 173065
(@OGUID+450, 0, 0, 0.9563047, -0.2923717), -- 173066
(@OGUID+452, 0, 0, 0.9563047, -0.2923717), -- 173073
(@OGUID+453, 0, 0, 0.9563047, -0.2923717), -- 173083
(@OGUID+454, 0, 0, 0.9563047, -0.2923717), -- 173094
(@OGUID+455, 0, 0, 0.9563047, -0.2923717), -- 173095
(@OGUID+457, 0, 0, 0.9563047, -0.2923717), -- 177011
(@OGUID+456, 0, 0, 0.9563047, -0.2923717), -- 173096
(@OGUID+459, 0, 0, 0.9563047, -0.2923717), -- 177010
(@OGUID+460, 0, 0, 0.9563047, -0.2923717), -- 173072
(@OGUID+462, 0, 0, 0.9563047, -0.2923717), -- 173074
(@OGUID+463, 0, 0, 0.9563047, -0.2923717), -- 173085
(@OGUID+461, 0, 0, 0.9563047, -0.2923717), -- 173067
(@OGUID+464, 0, 0, 0.9563047, -0.2923717), -- 177006
(@OGUID+465, 0, 0, 0.9563047, -0.2923717), -- 177007
(@OGUID+467, 0, 0, 0.9563047, -0.2923717), -- 177013
(@OGUID+470, 0, 0, 0.9563047, -0.2923717), -- 173178
(@OGUID+469, 0, 0, 0.9563047, -0.2923717), -- 173179
(@OGUID+471, 0, 0, 0.9563047, -0.2923717), -- 173184
(@OGUID+472, 0, 0, 0.9563047, -0.2923717), -- 173194
(@OGUID+473, 0, 0, 0.9563047, -0.2923717), -- 173050
(@OGUID+474, 0, 0, 0.9563047, -0.2923717), -- 172944
(@OGUID+475, 0, 0, 0.9563047, -0.2923717), -- 172951
(@OGUID+476, 0, 0, 0.9563047, -0.2923717), -- 173022
(@OGUID+477, 0, 0, 0.9563047, -0.2923717), -- 172956
(@OGUID+478, 0, 0, 0.9563047, -0.2923717), -- 172950
(@OGUID+479, 0, 0, 0.9563047, -0.2923717), -- 177003
(@OGUID+483, 0, 0, 0.9563047, -0.2923717), -- 175658
(@OGUID+480, 0, 0, 0.9563047, -0.2923717), -- 175312
(@OGUID+481, 0, 0, 0.9563047, -0.2923717), -- 173056
(@OGUID+482, 0, 0, 0.9563047, -0.2923717), -- 173060
(@OGUID+484, 0, 0, 0.9563047, -0.2923717), -- 173059
(@OGUID+485, 0, 0, 0.9563047, -0.2923717), -- 173061
(@OGUID+487, 0, 0, 0.9563047, -0.2923717), -- 172978
(@OGUID+488, 0, 0, 0.9563047, -0.2923717), -- 172979
(@OGUID+489, 0, 0, 0.9563047, -0.2923717), -- 172980
(@OGUID+490, 0, 0, 0.9563047, -0.2923717), -- 172981
(@OGUID+493, 0, 0, 0.9563047, -0.2923717), -- 177004
(@OGUID+486, 0, 0, 0.9563047, -0.2923717), -- 175319
(@OGUID+491, 0, 0, 0.9563047, -0.2923717), -- 173057
(@OGUID+492, 0, 0, 0.9563047, -0.2923717), -- 173058
(@OGUID+495, 0, 0, 0.9563047, -0.2923717), -- 175316
(@OGUID+494, 0, 0, 0.9563047, -0.2923717), -- 173173
(@OGUID+497, 0, 0, 0.9563047, -0.2923717), -- 177005
(@OGUID+499, 0, 0, 0.9563047, -0.2923717), -- 173140
(@OGUID+498, 0, 0, 0.9563047, -0.2923717), -- 173172
(@OGUID+500, 0, 0, 0.9563047, -0.2923717), -- 173141
(@OGUID+133, 0, 0, 0.9044551, 0.4265688), -- 143318
(@OGUID+501, 0, 0, 0.9563047, -0.2923717), -- 173137
(@OGUID+502, 0, 0, 0.9563047, -0.2923717), -- 173138
(@OGUID+503, 0, 0, 0.9563047, -0.2923717), -- 173139
(@OGUID+504, 0, 0, 0.9563047, -0.2923717), -- 173142
(@OGUID+134, 0, 0, 0.9044551, 0.4265688), -- 143319
(@OGUID+135, 0, 0, 0.9044551, 0.4265688), -- 143320
(@OGUID+137, 0, 0, 0.9044551, 0.4265688), -- 149413
(@OGUID+136, 0, 0, 0.9044551, 0.4265688), -- 143322
(@OGUID+138, 0, 0, 0.9044551, 0.4265688), -- 171580
(@OGUID+139, 0, 0, 0.9044551, 0.4265688), -- 171581
(@OGUID+140, 0, 0, 0.9044551, 0.4265688), -- 171582
(@OGUID+141, 0, 0, 0.9044551, 0.4265688), -- 171583
(@OGUID+506, 0, 0, 0.9563047, -0.2923717), -- 173143
(@OGUID+507, 0, 0, 0.9563047, -0.2923717), -- 173144
(@OGUID+505, 0, 0, 0.9563047, -0.2923717), -- 173177
(@OGUID+150, 0, 0, 0.9044551, 0.4265688), -- 171612
(@OGUID+151, 0, 0, 0.9044551, 0.4265688), -- 171613
(@OGUID+145, 0, 0, 0.9044551, 0.4265688), -- 171584
(@OGUID+152, 0, 0, 0.9044551, 0.4265688), -- 171614
(@OGUID+146, 0, 0, 0.9044551, 0.4265688), -- 171585
(@OGUID+153, 0, 0, 0.9044551, 0.4265688), -- 171615
(@OGUID+147, 0, 0, 0.9044551, 0.4265688), -- 171586
(@OGUID+148, 0, 0, 0.9044551, 0.4265688), -- 171587
(@OGUID+149, 0, 0, 0.9044551, 0.4265688), -- 171588
(@OGUID+143, 0, 0, 0.9044551, 0.4265688), -- 143321
(@OGUID+154, 0, 0, 0.9044551, 0.4265688), -- 171616
(@OGUID+155, 0, 0, 0.9044551, 0.4265688), -- 171617
(@OGUID+156, 0, 0, 0.9044551, 0.4265688), -- 171618
(@OGUID+144, 0, 0, 0.9044551, 0.4265688), -- 143326
(@OGUID+157, 0, 0, 0.9044551, 0.4265688), -- 171608
(@OGUID+158, 0, 0, 0.9044551, 0.4265688), -- 171609
(@OGUID+159, 0, 0, 0.9044551, 0.4265688), -- 171610
(@OGUID+160, 0, 0, 0.9044551, 0.4265688), -- 171611
(@OGUID+508, 0, 0, 0.9563047, -0.2923717), -- 173165
(@OGUID+509, 0, 0, 0.9563047, -0.2923717), -- 173169
(@OGUID+166, 0, 0, 0.9044551, 0.4265688), -- 171524
(@OGUID+167, 0, 0, 0.9044551, 0.4265688), -- 143324
(@OGUID+164, 0, 0, 0.9044551, 0.4265688), -- 143325
(@OGUID+163, 0, 0, 0.9044551, 0.4265688), -- 137646
(@OGUID+161, 0, 0, 0.9044551, 0.4265688), -- 32427
(@OGUID+162, 0, 0, 0.9044551, 0.4265688), -- 32431
(@OGUID+165, 0, 0, 0.9044551, 0.4265688), -- 144159
(@OGUID+511, 0, 0, 0.9563047, -0.2923717), -- 173145
(@OGUID+510, 0, 0, 0.9563047, -0.2923717), -- 173175
(@OGUID+513, 0, 0, 0.9563047, -0.2923717), -- 173136
(@OGUID+514, 0, 0, 0.9563047, -0.2923717), -- 173146
(@OGUID+512, 0, 0, 0.9563047, -0.2923717), -- 173167
(@OGUID+168, 0, 0, 0.9044551, 0.4265688), -- 143323
(@OGUID+171, 0, 0, 0.9044551, 0.4265688), -- 171698
(@OGUID+172, 0, 0, 0.9044551, 0.4265688), -- 171699
(@OGUID+169, 0, 0, 0.9044551, 0.4265688), -- 171633
(@OGUID+170, 0, 0, 0.9044551, 0.4265688), -- 171634
(@OGUID+516, 0, 0, 0.9563047, -0.2923717), -- 173132
(@OGUID+515, 0, 0, 0.9563047, -0.2923717), -- 173131
(@OGUID+174, 0, 0, 0.9044551, 0.4265688), -- 171697
(@OGUID+176, 0, 0, 0.9044551, 0.4265688), -- 176628
(@OGUID+177, 0, 0, 0.9044551, 0.4265688), -- 176629
(@OGUID+175, 0, 0, 0.9044551, 0.4265688), -- 26499
(@OGUID+517, 0, 0, 0.9563047, -0.2923717), -- 173130
(@OGUID+178, 0, 0, 0.9044551, 0.4265688), -- 171696
(@OGUID+183, 0, 0, 0.9044551, 0.4265688), -- 171702
(@OGUID+182, 0, 0, 0.9044551, 0.4265688), -- 171704
(@OGUID+184, 0, 0, 0.9044551, 0.4265688), -- 176624
(@OGUID+179, 0, 0, 0.9044551, 0.4265688), -- 171635
(@OGUID+181, 0, 0, 0.9044551, 0.4265688), -- 176627
(@OGUID+180, 0, 0, 0.9044551, 0.4265688), -- 176924
(@OGUID+185, 0, 0, 0.9044551, 0.4265688), -- 176626
(@OGUID+186, 0, 0, 0.9044551, 0.4265688), -- 171636
(@OGUID+187, 0, 0, 0.9044551, 0.4265688), -- 176625
(@OGUID+522, 0, 0, 0.9563047, -0.2923717), -- 172977
(@OGUID+518, 0, 0, 0.9563047, -0.2923717), -- 173163
(@OGUID+519, 0, 0, 0.9563047, -0.2923717), -- 173170
(@OGUID+523, 0, 0, 0.9563047, -0.2923717), -- 172993
(@OGUID+524, 0, 0, 0.9563047, -0.2923717), -- 172994
(@OGUID+525, 0, 0, 0.9563047, -0.2923717), -- 172995
(@OGUID+527, 0, 0, 0.9563047, -0.2923717), -- 173062
(@OGUID+526, 0, 0, 0.9563047, -0.2923717), -- 173025
(@OGUID+520, 0, 0, 0.9563047, -0.2923717), -- 172975
(@OGUID+521, 0, 0, 0.9563047, -0.2923717), -- 172976
(@OGUID+191, 0, 0, 0.9044551, 0.4265688), -- 171758
(@OGUID+194, 0, 0, 0.9044551, 0.4265688), -- 171701
(@OGUID+190, 0, 0, 0.9044551, 0.4265688), -- 171703
(@OGUID+192, 0, 0, 0.9044551, 0.4265688), -- 171764
(@OGUID+193, 0, 0, 0.9044551, 0.4265688), -- 32385
(@OGUID+200, 0, 0, 0.9044551, 0.4265688), -- 171695
(@OGUID+196, 0, 0, 0.9044551, 0.4265688), -- 171757
(@OGUID+201, 0, 0, 0.9044551, 0.4265688), -- 171700
(@OGUID+195, 0, 0, 0.9044551, 0.4265688), -- 149418
(@OGUID+198, 0, 0, 0.9044551, 0.4265688), -- 137644
(@OGUID+197, 0, 0, 0.9044551, 0.4265688), -- 32424
(@OGUID+199, 0, 0, 0.9044551, 0.4265688), -- 142838
(@OGUID+202, 0, 0, 0.9044551, 0.4265688), -- 143253
(@OGUID+205, 0, 0, 0.9044551, 0.4265688), -- 143317
(@OGUID+208, 0, 0, 0.9044551, 0.4265688), -- 171693
(@OGUID+209, 0, 0, 0.9044551, 0.4265688), -- 171694
(@OGUID+203, 0, 0, 0.9044551, 0.4265688), -- 171761
(@OGUID+206, 0, 0, 0.9044551, 0.4265688), -- 171648
(@OGUID+207, 0, 0, 0.9044551, 0.4265688), -- 171649
(@OGUID+204, 0, 0, 0.9044551, 0.4265688), -- 32349
(@OGUID+529, 0, 0, 0.9563047, -0.2923717), -- 177002
(@OGUID+528, 0, 0, 0.9563047, -0.2923717), -- 173101
(@OGUID+212, 0, 0, 0.9044551, 0.4265688), -- 171762
(@OGUID+213, 0, 0, 0.9044551, 0.4265688), -- 171569
(@OGUID+214, 0, 0, 0.9044551, 0.4265688), -- 171570
(@OGUID+215, 0, 0, 0.9044551, 0.4265688), -- 171573
(@OGUID+216, 0, 0, 0.9044551, 0.4265688), -- 171574
(@OGUID+217, 0, 0, 0.9044551, 0.4265688), -- 171575
(@OGUID+218, 0, 0, 0.9044551, 0.4265688), -- 171576
(@OGUID+219, 0, 0, 0.9044551, 0.4265688), -- 171577
(@OGUID+220, 0, 0, 0.9044551, 0.4265688), -- 171578
(@OGUID+221, 0, 0, 0.9044551, 0.4265688), -- 171579
(@OGUID+530, 0, 0, 0.9563047, -0.2923717), -- 173007
(@OGUID+226, 0, 0, 0.9044551, 0.4265688), -- 171692
(@OGUID+222, 0, 0, 0.9044551, 0.4265688), -- 171544
(@OGUID+223, 0, 0, 0.9044551, 0.4265688), -- 171545
(@OGUID+224, 0, 0, 0.9044551, 0.4265688), -- 171571
(@OGUID+225, 0, 0, 0.9044551, 0.4265688), -- 171572
(@OGUID+227, 0, 0, 0.9044551, 0.4265688), -- 171546
(@OGUID+228, 0, 0, 0.9044551, 0.4265688), -- 171547
(@OGUID+531, 0, 0, 0.9563047, -0.2923717), -- 173117
(@OGUID+229, 0, 0, 0.9044551, 0.4265688), -- 171543
(@OGUID+230, 0, 0, 0.9044551, 0.4265688), -- 171660
(@OGUID+231, 0, 0, 0.9044551, 0.4265688), -- 171661
(@OGUID+537, 0, 0, 0.9563047, -0.2923717), -- 179740
(@OGUID+532, 0, 0, 0.9563047, -0.2923717), -- 172969
(@OGUID+533, 0, 0, 0.9563047, -0.2923717), -- 172972
(@OGUID+534, 0, 0, 0.9563047, -0.2923717), -- 172973
(@OGUID+535, 0, 0, 0.9563047, -0.2923717), -- 172974
(@OGUID+536, 0, 0, 0.9563047, -0.2923717), -- 176518
(@OGUID+538, 0, 0, 0.9563047, -0.2923717), -- 176517
(@OGUID+540, 0, 0, 0.9563047, -0.2923717), -- 176521
(@OGUID+539, 0, 0, 0.9563047, -0.2923717), -- 176516
(@OGUID+541, 0, 0, 0.9563047, -0.2923717), -- 176519
(@OGUID+542, 0, 0, 0.9563047, -0.2923717), -- 176520
(@OGUID+543, 0, 0, 0.9563047, -0.2923717), -- 179741
(@OGUID+544, 0, 0, 0.9563047, -0.2923717), -- 179742
(@OGUID+545, 0, 0, 0.9563047, -0.2923717), -- 177023
(@OGUID+550, 0, 0, 0.9563047, -0.2923717), -- 177016
(@OGUID+548, 0, 0, 0.9563047, -0.2923717), -- 172996
(@OGUID+549, 0, 0, 0.9563047, -0.2923717), -- 172997
(@OGUID+546, 0, 0, 0.9563047, -0.2923717), -- 172970
(@OGUID+547, 0, 0, 0.9563047, -0.2923717), -- 172971
(@OGUID+551, 0, 0, 0.9563047, -0.2923717), -- 173160
(@OGUID+552, 0, 0, 0.9563047, -0.2923717), -- 173161
(@OGUID+232, 0, 0, 0.9044551, 0.4265688), -- 26496
(@OGUID+553, 0, 0, 0.9563047, -0.2923717), -- 173157
(@OGUID+554, 0, 0, 0.9563047, -0.2923717), -- 173159
(@OGUID+555, 0, 0, 0.9563047, -0.2923717), -- 177014
(@OGUID+556, 0, 0, 0.9563047, -0.2923717), -- 173162
(@OGUID+557, 0, 0, 0.9563047, -0.2923717); -- 177015


DELETE FROM `spell_target_position` WHERE (`entry`=3563 AND `effect_index`=0);
INSERT INTO `spell_target_position` (`entry`, `effect_index`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `sniff_build`) VALUES
(3563, 0, 0, 1773.42, 61.7391, -46.3215, 0, 35186); -- Spell: 3563 Efffect: 0 (0)


DELETE FROM `spell_unique_caster` WHERE (`caster_id`=11865 AND `caster_type`='Creature' AND `spell_id`=15987) OR (`caster_id`=11865 AND `caster_type`='Creature' AND `spell_id`=15986) OR (`caster_id`=5116 AND `caster_type`='Creature' AND `spell_id`=14334) OR (`caster_id`=3401 AND `caster_type`='Creature' AND `spell_id`=1781) OR (`caster_id`=3357 AND `caster_type`='Creature' AND `spell_id`=3317) OR (`caster_id`=15350 AND `caster_type`='Creature' AND `spell_id`=24965);
INSERT INTO `spell_unique_caster` (`caster_id`, `caster_type`, `spell_id`) VALUES
(11865, 'Creature', 15987),
(11865, 'Creature', 15986),
(5116, 'Creature', 14334),
(3401, 'Creature', 1781),
(3357, 'Creature', 3317),
(15350, 'Creature', 24965);


DELETE FROM `creature_display_info_addon` WHERE `display_id` IN (2090, 2109, 9391, 7624, 15250, 9272, 9742, 7999, 7622, 7623, 7625, 7628, 15664, 5372, 11803, 15730, 2141, 4516, 8572, 2110, 2100, 7998, 15249, 2092, 2093, 10188, 2094, 7621, 2114, 7620, 10617, 2129, 2132, 3129, 7627, 4517, 5847, 4568, 10586, 4518, 9392, 2133, 14758, 2126, 2127, 2098, 2083, 3002, 7626, 5487, 2104, 193, 4515, 1560, 15441, 15449, 3527, 15599, 15457, 15719, 15458, 15459, 15597, 1670, 3524, 3077, 5408, 15442, 15443, 3065, 15708, 15712, 15714, 15548, 3458, 3526, 10635, 3124, 3125, 15445, 3591, 15447, 15450, 15451, 15453, 3072, 9258, 3073, 3457, 7006, 7028, 5377, 3063, 7041, 3064, 2184, 15662, 3078, 2140, 4259, 4601, 9338, 15255, 15256, 6062, 15100, 15114, 4602, 14732, 14429, 2111, 2107, 2095, 10614, 2118, 2117, 2084, 2085, 2089, 10689, 2124, 2125, 2091, 2119, 2097, 2738, 2101, 1313, 4260, 4356, 2120, 2088, 11686, 15435, 1317, 1319, 1321, 3546, 3564, 13843, 5706, 3604, 3605, 5205, 3608, 7137, 3606, 3609, 1310, 1318, 1320, 15596, 1314, 2086, 15248, 9572, 14413, 15322, 1312, 14415, 1322, 8000, 3128, 4307, 7629, 1072, 8001, 9133, 1311, 4527, 15454, 3068, 15455, 15456, 1206, 3075, 1329, 1331, 4073, 1323, 3057, 3076, 3754, 1328, 2734, 2735, 1390, 1391, 7120, 3053, 3054, 3055, 3056, 11806, 12289, 15389, 12992, 4995, 3079, 3080, 3106, 6839, 1394, 1386, 1389, 1393, 14757, 1315, 1385, 4384, 5846, 1316, 1388, 4350, 1387, 4362, 4358, 1366, 5770, 1367, 5769, 10589, 14404, 1369, 1368, 1381, 1333, 1332, 5535, 1380, 1379, 14499, 14589, 14616, 4386, 10472, 8631, 4359, 15033, 7135, 7136, 3850, 1374, 15032, 15112, 1375, 15387, 4242, 10696, 10697, 4382, 10695, 9739, 6873, 6843, 6854, 6005, 1378, 4351, 1377, 14216, 4239, 4241, 9261, 6064, 1373, 4464, 14575, 2328, 2327, 1384, 14574, 247, 9336, 14573, 7921, 10578, 15731, 1326, 1371, 1372, 4492, 1335, 4545, 4354, 1324, 1325, 15724, 14361, 14363, 14360, 13341, 4514, 1360, 4231, 1330, 4534, 4355, 14362, 5410, 3041, 3040, 2999, 3081, 3107, 1334, 3042, 1327, 3039, 3043, 3525, 14396, 6588, 3050, 13850, 3038, 9131, 4361, 15257, 7989, 3037, 3044, 3045, 7990, 1655, 3049, 5190, 15966, 1358, 4360, 8171, 3597, 4889, 3046, 10186, 14235, 4546, 3047, 3051, 12681, 1392, 2957, 6303, 15653, 15508, 15536, 7631, 15650, 15502, 15535, 15472, 15661, 15717, 15720, 15541, 15503, 15652, 15537, 15539, 15460, 15702, 1370, 15461, 15466, 1395, 15543, 15722, 14414, 15462, 15544, 15542);
INSERT INTO `creature_display_info_addon` (`display_id`, `bounding_radius`, `combat_reach`, `speed_walk`, `speed_run`, `gender`, `sniff_build`) VALUES
(2090, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(2109, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(9391, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(7624, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(15250, 0.236, 1.5, 1, 1.142857, 1, 35186),
(9272, 1.07217, 4.455, 1, 1.142857, 0, 35186),
(9742, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(7999, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(7622, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(7623, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(7625, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(7628, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(15664, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(5372, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(11803, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(15730, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2141, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(4516, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(8572, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2110, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2100, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(7998, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(15249, 0.236, 1.5, 1, 1.142857, 1, 35186),
(2092, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(2093, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(10188, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(2094, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(7621, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2114, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(7620, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(10617, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(2129, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(2132, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(3129, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(7627, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(4517, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(5847, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(4568, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(10586, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(4518, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(9392, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2133, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(14758, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(2126, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2127, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2098, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(2083, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(3002, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(7626, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(5487, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2104, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(193, 1.176, 1, 1, 0.8571429, 2, 35186),
(4515, 0.4092, 1.65, 1, 1.142857, 0, 35186),
(1560, 0.17625, 0.75, 1, 0.8571429, 2, 35186),
(15441, 0.347, 1.5, 1, 1.142857, 0, 35186),
(15449, 0.208, 1.5, 1, 1.142857, 1, 35186),
(3527, 0.347, 1.5, 1, 1.142857, 0, 35186),
(15599, 0.347, 1.5, 1, 1.142857, 1, 35186),
(15457, 0.3519, 1.725, 1, 1.142857, 0, 35186),
(15719, 0.208, 1.5, 1, 1.142857, 1, 35186),
(15458, 0.3519, 1.725, 1, 1.142857, 1, 35186),
(15459, 0.306, 1.5, 1, 1.142857, 1, 35186),
(15597, 0.347, 1.5, 1, 1.142857, 0, 35186),
(1670, 0.347, 1.5, 1, 1.142857, 1, 35186),
(3524, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3077, 0.347, 1.5, 1, 1.142857, 0, 35186),
(5408, 0.347, 1.5, 1, 1.142857, 1, 35186),
(15442, 0.306, 1.5, 1, 1.142857, 0, 35186),
(15443, 0.347, 1.5, 1, 1.142857, 1, 35186),
(3065, 0.347, 1.5, 1, 1.142857, 1, 35186),
(15708, 0.306, 1.5, 1, 1.142857, 1, 35186),
(15712, 0.3519, 1.725, 1, 1.142857, 1, 35186),
(15714, 0.347, 1.5, 1, 1.142857, 0, 35186),
(15548, 0.4092, 1.65, 1, 1.385714, 0, 35186),
(3458, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3526, 0.347, 1.5, 1, 1.142857, 0, 35186),
(10635, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3124, 0.3519, 1.725, 1, 1.142857, 1, 35186),
(3125, 0.3519, 1.725, 1, 1.142857, 1, 35186),
(15445, 0.3519, 1.725, 1, 1.142857, 0, 35186),
(3591, 0.208, 1.5, 1, 1.142857, 1, 35186),
(15447, 0.389, 1.5, 1, 1.142857, 0, 35186),
(15450, 0.347, 1.5, 1, 1.142857, 1, 35186),
(15451, 0.306, 1.5, 1, 1.142857, 0, 35186),
(15453, 0.3519, 1.725, 1, 1.142857, 1, 35186),
(3072, 0.347, 1.5, 1, 1.142857, 0, 35186),
(9258, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3073, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3457, 0.3519, 1.725, 1, 1.142857, 0, 35186),
(7006, 0.42228, 2.07, 1, 1.142857, 0, 35186),
(7028, 0.3519, 1.725, 1, 1.142857, 0, 35186),
(5377, 0.3519, 1.725, 1, 1.142857, 0, 35186),
(3063, 0.347, 1.5, 1, 1.142857, 1, 35186),
(7041, 0.3519, 1.725, 1, 1.142857, 0, 35186),
(3064, 0.347, 1.5, 1, 1.142857, 1, 35186),
(2184, 0.3519, 1.725, 1, 1.142857, 0, 35186),
(15662, 0.3817, 1.65, 1, 1.385714, 0, 35186),
(3078, 0.347, 1.5, 1, 1.142857, 0, 35186),
(2140, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(4259, 0.372, 1.5, 1, 1.142857, 0, 35186),
(4601, 0.236, 1.5, 1, 1.142857, 1, 35186),
(9338, 0.347, 1.5, 1, 1.142857, 1, 35186),
(15255, 0.306, 1.5, 1, 1.142857, 1, 35186),
(15256, 0.306, 1.5, 1, 1.142857, 1, 35186),
(6062, 0.347, 1.5, 1, 1.142857, 0, 35186),
(15100, 0.3366, 1.65, 1, 1.142857, 1, 35186),
(15114, 0.3366, 1.65, 1, 1.142857, 0, 35186),
(4602, 0.372, 1.5, 1, 1.142857, 0, 35186),
(14732, 0.4092, 1.65, 1, 2.285714, 0, 35186),
(14429, 0.4092, 1.65, 1, 1.142857, 0, 35186),
(2111, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2107, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2095, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(10614, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(2118, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2117, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2084, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(2085, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(2089, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(10689, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(2124, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2125, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2091, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(2119, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2097, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(2738, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(2101, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(1313, 0.372, 1.5, 1, 1.142857, 0, 35186),
(4260, 0.236, 1.5, 1, 1.142857, 1, 35186),
(4356, 0.236, 1.5, 1, 1.142857, 1, 35186),
(2120, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(2088, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(11686, 0.5, 1, 1, 1.142857, 2, 35186),
(15435, 0.39, 0, 1, 0.9920629, 2, 35186),
(1317, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1319, 0.236, 1.5, 1, 1.142857, 1, 35186),
(1321, 0.372, 1.5, 1, 1.142857, 0, 35186),
(3546, 0.372, 1.5, 1, 1.142857, 0, 35186),
(3564, 0.236, 1.5, 1, 1.142857, 1, 35186),
(13843, 0.236, 1.5, 1, 1.142857, 1, 35186),
(5706, 0.236, 1.5, 1, 1.142857, 1, 35186),
(3604, 0.372, 1.5, 1, 1.142857, 0, 35186),
(3605, 0.372, 1.5, 1, 1.142857, 0, 35186),
(5205, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(3608, 0.306, 1.5, 1, 1.142857, 0, 35186),
(7137, 0.306, 1.5, 1, 1.142857, 0, 35186),
(3606, 0.372, 1.5, 1, 1.142857, 0, 35186),
(3609, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1310, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1318, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1320, 0.372, 1.5, 1, 1.142857, 0, 35186),
(15596, 0.347, 1.5, 1, 1.142857, 0, 35186),
(1314, 0.372, 1.5, 1, 1.142857, 0, 35186),
(2086, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(15248, 0.372, 1.5, 1, 1.142857, 0, 35186),
(9572, 0.4, 0.5, 1, 1.142857, 2, 35186),
(14413, 0.372, 1.5, 1, 1.142857, 0, 35186),
(15322, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(1312, 0.236, 1.5, 1, 1.142857, 1, 35186),
(14415, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1322, 1.047, 4.5, 1, 1.142857, 1, 35186),
(8000, 0.372, 1.5, 1, 1.142857, 0, 35186),
(3128, 0.236, 1.5, 1, 1.142857, 1, 35186),
(4307, 1.16964, 4.860001, 1, 1.142857, 0, 35186),
(7629, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(1072, 0.122, 1, 1, 0.8571429, 2, 35186),
(8001, 0.372, 1.5, 1, 1.142857, 0, 35186),
(9133, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1311, 0.372, 1.5, 1, 1.142857, 0, 35186),
(4527, 0.4464, 1.8, 1, 1.142857, 0, 35186),
(15454, 0.306, 1.5, 1, 1.142857, 1, 35186),
(3068, 0.347, 1.5, 1, 1.142857, 1, 35186),
(15455, 0.208, 1.5, 1, 1.142857, 1, 35186),
(15456, 0.389, 1.5, 1, 1.142857, 0, 35186),
(1206, 0.35, 0.5, 1, 1.142857, 2, 35186),
(3075, 0.347, 1.5, 1, 1.142857, 0, 35186),
(1329, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1331, 0.372, 1.5, 1, 1.142857, 0, 35186),
(4073, 0.306, 1.5, 1, 1.142857, 0, 35186),
(1323, 0.372, 1.5, 1, 1.142857, 0, 35186),
(3057, 0.347, 1.5, 1, 1.142857, 1, 35186),
(3076, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3754, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1328, 0.372, 1.5, 1, 1.142857, 0, 35186),
(2734, 0.306, 1.5, 1, 1.142857, 1, 35186),
(2735, 0.306, 1.5, 1, 1.142857, 0, 35186),
(1390, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1391, 0.372, 1.5, 1, 1.142857, 0, 35186),
(7120, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3053, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3054, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3055, 0.3519, 1.725, 1, 1.142857, 0, 35186),
(3056, 0.347, 1.5, 1, 1.142857, 1, 35186),
(11806, 0.347, 1.5, 1, 1.142857, 0, 35186),
(12289, 0.3817, 1.65, 1, 1.142857, 0, 35186),
(15389, 0.347, 1.5, 1, 1.142857, 0, 35186),
(12992, 0.3519, 1.725, 1, 1.142857, 1, 35186),
(4995, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3079, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3080, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3106, 0.3519, 1.725, 1, 1.142857, 1, 35186),
(6839, 0.306, 1.5, 1, 1.142857, 0, 35186),
(1394, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1386, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1389, 0.236, 1.5, 1, 1.142857, 1, 35186),
(1393, 0.372, 1.5, 1, 1.142857, 0, 35186),
(14757, 0.236, 1.5, 1, 1.142857, 1, 35186),
(1315, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1385, 0.372, 1.5, 1, 1.142857, 0, 35186),
(4384, 0.372, 1.5, 1, 1.142857, 0, 35186),
(5846, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1316, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1388, 0.372, 1.5, 1, 1.142857, 0, 35186),
(4350, 0.236, 1.5, 1, 1.142857, 1, 35186),
(1387, 0.372, 1.5, 1, 1.142857, 0, 35186),
(4362, 0.306, 1.5, 1, 1.142857, 1, 35186),
(4358, 0.306, 1.5, 1, 1.142857, 1, 35186),
(1366, 0.372, 1.5, 1, 1.142857, 0, 35186),
(5770, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1367, 0.236, 1.5, 1, 1.142857, 1, 35186),
(5769, 0.372, 1.5, 1, 1.142857, 0, 35186),
(10589, 0.372, 1.5, 1, 1.142857, 0, 35186),
(14404, 0.347, 1.5, 1, 1.142857, 0, 35186),
(1369, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1368, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1381, 0.236, 1.5, 1, 1.142857, 1, 35186),
(1333, 0.236, 1.5, 1, 1.142857, 1, 35186),
(1332, 0.372, 1.5, 1, 1.142857, 0, 35186),
(5535, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1380, 0.236, 1.5, 1, 1.142857, 1, 35186),
(1379, 0.372, 1.5, 1, 1.142857, 0, 35186),
(14499, 0.236, 1.5, 1, 1.142857, 1, 35186),
(14589, 0.5, 1, 1, 1, 0, 35186),
(14616, 0.5, 1, 1, 1, 1, 35186),
(4386, 0.372, 1.5, 1, 1.142857, 0, 35186),
(10472, 0.306, 1.5, 1, 1.142857, 0, 35186),
(8631, 0.306, 1.5, 1, 1.142857, 0, 35186),
(4359, 0.306, 1.5, 1, 1.142857, 0, 35186),
(15033, 0.2596, 1.65, 1, 1.142857, 1, 35186),
(7135, 0.306, 1.5, 1, 1.142857, 0, 35186),
(7136, 0.306, 1.5, 1, 1.142857, 0, 35186),
(3850, 0.236, 1.5, 1, 1.142857, 1, 35186),
(1374, 0.4092, 1.65, 1, 1.142857, 0, 35186),
(15032, 0.4092, 1.65, 1, 1.142857, 0, 35186),
(15112, 0.4213, 1.65, 1, 1.142857, 1, 35186),
(1375, 0.372, 1.5, 1, 1.142857, 0, 35186),
(15387, 0.372, 1.5, 1, 1.142857, 0, 35186),
(4242, 0.306, 1.5, 1, 1.142857, 0, 35186),
(10696, 0.372, 1.5, 1, 1.142857, 0, 35186),
(10697, 0.372, 1.5, 1, 1.142857, 0, 35186);

INSERT INTO `creature_display_info_addon` (`display_id`, `bounding_radius`, `combat_reach`, `speed_walk`, `speed_run`, `gender`, `sniff_build`) VALUES
(4382, 0.372, 1.5, 1, 1.142857, 0, 35186),
(10695, 0.372, 1.5, 1, 1.142857, 0, 35186),
(9739, 0.372, 1.5, 1, 1.142857, 0, 35186),
(6873, 0.372, 1.5, 1, 1.142857, 0, 35186),
(6843, 0.372, 1.5, 1, 1.142857, 0, 35186),
(6854, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(6005, 0.236, 1.5, 1, 1.142857, 1, 35186),
(1378, 0.236, 1.5, 1, 1.142857, 1, 35186),
(4351, 0.236, 1.5, 1, 1.142857, 1, 35186),
(1377, 0.372, 1.5, 1, 1.142857, 0, 35186),
(14216, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(4239, 0.306, 1.5, 1, 1.142857, 0, 35186),
(4241, 0.306, 1.5, 1, 1.142857, 1, 35186),
(9261, 0.306, 1.5, 1, 1.142857, 0, 35186),
(6064, 0.306, 1.5, 1, 1.142857, 1, 35186),
(1373, 0.372, 1.5, 1, 1.142857, 0, 35186),
(4464, 0.372, 1.5, 1, 1.385714, 0, 35186),
(14575, 0.42, 1.8, 1, 1.385714, 2, 35186),
(2328, 0.42, 1.8, 1, 1.385714, 2, 35186),
(2327, 0.42, 1.8, 1, 1.385714, 2, 35186),
(1384, 0.372, 1.5, 1, 1.142857, 0, 35186),
(14574, 0.42, 1.8, 1, 1.385714, 2, 35186),
(247, 0.42, 1.8, 1, 1.385714, 2, 35186),
(9336, 0.306, 1.5, 1, 1.142857, 0, 35186),
(14573, 0.42, 1.8, 1, 1.385714, 2, 35186),
(7921, 0.306, 1.5, 1, 1.142857, 0, 35186),
(10578, 0.372, 1.5, 1, 1.142857, 0, 35186),
(15731, 0.306, 1.5, 1, 1.142857, 0, 35186),
(1326, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1371, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1372, 0.372, 1.5, 1, 1.142857, 0, 35186),
(4492, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1335, 0.372, 1.5, 1, 1.142857, 0, 35186),
(4545, 0.372, 1.5, 1, 1.142857, 0, 35186),
(4354, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1324, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1325, 0.236, 1.5, 1, 1.142857, 1, 35186),
(15724, 0.236, 1.5, 1, 1.142857, 1, 35186),
(14361, 0.4092, 1.65, 1, 1.142857, 0, 35186),
(14363, 0.2596, 1.65, 1, 1.142857, 1, 35186),
(14360, 0.4092, 1.65, 1, 1.142857, 0, 35186),
(13341, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(4514, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1360, 0.236, 1.5, 1, 1.142857, 1, 35186),
(4231, 0.306, 1.5, 1, 1.142857, 1, 35186),
(1330, 0.372, 1.5, 1, 1.142857, 0, 35186),
(4534, 0.306, 1.5, 1, 1.142857, 0, 35186),
(4355, 0.236, 1.5, 1, 1.142857, 1, 35186),
(14362, 0.2596, 1.65, 1, 1.142857, 1, 35186),
(5410, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3041, 0.347, 1.5, 1, 1.142857, 1, 35186),
(3040, 0.3519, 1.725, 1, 1.142857, 0, 35186),
(2999, 0.347, 1.5, 1, 1.142857, 1, 35186),
(3081, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3107, 0.3519, 1.725, 1, 1.142857, 0, 35186),
(1334, 0.372, 1.5, 1, 1.142857, 0, 35186),
(3042, 0.347, 1.5, 1, 1.142857, 0, 35186),
(1327, 0.372, 1.5, 1, 1.142857, 0, 35186),
(3039, 0.347, 1.5, 1, 1.142857, 1, 35186),
(3043, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3525, 0.347, 1.5, 1, 1.142857, 0, 35186),
(14396, 0.347, 1.5, 1, 1.142857, 0, 35186),
(6588, 0.347, 1.5, 1, 1.142857, 1, 35186),
(3050, 0.347, 1.5, 1, 1.142857, 1, 35186),
(13850, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3038, 0.347, 1.5, 1, 1.142857, 0, 35186),
(9131, 0.3519, 1.725, 1, 1.142857, 1, 35186),
(4361, 0.306, 1.5, 1, 1.142857, 0, 35186),
(15257, 0.306, 1.5, 1, 1.142857, 1, 35186),
(7989, 0.347, 1.5, 1, 1.142857, 1, 35186),
(3037, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3044, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3045, 0.347, 1.5, 1, 1.142857, 0, 35186),
(7990, 0.347, 1.5, 1, 1.142857, 0, 35186),
(1655, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3049, 0.347, 1.5, 1, 1.142857, 1, 35186),
(5190, 0.372, 1.5, 1, 1.142857, 0, 35186),
(15966, 0.372, 1.5, 1, 1.142857, 0, 35186),
(1358, 0.236, 1.5, 1, 1.142857, 1, 35186),
(4360, 0.306, 1.5, 1, 1.142857, 0, 35186),
(8171, 0.347, 1.5, 1, 1.142857, 1, 35186),
(3597, 0.4164, 1.8, 1, 1.142857, 0, 35186),
(4889, 0.306, 1.5, 1, 1.142857, 0, 35186),
(3046, 0.347, 1.5, 1, 1.142857, 0, 35186),
(10186, 0.372, 1.5, 1, 1.142857, 0, 35186),
(14235, 0.347, 1.5, 1, 1.142857, 0, 35186),
(4546, 0.236, 1.5, 1, 1.142857, 1, 35186),
(3047, 0.347, 1.5, 1, 1.142857, 0, 35186),
(3051, 0.347, 1.5, 1, 1.142857, 1, 35186),
(12681, 0.236, 1.5, 1, 1.142857, 1, 35186),
(1392, 0.372, 1.5, 1, 1.142857, 0, 35186),
(2957, 0.35, 0.5, 1, 1.142857, 2, 35186),
(6303, 0.35, 0.5, 1, 1.142857, 2, 35186),
(15653, 0.236, 1.5, 1, 1.142857, 1, 35186),
(15508, 0.306, 1.5, 1, 1.142857, 1, 35186),
(15536, 0.383, 1.5, 1, 1.142857, 0, 35186),
(7631, 0.306, 1.5, 1, 1.142857, 0, 35186),
(15650, 0.372, 1.5, 1, 1.142857, 0, 35186),
(15502, 0.306, 1.5, 1, 1.142857, 0, 35186),
(15535, 0.236, 1.5, 1, 1.142857, 1, 35186),
(15472, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(15661, 0.4092, 1.65, 1, 1.385714, 0, 35186),
(15717, 0.236, 1.5, 1, 1.142857, 1, 35186),
(15720, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(15541, 0.8725, 3.75, 1, 1.142857, 1, 35186),
(15503, 0.383, 1.5, 1, 1.142857, 1, 35186),
(15652, 0.236, 1.5, 1, 1.142857, 1, 35186),
(15537, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(15539, 0.383, 1.5, 1, 1.142857, 1, 35186),
(15460, 0.347, 1.5, 1, 1.385714, 0, 35186),
(15702, 0.306, 1.5, 1, 1.142857, 1, 35186),
(1370, 0.372, 1.5, 1, 1.142857, 0, 35186),
(15461, 0.383, 1.5, 1, 1.142857, 0, 35186),
(15466, 0.306, 1.5, 1, 1.142857, 1, 35186),
(1395, 0.372, 1.5, 1, 1.142857, 0, 35186),
(15543, 0.306, 1.5, 1, 1.142857, 0, 35186),
(15722, 0.383, 1.5, 1, 1.142857, 0, 35186),
(14414, 0.236, 1.5, 1, 1.142857, 1, 35186),
(15462, 0.372, 1.5, 1, 1.142857, 0, 35186),
(15544, 0.9747, 4.05, 1, 1.142857, 0, 35186),
(15542, 0.236, 1.5, 1, 1.142857, 1, 35186);

DELETE FROM `npc_vendor` WHERE (`entry`=2999 AND `item`=18567 AND `extended_cost`=0 AND `type`=1) OR (`entry`=2999 AND `item`=3857 AND `extended_cost`=0 AND `type`=1) OR (`entry`=2999 AND `item`=3466 AND `extended_cost`=0 AND `type`=1) OR (`entry`=2999 AND `item`=2880 AND `extended_cost`=0 AND `type`=1) OR (`entry`=2999 AND `item`=5956 AND `extended_cost`=0 AND `type`=1) OR (`entry`=2999 AND `item`=2901 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=2595 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=2594 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=2596 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=2593 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=2723 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=8952 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=4599 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=3771 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=3770 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=2287 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=117 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=8766 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=1645 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=1708 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=1205 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=1179 AND `extended_cost`=0 AND `type`=1) OR (`entry`=5111 AND `item`=159 AND `extended_cost`=0 AND `type`=1);
INSERT INTO `npc_vendor` (`entry`, `slot`, `item`, `maxcount`, `extended_cost`, `type`, `player_condition_id`, `ignore_filtering`, `sniff_build`) VALUES
(2999, 6, 18567, 0, 0, 1, 0, 0, 35186), -- 18567
(2999, 5, 3857, 0, 0, 1, 0, 0, 35186), -- 3857
(2999, 4, 3466, 0, 0, 1, 0, 0, 35186), -- 3466
(2999, 3, 2880, 0, 0, 1, 0, 0, 35186), -- 2880
(2999, 2, 5956, 0, 0, 1, 0, 0, 35186), -- 5956
(2999, 1, 2901, 0, 0, 1, 0, 0, 35186), -- 2901
(5111, 17, 2595, 0, 0, 1, 0, 0, 35186), -- 2595
(5111, 16, 2594, 0, 0, 1, 0, 0, 35186), -- 2594
(5111, 15, 2596, 0, 0, 1, 0, 0, 35186), -- 2596
(5111, 14, 2593, 0, 0, 1, 0, 0, 35186), -- 2593
(5111, 13, 2723, 0, 0, 1, 0, 0, 35186), -- 2723
(5111, 12, 8952, 0, 0, 1, 0, 0, 35186), -- 8952
(5111, 11, 4599, 0, 0, 1, 0, 0, 35186), -- 4599
(5111, 10, 3771, 0, 0, 1, 0, 0, 35186), -- 3771
(5111, 9, 3770, 0, 0, 1, 0, 0, 35186), -- 3770
(5111, 8, 2287, 0, 0, 1, 0, 0, 35186), -- 2287
(5111, 7, 117, 0, 0, 1, 0, 0, 35186), -- 117
(5111, 6, 8766, 0, 0, 1, 0, 0, 35186), -- 8766
(5111, 5, 1645, 0, 0, 1, 0, 0, 35186), -- 1645
(5111, 4, 1708, 0, 0, 1, 0, 0, 35186), -- 1708
(5111, 3, 1205, 0, 0, 1, 0, 0, 35186), -- 1205
(5111, 2, 1179, 0, 0, 1, 0, 0, 35186), -- 1179
(5111, 1, 159, 0, 0, 1, 0, 0, 35186); -- 159


DELETE FROM `creature_equip_template` WHERE (`id`=1 AND `entry` IN (15533,15535,15460,14376,15534,3373,15469,15459,3349,15458,15528,15512,15532,15700,15477,15522,15508,8404,15525,15515,3370,12799,5112,5111,5910,14183,5110,2784,8879,3401,3342,16012,6446,5107,5106,3402,13843,5109,14363,5103,3327,5102,3334,5130,5100,5101,2790,5816,5892,3330,3403,3344,4047,13417,14304,15765,3325,3324,5815,3335,5875,3351,3350,3326,11046,8659,10088,3362,4752,3352,7294,9988,3407,3406,14182,3355,5812,3356,7230,7793,7792,7790,10266,11176,11178,11177,3408,15350,3354,15006,3890,3353,3413,3412,14942,3410,9317,11017,2857,3357,3358,4485,3332,3333,3347,3348,14365,11066,6986,6987,3404,3405,5811,3366,7088,2855,3363,3315,3367,7010,5126,6114,13084,12197,11865,5115,5114,5113,1901,7976,3369,3368,3400,3399,3328,3216,5121,5120,3323,3189,3331,3329,5119,15453,15451,4949,3310,8401,3057,5188,3322,14377,3312,14375,3018,3314,3320,3318,3309,5614,5611,5610,5613,5609,5606,6929,13842,5603,5597,3319,3028,3029,5817,3313,3011,4721,3024,3014,3013,3023,3022,8398,3021,3020,3019,3017,3012,11071,3027,3026,3025,14392,14720,857,14982,7298,3296,3083,5124,15701,5138,7950,5137,7944,7937,5569,5117,5116,15450,15448,15446,15437,5605,15434,5178,5177,5570,15539,5140,15431,5122,2695,15457,15455,5595,15445,15383,4311,2996,6746,8362,5054,3001,2995,3007,3004,3092,3978,4451,7089,3050,8364,5189,3095,3093,11084,8357,3015,8356,3008,10881,3005,3002,2999,2997,2987,11869,6410,15702,8363,8361,10278,10054,3084,3003,2998));
INSERT INTO `creature_equip_template` (`entry`, `id`, `item_id1`, `item_id2`, `item_id3`, `sniff_build`) VALUES
(15533, 1, 2202, 0, 0, 35186), -- 15533
(15535, 1, 6228, 0, 0, 35186), -- 15535
(15460, 1, 12629, 0, 0, 35186), -- 15460
(14376, 1, 10612, 10612, 0, 35186), -- 14376
(15534, 1, 1117, 0, 0, 35186), -- 15534
(3373, 1, 1907, 0, 0, 35186), -- 3373
(15469, 1, 6680, 0, 0, 35186), -- 15469
(15459, 1, 1910, 0, 0, 35186), -- 15459
(3349, 1, 5304, 0, 0, 35186), -- 3349
(15458, 1, 2557, 0, 0, 35186), -- 15458
(15528, 1, 12937, 0, 0, 35186), -- 15528
(15512, 1, 2198, 12870, 0, 35186), -- 15512
(15532, 1, 12754, 0, 0, 35186), -- 15532
(15700, 1, 18419, 0, 0, 35186), -- 15700
(15477, 1, 21123, 0, 0, 35186), -- 15477
(15522, 1, 11019, 0, 0, 35186), -- 15522
(15508, 1, 0, 2081, 0, 35186), -- 15508
(8404, 1, 1906, 0, 0, 35186), -- 8404
(15525, 1, 21122, 0, 0, 35186), -- 15525
(15515, 1, 5278, 0, 0, 35186), -- 15515
(3370, 1, 5303, 0, 0, 35186), -- 3370
(12799, 1, 10612, 0, 0, 35186), -- 12799
(5112, 1, 2703, 0, 0, 35186), -- 5112
(5111, 1, 2705, 0, 0, 35186), -- 5111
(5910, 1, 12329, 0, 0, 35186), -- 5910
(14183, 1, 0, 0, 15460, 35186), -- 14183
(5110, 1, 2707, 3694, 0, 35186), -- 5110
(2784, 1, 12883, 12883, 0, 35186), -- 2784
(8879, 1, 12742, 0, 0, 35186), -- 8879
(3401, 1, 1900, 5281, 0, 35186), -- 3401
(3342, 1, 12329, 0, 0, 35186), -- 3342
(16012, 1, 14824, 0, 0, 35186), -- 16012
(6446, 1, 2711, 0, 0, 35186), -- 6446
(5107, 1, 0, 2053, 0, 35186), -- 5107
(5106, 1, 0, 1985, 0, 35186), -- 5106
(3402, 1, 10617, 0, 0, 35186), -- 3402
(13843, 1, 12742, 0, 0, 35186), -- 13843
(5109, 1, 2197, 0, 0, 35186), -- 5109
(14363, 1, 11763, 11763, 0, 35186), -- 14363
(5103, 1, 1909, 0, 0, 35186), -- 5103
(3327, 1, 2184, 0, 0, 35186), -- 3327
(5102, 1, 1896, 0, 0, 35186), -- 5102
(3334, 1, 2199, 0, 0, 35186), -- 3334
(5130, 1, 5303, 0, 0, 35186), -- 5130
(5100, 1, 1911, 0, 0, 35186), -- 5100
(5101, 1, 1906, 0, 0, 35186), -- 5101
(2790, 1, 1903, 0, 0, 35186), -- 2790
(5816, 1, 0, 0, 6231, 35186), -- 5816
(5892, 1, 5291, 0, 0, 35186), -- 5892
(3330, 1, 5304, 0, 0, 35186), -- 3330
(3403, 1, 5300, 0, 0, 35186), -- 3403
(3344, 1, 3361, 0, 0, 35186), -- 3344
(4047, 1, 5304, 0, 0, 35186), -- 4047
(13417, 1, 2558, 0, 0, 35186), -- 13417
(14304, 1, 5289, 0, 0, 35186), -- 14304
(15765, 1, 13718, 0, 0, 35186), -- 15765
(3325, 1, 5277, 0, 0, 35186), -- 3325
(3324, 1, 5277, 0, 0, 35186), -- 3324
(5815, 1, 5304, 0, 0, 35186), -- 5815
(3335, 1, 2199, 0, 0, 35186), -- 3335
(5875, 1, 12864, 0, 0, 35186), -- 5875
(3351, 1, 2717, 0, 0, 35186), -- 3351
(3350, 1, 1906, 12745, 0, 35186), -- 3350
(3326, 1, 5277, 0, 0, 35186), -- 3326
(11046, 1, 3699, 3697, 0, 35186), -- 11046
(8659, 1, 2711, 10619, 0, 35186), -- 8659
(10088, 1, 6680, 0, 0, 35186), -- 10088
(3362, 1, 2147, 0, 0, 35186), -- 3362
(4752, 1, 10611, 0, 0, 35186), -- 4752
(3352, 1, 0, 0, 5262, 35186), -- 3352
(7294, 1, 3433, 0, 0, 35186), -- 7294
(9988, 1, 1908, 0, 0, 35186), -- 9988
(3407, 1, 3433, 0, 0, 35186), -- 3407
(3406, 1, 3433, 0, 0, 35186), -- 3406
(14182, 1, 12951, 0, 0, 35186), -- 14182
(3355, 1, 1903, 0, 0, 35186), -- 3355
(5812, 1, 1903, 0, 0, 35186), -- 5812
(3356, 1, 1903, 13611, 0, 35186), -- 3356
(7230, 1, 2182, 0, 0, 35186), -- 7230
(7793, 1, 5491, 0, 0, 35186), -- 7793
(7792, 1, 2182, 0, 0, 35186), -- 7792
(7790, 1, 1903, 0, 0, 35186), -- 7790
(10266, 1, 5532, 0, 0, 35186), -- 10266
(11176, 1, 5532, 0, 0, 35186), -- 11176
(11178, 1, 1903, 0, 0, 35186), -- 11178
(11177, 1, 5491, 0, 0, 35186), -- 11177
(3408, 1, 12348, 0, 0, 35186), -- 3408
(15350, 1, 13706, 0, 0, 35186), -- 15350
(3354, 1, 1983, 0, 0, 35186), -- 3354
(15006, 1, 10616, 0, 0, 35186), -- 15006
(3890, 1, 18419, 0, 0, 35186), -- 3890
(3353, 1, 10612, 10611, 0, 35186), -- 3353
(3413, 1, 1911, 0, 0, 35186), -- 3413
(3412, 1, 4994, 0, 0, 35186), -- 3412
(14942, 1, 19623, 0, 0, 35186), -- 14942
(3410, 1, 0, 0, 5259, 35186), -- 3410
(9317, 1, 1911, 0, 0, 35186), -- 9317
(11017, 1, 1903, 0, 0, 35186), -- 11017
(2857, 1, 1906, 0, 0, 35186), -- 2857
(3357, 1, 1910, 0, 0, 35186), -- 3357
(3358, 1, 2714, 0, 0, 35186), -- 3358
(4485, 1, 2183, 2183, 0, 35186), -- 4485
(3332, 1, 1117, 0, 0, 35186), -- 3332
(3333, 1, 1117, 0, 0, 35186), -- 3333
(3347, 1, 3699, 3697, 0, 35186), -- 3347
(3348, 1, 2198, 0, 0, 35186), -- 3348
(14365, 1, 11763, 11763, 0, 35186), -- 14365
(11066, 1, 0, 12860, 0, 35186), -- 11066
(6986, 1, 1911, 0, 0, 35186), -- 6986
(6987, 1, 1903, 0, 0, 35186), -- 6987
(3404, 1, 6233, 0, 0, 35186), -- 3404
(3405, 1, 3696, 0, 0, 35186), -- 3405
(5811, 1, 2184, 0, 0, 35186), -- 5811
(3366, 1, 3699, 0, 0, 35186), -- 3366
(7088, 1, 5278, 0, 0, 35186), -- 7088
(2855, 1, 0, 12745, 0, 35186), -- 2855
(3363, 1, 1908, 0, 0, 35186), -- 3363
(3315, 1, 1896, 0, 0, 35186), -- 3315
(3367, 1, 2197, 0, 0, 35186), -- 3367
(7010, 1, 5303, 0, 0, 35186), -- 7010
(5126, 1, 0, 11041, 0, 35186), -- 5126
(6114, 1, 1909, 0, 0, 35186), -- 6114
(13084, 1, 5278, 5278, 0, 35186), -- 13084
(12197, 1, 2557, 0, 0, 35186), -- 12197
(11865, 1, 14534, 14533, 0, 35186), -- 11865
(5115, 1, 3433, 0, 0, 35186), -- 5115
(5114, 1, 1897, 2053, 0, 35186), -- 5114
(5113, 1, 5301, 0, 0, 35186), -- 5113
(1901, 1, 5286, 1984, 0, 35186), -- 1901
(7976, 1, 0, 0, 2552, 35186), -- 7976
(3369, 1, 0, 12745, 0, 35186), -- 3369
(3368, 1, 2827, 2196, 0, 35186), -- 3368
(3400, 1, 3351, 4993, 0, 35186), -- 3400
(3399, 1, 2827, 0, 0, 35186), -- 3399
(3328, 1, 5278, 0, 0, 35186), -- 3328
(3216, 1, 2559, 0, 0, 35186), -- 3216
(5121, 1, 2809, 0, 0, 35186), -- 5121
(5120, 1, 1899, 0, 0, 35186), -- 5120
(3323, 1, 2200, 0, 0, 35186), -- 3323
(3189, 1, 2023, 0, 0, 35186), -- 3189
(3331, 1, 2178, 0, 0, 35186), -- 3331
(3329, 1, 3346, 0, 0, 35186), -- 3329
(5119, 1, 5286, 0, 0, 35186), -- 5119
(15453, 1, 1907, 0, 0, 35186), -- 15453
(15451, 1, 5598, 0, 0, 35186), -- 15451
(4949, 1, 12183, 0, 0, 35186), -- 4949
(3310, 1, 3433, 0, 0, 35186), -- 3310
(8401, 1, 12329, 0, 0, 35186), -- 8401
(3057, 1, 14084, 0, 0, 35186), -- 3057
(5188, 1, 5284, 0, 0, 35186), -- 5188
(3322, 1, 0, 0, 2552, 35186), -- 3322
(14377, 1, 10612, 10612, 0, 35186), -- 14377
(3312, 1, 2827, 2196, 2551, 35186), -- 3312
(14375, 1, 10612, 10612, 0, 35186), -- 14375
(3018, 1, 0, 0, 2552, 35186), -- 3018
(3314, 1, 10611, 0, 0, 35186), -- 3314
(3320, 1, 12850, 12745, 0, 35186), -- 3320
(3318, 1, 12856, 12859, 0, 35186), -- 3318
(3309, 1, 12852, 12855, 0, 35186), -- 3309
(5614, 1, 2716, 0, 0, 35186), -- 5614
(5611, 1, 0, 0, 2551, 35186), -- 5611
(5610, 1, 2703, 0, 0, 35186), -- 5610
(5613, 1, 2703, 0, 0, 35186), -- 5613
(5609, 1, 2703, 0, 0, 35186), -- 5609
(5606, 1, 2703, 0, 0, 35186), -- 5606
(6929, 1, 6334, 0, 0, 35186), -- 6929
(13842, 1, 13339, 0, 0, 35186), -- 13842
(5603, 1, 5287, 0, 0, 35186), -- 5603
(5597, 1, 5287, 0, 0, 35186), -- 5597
(3319, 1, 0, 1985, 0, 35186), -- 3319
(3028, 1, 6229, 0, 0, 35186), -- 3028
(3029, 1, 1117, 0, 0, 35186), -- 3029
(5817, 1, 1910, 2081, 0, 35186), -- 5817
(3313, 1, 1906, 12745, 0, 35186), -- 3313
(3011, 1, 13061, 0, 0, 35186), -- 3011
(4721, 1, 13337, 0, 0, 35186), -- 4721
(3024, 1, 12801, 0, 0, 35186), -- 3024
(3014, 1, 6233, 0, 0, 35186), -- 3014
(3013, 1, 1907, 0, 0, 35186), -- 3013
(3023, 1, 1907, 0, 0, 35186), -- 3023
(3022, 1, 5277, 0, 0, 35186), -- 3022
(8398, 1, 12889, 0, 0, 35186), -- 8398
(3021, 1, 10878, 0, 0, 35186), -- 3021
(3020, 1, 9659, 0, 0, 35186), -- 3020
(3019, 1, 10611, 0, 0, 35186), -- 3019
(3017, 1, 2184, 0, 0, 35186), -- 3017
(3012, 1, 1906, 0, 0, 35186), -- 3012
(11071, 1, 12742, 0, 0, 35186), -- 11071
(3027, 1, 5278, 2081, 0, 35186), -- 3027
(3026, 1, 2196, 0, 0, 35186), -- 3026
(3025, 1, 2196, 0, 0, 35186), -- 3025
(14392, 1, 18419, 0, 0, 35186), -- 14392
(14720, 1, 21580, 0, 0, 35186), -- 14720
(857, 1, 2176, 0, 0, 35186), -- 857
(14982, 1, 5598, 0, 0, 35186), -- 14982
(7298, 1, 6680, 0, 0, 35186), -- 7298
(3296, 1, 5289, 0, 0, 35186), -- 3296
(3083, 1, 5288, 0, 0, 35186), -- 3083
(5124, 1, 2196, 0, 0, 35186), -- 5124
(15701, 1, 21286, 0, 0, 35186), -- 15701
(5138, 1, 2707, 0, 0, 35186), -- 5138
(7950, 1, 1903, 0, 0, 35186), -- 7950
(5137, 1, 1908, 0, 0, 35186), -- 5137
(7944, 1, 1903, 0, 0, 35186), -- 7944
(7937, 1, 1911, 11587, 0, 35186), -- 7937
(5569, 1, 4994, 0, 0, 35186), -- 5569
(5117, 1, 0, 0, 2552, 35186), -- 5117
(5116, 1, 0, 0, 2552, 35186), -- 5116
(15450, 1, 5284, 0, 0, 35186), -- 15450
(15448, 1, 12890, 0, 0, 35186), -- 15448
(15446, 1, 2184, 0, 0, 35186), -- 15446
(15437, 1, 21121, 0, 0, 35186), -- 15437
(5605, 1, 2147, 1984, 0, 35186), -- 5605
(15434, 1, 1896, 0, 0, 35186), -- 15434
(5178, 1, 2200, 3695, 0, 35186), -- 5178
(5177, 1, 2716, 3695, 0, 35186), -- 5177
(5570, 1, 3361, 0, 0, 35186), -- 5570
(15539, 1, 17383, 0, 0, 35186), -- 15539
(5140, 1, 2703, 0, 0, 35186), -- 5140
(15431, 1, 1899, 0, 0, 35186), -- 15431
(5122, 1, 0, 0, 5262, 35186), -- 5122
(2695, 1, 2714, 0, 0, 35186), -- 2695
(15457, 1, 0, 0, 5258, 35186), -- 15457
(15455, 1, 6228, 0, 0, 35186), -- 15455
(5595, 1, 5286, 6254, 0, 35186), -- 5595
(15445, 1, 1899, 0, 0, 35186), -- 15445
(15383, 1, 17942, 0, 0, 35186), -- 15383
(4311, 1, 5288, 0, 0, 35186), -- 4311
(2996, 1, 12854, 0, 0, 35186), -- 2996
(6746, 1, 3362, 0, 0, 35186), -- 6746
(8362, 1, 2197, 0, 0, 35186), -- 8362
(5054, 1, 5301, 0, 0, 35186), -- 5054
(3001, 1, 1910, 0, 0, 35186), -- 3001
(2995, 1, 6680, 0, 0, 35186), -- 2995
(3007, 1, 2711, 0, 0, 35186), -- 3007
(3004, 1, 12329, 0, 0, 35186), -- 3004
(3092, 1, 12629, 0, 0, 35186), -- 3092
(3978, 1, 2558, 0, 0, 35186), -- 3978
(4451, 1, 1908, 0, 0, 35186), -- 4451
(7089, 1, 5278, 0, 0, 35186), -- 7089
(3050, 1, 5301, 0, 0, 35186), -- 3050
(8364, 1, 12744, 12745, 0, 35186), -- 8364
(5189, 1, 10611, 0, 0, 35186), -- 5189
(3095, 1, 12297, 0, 0, 35186), -- 3095
(3093, 1, 5291, 0, 0, 35186), -- 3093
(11084, 1, 12290, 0, 0, 35186), -- 11084
(8357, 1, 12856, 0, 0, 35186), -- 8357
(3015, 1, 0, 0, 5259, 35186), -- 3015
(8356, 1, 12744, 0, 0, 35186), -- 8356
(3008, 1, 10616, 0, 0, 35186); -- 3008

INSERT INTO `creature_equip_template` (`entry`, `id`, `item_id1`, `item_id2`, `item_id3`, `sniff_build`) VALUES
(10881, 1, 1906, 0, 0, 35186), -- 10881
(3005, 1, 5281, 0, 0, 35186), -- 3005
(3002, 1, 1910, 0, 0, 35186), -- 3002
(2999, 1, 5532, 0, 0, 35186), -- 2999
(2997, 1, 5292, 0, 0, 35186), -- 2997
(2987, 1, 2023, 0, 0, 35186), -- 2987
(11869, 1, 14527, 0, 0, 35186), -- 11869
(6410, 1, 1903, 0, 0, 35186), -- 6410
(15702, 1, 5280, 0, 0, 35186), -- 15702
(8363, 1, 1903, 0, 0, 35186), -- 8363
(8361, 1, 2716, 0, 0, 35186), -- 8361
(10278, 1, 1903, 0, 0, 35186), -- 10278
(10054, 1, 12328, 0, 0, 35186), -- 10054
(3084, 1, 12754, 0, 0, 35186), -- 3084
(3003, 1, 2197, 0, 0, 35186), -- 3003
(2998, 1, 1903, 0, 0, 35186); -- 2998


DELETE FROM `creature_gossip` WHERE (`entry`=2995 AND `gossip_menu_id`=4326 AND `is_default`=1) OR (`entry`=15767 AND `gossip_menu_id`=6809 AND `is_default`=1) OR (`entry`=15702 AND `gossip_menu_id`=6790 AND `is_default`=1) OR (`entry`=5111 AND `gossip_menu_id`=345 AND `is_default`=1) OR (`entry`=15701 AND `gossip_menu_id`=6772 AND `is_default`=1) OR (`entry`=15701 AND `gossip_menu_id`=6771 AND `is_default`=0) OR (`entry`=15734 AND `gossip_menu_id`=6805 AND `is_default`=1) OR (`entry`=15431 AND `gossip_menu_id`=6702 AND `is_default`=0) OR (`entry`=15431 AND `gossip_menu_id`=6602 AND `is_default`=1) OR (`entry`=15451 AND `gossip_menu_id`=6610 AND `is_default`=1) OR (`entry`=15453 AND `gossip_menu_id`=6613 AND `is_default`=1) OR (`entry`=15453 AND `gossip_menu_id`=6720 AND `is_default`=0) OR (`entry`=15452 AND `gossip_menu_id`=6612 AND `is_default`=1) OR (`entry`=15452 AND `gossip_menu_id`=6718 AND `is_default`=0) OR (`entry`=15451 AND `gossip_menu_id`=6716 AND `is_default`=0) OR (`entry`=15446 AND `gossip_menu_id`=6607 AND `is_default`=1) OR (`entry`=15446 AND `gossip_menu_id`=6696 AND `is_default`=0) OR (`entry`=15448 AND `gossip_menu_id`=6608 AND `is_default`=1) OR (`entry`=15448 AND `gossip_menu_id`=6712 AND `is_default`=0) OR (`entry`=15450 AND `gossip_menu_id`=6609 AND `is_default`=1) OR (`entry`=15450 AND `gossip_menu_id`=6714 AND `is_default`=0) OR (`entry`=15735 AND `gossip_menu_id`=6806 AND `is_default`=1) OR (`entry`=15432 AND `gossip_menu_id`=6603 AND `is_default`=1) OR (`entry`=15432 AND `gossip_menu_id`=6704 AND `is_default`=0) OR (`entry`=15539 AND `gossip_menu_id`=6665 AND `is_default`=1) OR (`entry`=15539 AND `gossip_menu_id`=6671 AND `is_default`=0) OR (`entry`=15731 AND `gossip_menu_id`=6803 AND `is_default`=1) OR (`entry`=15383 AND `gossip_menu_id`=6599 AND `is_default`=1) OR (`entry`=15383 AND `gossip_menu_id`=6700 AND `is_default`=0) OR (`entry`=15434 AND `gossip_menu_id`=6604 AND `is_default`=1) OR (`entry`=15434 AND `gossip_menu_id`=6706 AND `is_default`=0) OR (`entry`=15445 AND `gossip_menu_id`=6606 AND `is_default`=1) OR (`entry`=15445 AND `gossip_menu_id`=6710 AND `is_default`=0) OR (`entry`=15437 AND `gossip_menu_id`=6605 AND `is_default`=1) OR (`entry`=15437 AND `gossip_menu_id`=6708 AND `is_default`=0) OR (`entry`=15457 AND `gossip_menu_id`=6726 AND `is_default`=0) OR (`entry`=15457 AND `gossip_menu_id`=6616 AND `is_default`=1) OR (`entry`=15456 AND `gossip_menu_id`=6615 AND `is_default`=1) OR (`entry`=15456 AND `gossip_menu_id`=6724 AND `is_default`=0) OR (`entry`=15455 AND `gossip_menu_id`=6614 AND `is_default`=1) OR (`entry`=15455 AND `gossip_menu_id`=6722 AND `is_default`=0) OR (`entry`=15534 AND `gossip_menu_id`=6663 AND `is_default`=1) OR (`entry`=15700 AND `gossip_menu_id`=6778 AND `is_default`=1) OR (`entry`=15737 AND `gossip_menu_id`=6807 AND `is_default`=1) OR (`entry`=15535 AND `gossip_menu_id`=6758 AND `is_default`=0) OR (`entry`=15535 AND `gossip_menu_id`=6664 AND `is_default`=1) OR (`entry`=15534 AND `gossip_menu_id`=6756 AND `is_default`=0) OR (`entry`=3296 AND `gossip_menu_id`=1951 AND `is_default`=1) OR (`entry`=15738 AND `gossip_menu_id`=6810 AND `is_default`=1) OR (`entry`=15460 AND `gossip_menu_id`=6619 AND `is_default`=1) OR (`entry`=15469 AND `gossip_menu_id`=6624 AND `is_default`=1) OR (`entry`=15459 AND `gossip_menu_id`=6729 AND `is_default`=0) OR (`entry`=15459 AND `gossip_menu_id`=6618 AND `is_default`=1) OR (`entry`=15458 AND `gossip_menu_id`=6678 AND `is_default`=1) OR (`entry`=15739 AND `gossip_menu_id`=6809 AND `is_default`=1) OR (`entry`=15477 AND `gossip_menu_id`=6625 AND `is_default`=1) OR (`entry`=15508 AND `gossip_menu_id`=6651 AND `is_default`=1) OR (`entry`=15512 AND `gossip_menu_id`=6740 AND `is_default`=0) OR (`entry`=15512 AND `gossip_menu_id`=6653 AND `is_default`=1) OR (`entry`=15458 AND `gossip_menu_id`=6759 AND `is_default`=0) OR (`entry`=15736 AND `gossip_menu_id`=6808 AND `is_default`=1) OR (`entry`=15528 AND `gossip_menu_id`=6748 AND `is_default`=0) OR (`entry`=15528 AND `gossip_menu_id`=6659 AND `is_default`=1) OR (`entry`=15529 AND `gossip_menu_id`=6660 AND `is_default`=1) OR (`entry`=15529 AND `gossip_menu_id`=6750 AND `is_default`=0) OR (`entry`=15532 AND `gossip_menu_id`=6661 AND `is_default`=1) OR (`entry`=15532 AND `gossip_menu_id`=6752 AND `is_default`=0) OR (`entry`=15700 AND `gossip_menu_id`=6779 AND `is_default`=0) OR (`entry`=15522 AND `gossip_menu_id`=6656 AND `is_default`=1) OR (`entry`=15522 AND `gossip_menu_id`=6744 AND `is_default`=0) OR (`entry`=15525 AND `gossip_menu_id`=6657 AND `is_default`=1) OR (`entry`=15515 AND `gossip_menu_id`=6742 AND `is_default`=0) OR (`entry`=15515 AND `gossip_menu_id`=6654 AND `is_default`=1) OR (`entry`=14720 AND `gossip_menu_id`=6024 AND `is_default`=1);
INSERT INTO `creature_gossip` (`entry`, `gossip_menu_id`, `is_default`, `sniff_build`) VALUES
(2995, 4326, 1, 35186), -- 2995
(15767, 6809, 1, 35186), -- 15767
(15702, 6790, 1, 35186), -- 15702
(5111, 345, 1, 35186), -- 5111
(15701, 6772, 1, 35186), -- 15701
(15701, 6771, 0, 35186), -- 15701
(15734, 6805, 1, 35186), -- 15734
(15431, 6702, 0, 35186), -- 15431
(15431, 6602, 1, 35186), -- 15431
(15451, 6610, 1, 35186), -- 15451
(15453, 6613, 1, 35186), -- 15453
(15453, 6720, 0, 35186), -- 15453
(15452, 6612, 1, 35186), -- 15452
(15452, 6718, 0, 35186), -- 15452
(15451, 6716, 0, 35186), -- 15451
(15446, 6607, 1, 35186), -- 15446
(15446, 6696, 0, 35186), -- 15446
(15448, 6608, 1, 35186), -- 15448
(15448, 6712, 0, 35186), -- 15448
(15450, 6609, 1, 35186), -- 15450
(15450, 6714, 0, 35186), -- 15450
(15735, 6806, 1, 35186), -- 15735
(15432, 6603, 1, 35186), -- 15432
(15432, 6704, 0, 35186), -- 15432
(15539, 6665, 1, 35186), -- 15539
(15539, 6671, 0, 35186), -- 15539
(15731, 6803, 1, 35186), -- 15731
(15383, 6599, 1, 35186), -- 15383
(15383, 6700, 0, 35186), -- 15383
(15434, 6604, 1, 35186), -- 15434
(15434, 6706, 0, 35186), -- 15434
(15445, 6606, 1, 35186), -- 15445
(15445, 6710, 0, 35186), -- 15445
(15437, 6605, 1, 35186), -- 15437
(15437, 6708, 0, 35186), -- 15437
(15457, 6726, 0, 35186), -- 15457
(15457, 6616, 1, 35186), -- 15457
(15456, 6615, 1, 35186), -- 15456
(15456, 6724, 0, 35186), -- 15456
(15455, 6614, 1, 35186), -- 15455
(15455, 6722, 0, 35186), -- 15455
(15534, 6663, 1, 35186), -- 15534
(15700, 6778, 1, 35186), -- 15700
(15737, 6807, 1, 35186), -- 15737
(15535, 6758, 0, 35186), -- 15535
(15535, 6664, 1, 35186), -- 15535
(15534, 6756, 0, 35186), -- 15534
(3296, 1951, 1, 35186), -- 3296
(15738, 6810, 1, 35186), -- 15738
(15460, 6619, 1, 35186), -- 15460
(15469, 6624, 1, 35186), -- 15469
(15459, 6729, 0, 35186), -- 15459
(15459, 6618, 1, 35186), -- 15459
(15458, 6678, 1, 35186), -- 15458
(15739, 6809, 1, 35186), -- 15739
(15477, 6625, 1, 35186), -- 15477
(15508, 6651, 1, 35186), -- 15508
(15512, 6740, 0, 35186), -- 15512
(15512, 6653, 1, 35186), -- 15512
(15458, 6759, 0, 35186), -- 15458
(15736, 6808, 1, 35186), -- 15736
(15528, 6748, 0, 35186), -- 15528
(15528, 6659, 1, 35186), -- 15528
(15529, 6660, 1, 35186), -- 15529
(15529, 6750, 0, 35186), -- 15529
(15532, 6661, 1, 35186), -- 15532
(15532, 6752, 0, 35186), -- 15532
(15700, 6779, 0, 35186), -- 15700
(15522, 6656, 1, 35186), -- 15522
(15522, 6744, 0, 35186), -- 15522
(15525, 6657, 1, 35186), -- 15525
(15515, 6742, 0, 35186), -- 15515
(15515, 6654, 1, 35186), -- 15515
(14720, 6024, 1, 35186); -- 14720

DELETE FROM `gossip_menu` WHERE (`text_id`=5500 AND `entry`=4326) OR (`text_id`=8132 AND `entry`=6809) OR (`text_id`=8107 AND `entry`=6790) OR (`text_id`=823 AND `entry`=345) OR (`text_id`=8084 AND `entry`=6772) OR (`text_id`=8071 AND `entry` IN (6771,6759)) OR (`text_id`=8129 AND `entry`=6805) OR (`text_id`=8072 AND `entry` IN (6702,6720,6712,6700,6706,6708,6722)) OR (`text_id`=7960 AND `entry`=6602) OR (`text_id`=7988 AND `entry`=6610) OR (`text_id`=7994 AND `entry`=6613) OR (`text_id`=7991 AND `entry`=6612) OR (`text_id`=8070 AND `entry` IN (6718,6716,6696,6714,6704,6710,6726,6724)) OR (`text_id`=7971 AND `entry`=6607) OR (`text_id`=7981 AND `entry`=6608) OR (`text_id`=7984 AND `entry`=6609) OR (`text_id`=8130 AND `entry`=6806) OR (`text_id`=7962 AND `entry`=6603) OR (`text_id`=8006 AND `entry`=6665) OR (`text_id`=8209 AND `entry` IN (6671,6779)) OR (`text_id`=8126 AND `entry`=6803) OR (`text_id`=7958 AND `entry`=6599) OR (`text_id`=7964 AND `entry`=6604) OR (`text_id`=7969 AND `entry`=6606) OR (`text_id`=7967 AND `entry`=6605) OR (`text_id`=8003 AND `entry`=6616) OR (`text_id`=8000 AND `entry`=6615) OR (`text_id`=7997 AND `entry`=6614) OR (`text_id`=8049 AND `entry`=6663) OR (`text_id`=8094 AND `entry`=6778) OR (`text_id`=8127 AND `entry`=6807) OR (`text_id`=8073 AND `entry` IN (6758,6756,6729,6748)) OR (`text_id`=8052 AND `entry`=6664) OR (`text_id`=2593 AND `entry`=1951) OR (`text_id`=8133 AND `entry`=6810) OR (`text_id`=8013 AND `entry`=6619) OR (`text_id`=8016 AND `entry`=6624) OR (`text_id`=8010 AND `entry`=6618) OR (`text_id`=8055 AND `entry`=6678) OR (`text_id`=8019 AND `entry`=6625) OR (`text_id`=8022 AND `entry`=6651) OR (`text_id`=8074 AND `entry` IN (6740,6750,6752,6744,6742)) OR (`text_id`=8025 AND `entry`=6653) OR (`text_id`=8131 AND `entry`=6808) OR (`text_id`=8037 AND `entry`=6659) OR (`text_id`=8040 AND `entry`=6660) OR (`text_id`=8043 AND `entry`=6661) OR (`text_id`=8031 AND `entry`=6656) OR (`text_id`=8034 AND `entry`=6657) OR (`text_id`=8028 AND `entry`=6654) OR (`text_id`=7176 AND `entry`=6024);
INSERT INTO `gossip_menu` (`entry`, `text_id`, `sniff_build`) VALUES
(4326, 5500, 35186), -- 2995
(6809, 8132, 35186), -- 15767
(6790, 8107, 35186), -- 15702
(345, 823, 35186), -- 5111
(6772, 8084, 35186), -- 15701
(6771, 8071, 35186), -- 15701
(6805, 8129, 35186), -- 15734
(6702, 8072, 35186), -- 15431
(6602, 7960, 35186), -- 15431
(6610, 7988, 35186), -- 15451
(6613, 7994, 35186), -- 15453
(6720, 8072, 35186), -- 15453
(6612, 7991, 35186), -- 15452
(6718, 8070, 35186), -- 15452
(6716, 8070, 35186), -- 15451
(6607, 7971, 35186), -- 15446
(6696, 8070, 35186), -- 15446
(6608, 7981, 35186), -- 15448
(6712, 8072, 35186), -- 15448
(6609, 7984, 35186), -- 15450
(6714, 8070, 35186), -- 15450
(6806, 8130, 35186), -- 15735
(6603, 7962, 35186), -- 15432
(6704, 8070, 35186), -- 15432
(6665, 8006, 35186), -- 15539
(6671, 8209, 35186), -- 15539
(6803, 8126, 35186), -- 15731
(6599, 7958, 35186), -- 15383
(6700, 8072, 35186), -- 15383
(6604, 7964, 35186), -- 15434
(6706, 8072, 35186), -- 15434
(6606, 7969, 35186), -- 15445
(6710, 8070, 35186), -- 15445
(6605, 7967, 35186), -- 15437
(6708, 8072, 35186), -- 15437
(6726, 8070, 35186), -- 15457
(6616, 8003, 35186), -- 15457
(6615, 8000, 35186), -- 15456
(6724, 8070, 35186), -- 15456
(6614, 7997, 35186), -- 15455
(6722, 8072, 35186), -- 15455
(6663, 8049, 35186), -- 15534
(6778, 8094, 35186), -- 15700
(6807, 8127, 35186), -- 15737
(6758, 8073, 35186), -- 15535
(6664, 8052, 35186), -- 15535
(6756, 8073, 35186), -- 15534
(1951, 2593, 35186), -- 3296
(6810, 8133, 35186), -- 15738
(6619, 8013, 35186), -- 15460
(6624, 8016, 35186), -- 15469
(6729, 8073, 35186), -- 15459
(6618, 8010, 35186), -- 15459
(6678, 8055, 35186), -- 15458
(6625, 8019, 35186), -- 15477
(6651, 8022, 35186), -- 15508
(6740, 8074, 35186), -- 15512
(6653, 8025, 35186), -- 15512
(6759, 8071, 35186), -- 15458
(6808, 8131, 35186), -- 15736
(6748, 8073, 35186), -- 15528
(6659, 8037, 35186), -- 15528
(6660, 8040, 35186), -- 15529
(6750, 8074, 35186), -- 15529
(6661, 8043, 35186), -- 15532
(6752, 8074, 35186), -- 15532
(6779, 8209, 35186), -- 15700
(6656, 8031, 35186), -- 15522
(6744, 8074, 35186), -- 15522
(6657, 8034, 35186), -- 15525
(6742, 8074, 35186), -- 15515
(6654, 8028, 35186), -- 15515
(6024, 7176, 35186); -- 14720

DELETE FROM `gossip_menu_option` WHERE (`id`=0 AND `menu_id` IN (4326,6772,6771,6702,6602,6610,6613,6720,6612,6718,6716,6607,6696,6608,6712,6609,6714,6603,6704,6665,6671,6599,6700,6604,6706,6606,6710,6605,6708,6726,6616,6615,6724,6614,6722,6663,6778,6758,6664,6756,1951,6619,6624,6729,6618,6678,6625,6651,6740,6653,6759,6748,6659,6660,6750,6661,6752,6779,6656,6744,6657,6742,6654)) OR (`id`=5 AND `menu_id` IN (345,1951)) OR (`id`=3 AND `menu_id` IN (345,1951)) OR (`id`=2 AND `menu_id` IN (345,1951)) OR (`id`=12 AND `menu_id`=1951) OR (`id`=11 AND `menu_id`=1951) OR (`id`=10 AND `menu_id`=1951) OR (`id`=9 AND `menu_id`=1951) OR (`id`=8 AND `menu_id`=1951) OR (`id`=7 AND `menu_id`=1951) OR (`id`=6 AND `menu_id`=1951) OR (`id`=4 AND `menu_id`=1951) OR (`id`=1 AND `menu_id`=1951);
INSERT INTO `gossip_menu_option` (`menu_id`, `id`, `option_icon`, `option_text`, `option_broadcast_text`, `option_id`, `npc_option_npcflag`, `sniff_build`) VALUES
(4326, 0, 2, 'I need a ride.', 0, 4, 8, 35186),
(345, 5, 0, 'Tell me about dungeons I could explore.', 0, 1, 1, 35186),
(345, 3, 1, 'Let me browse your goods.', 0, 3, 4, 35186),
(345, 2, 5, 'Make this inn your home.', 0, 8, 128, 35186),
(6772, 0, 0, 'What is the Ahn\'Qiraj war effort?', 0, 1, 1, 35186),
(6771, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6702, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6602, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6610, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6613, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6720, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6612, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6718, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6716, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6607, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6696, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6608, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6712, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6609, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6714, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6603, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6704, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6665, 0, 0, 'What is the Ahn\'Qiraj war effort?', 0, 1, 1, 35186),
(6671, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6599, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6700, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6604, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6706, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6606, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6710, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6605, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6708, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6726, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6616, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6615, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6724, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6614, 0, 0, 'What is an Alliance Commendation Signet?', 0, 1, 1, 35186),
(6722, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6663, 0, 0, 'What is a Horde Commendation Signet?', 0, 1, 1, 35186),
(6778, 0, 0, 'What is the Ahn\'Qiraj war effort?', 0, 1, 1, 35186),
(6758, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6664, 0, 0, 'What is a Horde Commendation Signet?', 0, 1, 1, 35186),
(6756, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(1951, 12, 0, 'A profession trainer', 0, 1, 1, 35186),
(1951, 11, 0, 'A class trainer', 0, 1, 1, 35186),
(1951, 10, 0, 'The battlemaster', 0, 1, 1, 35186),
(1951, 9, 0, 'The officers\' lounge', 0, 1, 1, 35186),
(1951, 8, 0, 'The stable master', 0, 1, 1, 35186),
(1951, 7, 0, 'The weapon master', 0, 1, 1, 35186),
(1951, 6, 0, 'The zeppelin master', 0, 1, 1, 35186),
(1951, 5, 0, 'The auction house', 0, 1, 1, 35186),
(1951, 4, 0, 'The mailbox', 0, 1, 1, 35186),
(1951, 3, 0, 'The inn', 0, 1, 1, 35186),
(1951, 2, 0, 'The guild master', 0, 1, 1, 35186),
(1951, 1, 0, 'The wind rider master', 0, 1, 1, 35186),
(1951, 0, 0, 'The bank', 0, 1, 1, 35186),
(6619, 0, 0, 'What is a Horde Commendation Signet?', 0, 1, 1, 35186),
(6624, 0, 0, 'What is a Horde Commendation Signet?', 0, 1, 1, 35186),
(6729, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6618, 0, 0, 'What is a Horde Commendation Signet?', 0, 1, 1, 35186),
(6678, 0, 0, 'What is the Ahn\'Qiraj war effort?', 0, 1, 1, 35186),
(6625, 0, 0, 'What is a Horde Commendation Signet?', 0, 1, 1, 35186),
(6651, 0, 0, 'What is a Horde Commendation Signet?', 0, 1, 1, 35186),
(6740, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6653, 0, 0, 'What is a Horde Commendation Signet?', 0, 1, 1, 35186),
(6759, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6748, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6659, 0, 0, 'What is a Horde Commendation Signet?', 0, 1, 1, 35186),
(6660, 0, 0, 'What is a Horde Commendation Signet?', 0, 1, 1, 35186),
(6750, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6661, 0, 0, 'What is a Horde Commendation Signet?', 0, 1, 1, 35186),
(6752, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6779, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6656, 0, 0, 'What is a Horde Commendation Signet?', 0, 1, 1, 35186),
(6744, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6657, 0, 0, 'What is a Horde Commendation Signet?', 0, 1, 1, 35186),
(6742, 0, 0, 'I want to ask you about something else.', 0, 1, 1, 35186),
(6654, 0, 0, 'What is a Horde Commendation Signet?', 0, 1, 1, 35186);

UPDATE `gossip_menu_option` SET `action_menu_id`=6772, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6771 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6771, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6772 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6702, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6602 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6613, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6720 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6720, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6613 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6612, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6718 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6718, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6612 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6612, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6718 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6718, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6612 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6610, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6716 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6716, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6610 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6607, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6696 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6696, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6607 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6608, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6712 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6712, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6608 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6609, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6714 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6714, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6609 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6603, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6704 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6704, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6603 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6665, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6671 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6671, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6665 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6603, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6704 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6704, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6603 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6599, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6700 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6700, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6599 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6602, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6702 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6702, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6602 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6604, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6706 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6706, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6604 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6606, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6710 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6710, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6606 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6605, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6708 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6708, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6605 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6726, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6616 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6616, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6726 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6726, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6616 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6615, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6724 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6724, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6615 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6614, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6722 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6722, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6614 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6758, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6664 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6756, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6663 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6729, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6618 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6740, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6653 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6759, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6678 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6748, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6659 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6660, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6750 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6750, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6660 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6661, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6752 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6752, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6661 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6779, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6778 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6778, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6779 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6779, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6778 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6656, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6744 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6744, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6656 && `id`=0;
UPDATE `gossip_menu_option` SET `action_menu_id`=6742, `action_poi_id`=0, `option_id`=1, `npc_option_npcflag`=1 WHERE `menu_id`=6654 && `id`=0;

DELETE FROM `gossip_menu_option_action` WHERE (`id`=0 AND `menu_id` IN (6771,6772,6602,6720,6613,6718,6612,6716,6610,6696,6607,6712,6608,6714,6609,6704,6603,6671,6665,6700,6599,6702,6706,6604,6710,6606,6708,6605,6616,6726,6724,6615,6722,6614,6664,6663,6618,6653,6678,6659,6750,6660,6752,6661,6778,6779,6744,6656,6654));
INSERT INTO `gossip_menu_option_action` (`menu_id`, `id`, `action_menu_id`, `action_poi_id`) VALUES
(6771, 0, 6772, 0),
(6772, 0, 6771, 0),
(6602, 0, 6702, 0),
(6720, 0, 6613, 0),
(6613, 0, 6720, 0),
(6718, 0, 6612, 0),
(6612, 0, 6718, 0),
(6716, 0, 6610, 0),
(6610, 0, 6716, 0),
(6696, 0, 6607, 0),
(6607, 0, 6696, 0),
(6712, 0, 6608, 0),
(6608, 0, 6712, 0),
(6714, 0, 6609, 0),
(6609, 0, 6714, 0),
(6704, 0, 6603, 0),
(6603, 0, 6704, 0),
(6671, 0, 6665, 0),
(6665, 0, 6671, 0),
(6700, 0, 6599, 0),
(6599, 0, 6700, 0),
(6702, 0, 6602, 0),
(6706, 0, 6604, 0),
(6604, 0, 6706, 0),
(6710, 0, 6606, 0),
(6606, 0, 6710, 0),
(6708, 0, 6605, 0),
(6605, 0, 6708, 0),
(6616, 0, 6726, 0),
(6726, 0, 6616, 0),
(6724, 0, 6615, 0),
(6615, 0, 6724, 0),
(6722, 0, 6614, 0),
(6614, 0, 6722, 0),
(6664, 0, 6758, 0),
(6663, 0, 6756, 0),
(6618, 0, 6729, 0),
(6653, 0, 6740, 0),
(6678, 0, 6759, 0),
(6659, 0, 6748, 0),
(6750, 0, 6660, 0),
(6660, 0, 6750, 0),
(6752, 0, 6661, 0),
(6661, 0, 6752, 0),
(6778, 0, 6779, 0),
(6779, 0, 6778, 0),
(6744, 0, 6656, 0),
(6656, 0, 6744, 0),
(6654, 0, 6742, 0);


DELETE FROM `creature_template` WHERE `entry` IN (15533 /*15533*/, 15535 /*15535*/, 15460 /*15460*/, 14376 /*14376*/, 15738 /*15738*/, 15534 /*15534*/, 3373 /*3373*/, 15469 /*15469*/, 15459 /*15459*/, 3349 /*3349*/, 15737 /*15737*/, 15458 /*15458*/, 15529 /*15529*/, 15528 /*15528*/, 15512 /*15512*/, 15532 /*15532*/, 15739 /*15739*/, 15736 /*15736*/, 15700 /*15700*/, 15477 /*15477*/, 15522 /*15522*/, 15508 /*15508*/, 8404 /*8404*/, 15525 /*15525*/, 15515 /*15515*/, 15696 /*15696*/, 7567 /*7567*/, 7562 /*7562*/, 3370 /*3370*/, 12799 /*12799*/, 5112 /*5112*/, 5111 /*5111*/, 5910 /*5910*/, 14183 /*14183*/, 10880 /*10880*/, 5110 /*5110*/, 6175 /*6175*/, 2784 /*2784*/, 8879 /*8879*/, 3401 /*3401*/, 3342 /*3342*/, 16012 /*16012*/, 6446 /*6446*/, 5108 /*5108*/, 1274 /*1274*/, 8671 /*8671*/, 5107 /*5107*/, 5106 /*5106*/, 2460 /*2460*/, 8720 /*8720*/, 3402 /*3402*/, 9859 /*9859*/, 2461 /*2461*/, 13843 /*13843*/, 5109 /*5109*/, 7292 /*7292*/, 14363 /*14363*/, 5103 /*5103*/, 5099 /*5099*/, 3327 /*3327*/, 5102 /*5102*/, 3334 /*3334*/, 5132 /*5132*/, 5130 /*5130*/, 5049 /*5049*/, 5100 /*5100*/, 5101 /*5101*/, 2790 /*2790*/, 5816 /*5816*/, 5892 /*5892*/, 3330 /*3330*/, 3403 /*3403*/, 3344 /*3344*/, 4047 /*4047*/, 13417 /*13417*/, 14304 /*14304*/, 15765 /*15765*/, 3325 /*3325*/, 3324 /*3324*/, 5815 /*5815*/, 5909 /*5909*/, 3335 /*3335*/, 5875 /*5875*/, 3351 /*3351*/, 3350 /*3350*/, 3326 /*3326*/, 15761 /*15761*/, 11046 /*11046*/, 8659 /*8659*/, 14540 /*14540*/, 10088 /*10088*/, 12353 /*12353*/, 14541 /*14541*/, 3362 /*3362*/, 12351 /*12351*/, 5195 /*5195*/, 14539 /*14539*/, 4752 /*4752*/, 3352 /*3352*/, 7294 /*7294*/, 9988 /*9988*/, 3407 /*3407*/, 3406 /*3406*/, 14182 /*14182*/, 3355 /*3355*/, 5812 /*5812*/, 3356 /*3356*/, 7230 /*7230*/, 7793 /*7793*/, 7792 /*7792*/, 7790 /*7790*/, 10266 /*10266*/, 11176 /*11176*/, 1383 /*1383*/, 11178 /*11178*/, 11177 /*11177*/, 3408 /*3408*/, 15350 /*15350*/, 3354 /*3354*/, 15006 /*15006*/, 3890 /*3890*/, 3353 /*3353*/, 14498 /*14498*/, 3413 /*3413*/, 3412 /*3412*/, 14942 /*14942*/, 3410 /*3410*/, 9317 /*9317*/, 11017 /*11017*/, 2857 /*2857*/, 14499 /*14499*/, 14451 /*14451*/, 3357 /*3357*/, 3358 /*3358*/, 4485 /*4485*/, 3332 /*3332*/, 3333 /*3333*/, 3359 /*3359*/, 3347 /*3347*/, 3348 /*3348*/, 14365 /*14365*/, 11066 /*11066*/, 6986 /*6986*/, 3346 /*3346*/, 6987 /*6987*/, 3345 /*3345*/, 3404 /*3404*/, 3405 /*3405*/, 3365 /*3365*/, 5811 /*5811*/, 3366 /*3366*/, 3316 /*3316*/, 7088 /*7088*/, 2855 /*2855*/, 3363 /*3363*/, 3315 /*3315*/, 14726 /*14726*/, 3371 /*3371*/, 3367 /*3367*/, 3364 /*3364*/, 3372 /*3372*/, 7010 /*7010*/, 5129 /*5129*/, 5126 /*5126*/, 5125 /*5125*/, 6114 /*6114*/, 13084 /*13084*/, 15351 /*15351*/, 12197 /*12197*/, 11865 /*11865*/, 5115 /*5115*/, 5114 /*5114*/, 5113 /*5113*/, 1901 /*1901*/, 7976 /*7976*/, 3369 /*3369*/, 3368 /*3368*/, 3400 /*3400*/, 3399 /*3399*/, 3328 /*3328*/, 3216 /*3216*/, 5121 /*5121*/, 5120 /*5120*/, 3323 /*3323*/, 3189 /*3189*/, 3331 /*3331*/, 3329 /*3329*/, 5119 /*5119*/, 7565 /*7565*/, 15453 /*15453*/, 15452 /*15452*/, 5150 /*5150*/, 15451 /*15451*/, 4949 /*4949*/, 3310 /*3310*/, 9856 /*9856*/, 8673 /*8673*/, 12383 /*12383*/, 8401 /*8401*/, 3057 /*3057*/, 5188 /*5188*/, 8724 /*8724*/, 3322 /*3322*/, 14377 /*14377*/, 3312 /*3312*/, 15188 /*15188*/, 14375 /*14375*/, 10259 /*10259*/, 3018 /*3018*/, 3314 /*3314*/, 3320 /*3320*/, 3318 /*3318*/, 3309 /*3309*/, 5614 /*5614*/, 5611 /*5611*/, 5610 /*5610*/, 5613 /*5613*/, 6466 /*6466*/, 5609 /*5609*/, 5606 /*5606*/, 6929 /*6929*/, 13842 /*13842*/, 5603 /*5603*/, 5597 /*5597*/, 3321 /*3321*/, 3319 /*3319*/, 3317 /*3317*/, 173758 /*173758*/, 15164 /*15164*/, 3028 /*3028*/, 3029 /*3029*/, 5817 /*5817*/, 3313 /*3313*/, 3011 /*3011*/, 4721 /*4721*/, 3024 /*3024*/, 3014 /*3014*/, 3013 /*3013*/, 3023 /*3023*/, 3022 /*3022*/, 8398 /*8398*/, 3021 /*3021*/, 3020 /*3020*/, 3019 /*3019*/, 3017 /*3017*/, 3012 /*3012*/, 11071 /*11071*/, 3027 /*3027*/, 3026 /*3026*/, 3025 /*3025*/, 14392 /*14392*/, 14720 /*14720*/, 857 /*857*/, 14982 /*14982*/, 7298 /*7298*/, 15102 /*15102*/, 10090 /*10090*/, 3296 /*3296*/, 3083 /*3083*/, 5124 /*5124*/, 15701 /*15701*/, 4081 /*4081*/, 5138 /*5138*/, 7950 /*7950*/, 5137 /*5137*/, 6569 /*6569*/, 7944 /*7944*/, 7937 /*7937*/, 5569 /*5569*/, 5117 /*5117*/, 9984 /*9984*/, 5116 /*5116*/, 15450 /*15450*/, 15448 /*15448*/, 15446 /*15446*/, 15437 /*15437*/, 5605 /*5605*/, 15434 /*15434*/, 5178 /*5178*/, 5177 /*5177*/, 1246 /*1246*/, 5570 /*5570*/, 15539 /*15539*/, 15734 /*15734*/, 15733 /*15733*/, 15731 /*15731*/, 5140 /*5140*/, 15432 /*15432*/, 15431 /*15431*/, 5123 /*5123*/, 5122 /*5122*/, 2695 /*2695*/, 15457 /*15457*/, 15456 /*15456*/, 15735 /*15735*/, 15455 /*15455*/, 15663 /*15663*/, 5595 /*5595*/, 15445 /*15445*/, 15383 /*15383*/, 5951 /*5951*/, 4311 /*4311*/, 3100 /*3100*/, 2996 /*2996*/, 6746 /*6746*/, 8362 /*8362*/, 5054 /*5054*/, 3001 /*3001*/, 2995 /*2995*/, 3007 /*3007*/, 3004 /*3004*/, 14728 /*14728*/, 3092 /*3092*/, 3978 /*3978*/, 11051 /*11051*/, 4451 /*4451*/, 7089 /*7089*/, 3050 /*3050*/, 8364 /*8364*/, 5189 /*5189*/, 3095 /*3095*/, 3093 /*3093*/, 11084 /*11084*/, 8357 /*8357*/, 3015 /*3015*/, 8356 /*8356*/, 3008 /*3008*/, 10881 /*10881*/, 3005 /*3005*/, 3002 /*3002*/, 8722 /*8722*/, 2999 /*2999*/, 2997 /*2997*/, 2987 /*2987*/, 15767 /*15767*/, 11869 /*11869*/, 6410 /*6410*/, 15702 /*15702*/, 8363 /*8363*/, 8361 /*8361*/, 8359 /*8359*/, 8358 /*8358*/, 8674 /*8674*/, 10278 /*10278*/, 10054 /*10054*/, 15105 /*15105*/, 8360 /*8360*/, 3084 /*3084*/, 3003 /*3003*/, 2998 /*2998*/);
INSERT INTO `creature_template` (`entry`, `gossip_menu_id`, `level_min`, `level_max`, `faction`, `npc_flags`, `speed_walk`, `speed_run`, `scale`, `base_attack_time`, `unit_flags`, `unit_flags2`, `vehicle_id`, `hover_height`, `auras`) VALUES
(15533, 0, 56, 56, 29, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15533
(15535, 6664, 60, 60, 104, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15535
(15460, 6619, 58, 58, 29, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15460
(14376, 0, 60, 60, 85, 0, 1, 1.142857, 1, 2000, 32768, 2048, 0, 1, '18950'), -- 14376
(15738, 6810, 55, 55, 68, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15738
(15534, 6663, 58, 58, 126, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15534
(3373, 0, 35, 35, 29, 83, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3373
(15469, 6624, 60, 60, 126, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15469
(15459, 6618, 56, 56, 68, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15459
(3349, 0, 30, 30, 29, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3349
(15737, 6807, 55, 55, 126, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15737
(15458, 6678, 60, 60, 35, 1, 1, 1.385714, 1, 2000, 0, 2048, 0, 1, ''), -- 15458
(15529, 6660, 58, 58, 68, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15529
(15528, 6659, 56, 56, 104, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15528
(15512, 6653, 60, 60, 68, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15512
(15532, 6661, 60, 60, 104, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15532
(15739, 6809, 55, 55, 104, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15739
(15736, 6808, 55, 55, 29, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15736
(15700, 6778, 60, 60, 29, 3, 1, 1.385714, 1, 2000, 0, 2048, 0, 1, ''), -- 15700
(15477, 6625, 56, 56, 104, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15477
(15522, 6656, 58, 58, 29, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15522
(15508, 6651, 58, 58, 126, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15508
(8404, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 8404
(15525, 6657, 60, 60, 68, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15525
(15515, 6654, 56, 56, 126, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15515
(15696, 0, 30, 30, 29, 0, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15696
(7567, 0, 1, 1, 188, 0, 1, 1.142857, 1, 2000, 33536, 2048, 0, 1, ''), -- 7567
(7562, 0, 1, 1, 188, 0, 1, 1.142857, 1, 2000, 33536, 2048, 0, 1, ''), -- 7562
(3370, 0, 45, 45, 29, 786433, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3370
(12799, 0, 55, 55, 29, 4224, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 12799
(5112, 0, 30, 30, 55, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5112
(5111, 345, 30, 30, 55, 65667, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5111
(5910, 0, 15, 15, 83, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5910
(14183, 0, 60, 60, 55, 2, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 14183
(10880, 0, 3, 3, 29, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 10880
(5110, 0, 30, 30, 55, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5110
(6175, 0, 8, 8, 12, 2, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 6175
(2784, 0, 63, 63, 55, 2, 1, 1.142857, 1, 2000, 64, 2048, 0, 1, ''), -- 2784
(8879, 0, 50, 50, 55, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 8879
(3401, 0, 60, 60, 126, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3401
(3342, 0, 35, 35, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3342
(16012, 0, 60, 60, 1619, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 16012
(6446, 0, 20, 20, 83, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 6446
(5108, 0, 30, 30, 55, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5108
(1274, 0, 50, 50, 55, 2, 1, 1.142857, 1, 1500, 512, 2048, 0, 1, ''), -- 1274
(8671, 0, 50, 50, 55, 2097152, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 8671
(5107, 0, 30, 30, 55, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5107
(5106, 0, 30, 30, 55, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5106
(2460, 0, 45, 45, 55, 131072, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 2460
(8720, 0, 50, 50, 55, 2097152, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 8720
(3402, 0, 35, 35, 126, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3402
(9859, 0, 50, 50, 55, 2097152, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 9859
(2461, 0, 45, 45, 55, 131072, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 2461
(13843, 0, 60, 60, 1217, 2, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 13843
(5109, 0, 30, 30, 55, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5109
(7292, 0, 55, 55, 55, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 7292
(14363, 0, 60, 60, 57, 0, 1, 1.142857, 1, 2000, 32768, 2048, 0, 1, '18950'), -- 14363
(5103, 0, 30, 30, 55, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5103
(5099, 0, 45, 45, 55, 131072, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5099
(3327, 0, 40, 40, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3327
(5102, 0, 30, 30, 55, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5102
(3334, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3334
(5132, 0, 30, 30, 875, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5132
(5130, 0, 60, 60, 55, 786433, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5130
(5049, 0, 25, 25, 55, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5049
(5100, 0, 30, 30, 875, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5100
(5101, 0, 30, 30, 55, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5101
(2790, 0, 44, 44, 55, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 2790
(5816, 0, 30, 30, 29, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5816
(5892, 0, 15, 15, 126, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5892
(3330, 0, 30, 30, 29, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3330
(3403, 0, 40, 40, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3403
(3344, 0, 60, 60, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3344
(4047, 0, 62, 62, 29, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 4047
(13417, 0, 50, 50, 104, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 13417
(14304, 0, 60, 60, 85, 0, 1, 1.142857, 1, 2000, 32768, 2048, 0, 1, ''), -- 14304
(15765, 0, 55, 55, 29, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15765
(3325, 0, 50, 50, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3325
(3324, 0, 50, 50, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3324
(5815, 0, 45, 45, 29, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5815
(5909, 0, 40, 40, 83, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5909
(3335, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3335
(5875, 0, 40, 40, 83, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5875
(3351, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3351
(3350, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3350
(3326, 0, 50, 50, 29, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3326
(15761, 0, 55, 55, 126, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15761
(11046, 0, 23, 23, 29, 17, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 11046
(8659, 0, 50, 50, 876, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 8659
(14540, 0, 10, 10, 35, 0, 1, 1.385714, 1, 2000, 0, 2048, 0, 1, ''), -- 14540
(10088, 0, 40, 40, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 10088
(12353, 0, 10, 10, 35, 0, 1, 1.385714, 1, 2000, 0, 2048, 0, 1, ''), -- 12353
(14541, 0, 10, 10, 35, 0, 1, 1.385714, 1, 2000, 0, 2048, 0, 1, ''), -- 14541
(3362, 0, 45, 45, 29, 131, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3362
(12351, 0, 10, 10, 35, 0, 1, 1.385714, 1, 2000, 0, 2048, 0, 1, ''), -- 12351
(5195, 0, 10, 10, 35, 0, 1, 1.385714, 1, 2000, 0, 2048, 0, 1, ''), -- 5195
(14539, 0, 10, 10, 35, 0, 1, 1.385714, 1, 2000, 0, 2048, 0, 1, ''), -- 14539
(4752, 0, 50, 50, 29, 81, 1, 1.385714, 1, 2000, 512, 2048, 0, 1, ''), -- 4752
(3352, 0, 60, 60, 29, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3352
(7294, 0, 35, 35, 29, 0, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 7294
(9988, 0, 30, 30, 29, 4194304, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 9988
(3407, 0, 40, 40, 29, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3407
(3406, 0, 50, 50, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3406
(14182, 0, 60, 60, 104, 2, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 14182
(3355, 0, 45, 45, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3355
(5812, 0, 30, 30, 29, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5812
(3356, 0, 30, 30, 29, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3356
(7230, 0, 60, 60, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 7230
(7793, 0, 53, 53, 104, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 7793
(7792, 0, 50, 50, 29, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 7792
(7790, 0, 45, 45, 29, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 7790
(10266, 0, 25, 25, 29, 17, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 10266
(11176, 0, 53, 53, 29, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 11176
(1383, 0, 31, 31, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 1383
(11178, 0, 51, 51, 29, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 11178
(11177, 0, 52, 52, 29, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 11177
(3408, 0, 40, 40, 29, 49, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3408
(15350, 0, 60, 60, 1074, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15350
(3354, 0, 50, 50, 29, 51, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3354
(15006, 0, 61, 61, 412, 1, 1, 1.142857, 1, 2000, 576, 2048, 0, 1, ''), -- 15006
(3890, 0, 61, 61, 1515, 1, 1, 1.142857, 1, 2000, 576, 2048, 0, 1, ''), -- 3890
(3353, 0, 60, 60, 29, 49, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3353
(14498, 0, 34, 34, 29, 0, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 14498
(3413, 0, 30, 30, 29, 131, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3413
(3412, 0, 35, 35, 29, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3412
(14942, 0, 61, 61, 1214, 1, 1, 1.142857, 1, 2000, 576, 2048, 0, 1, ''), -- 14942
(3410, 0, 30, 30, 29, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3410
(9317, 0, 22, 22, 29, 2, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 9317
(11017, 0, 46, 46, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 11017
(2857, 0, 23, 23, 29, 17, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 2857
(14499, 0, 1, 3, 29, 0, 1, 1, 1, 2000, 768, 2048, 0, 1, ''), -- 14499
(14451, 0, 10, 10, 29, 3, 1, 1.142857, 1, 2000, 768, 2048, 0, 1, ''), -- 14451
(3357, 0, 35, 35, 29, 80, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3357
(3358, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3358
(4485, 0, 35, 35, 29, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 4485
(3332, 0, 35, 35, 29, 83, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3332
(3333, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3333
(3359, 0, 30, 30, 29, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3359
(3347, 0, 35, 35, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3347
(3348, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3348
(14365, 0, 60, 60, 57, 0, 1, 1.142857, 1, 2000, 32768, 2048, 0, 1, '18950'), -- 14365
(11066, 0, 26, 26, 29, 17, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 11066
(6986, 0, 45, 45, 29, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 6986
(3346, 0, 35, 35, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3346
(6987, 0, 40, 40, 125, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 6987
(3345, 0, 35, 35, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3345
(3404, 0, 35, 35, 126, 80, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3404
(3405, 0, 30, 30, 126, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3405
(3365, 0, 35, 35, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3365
(5811, 0, 26, 26, 29, 17, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5811
(3366, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3366
(3316, 0, 30, 30, 29, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3316
(7088, 0, 35, 35, 29, 80, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 7088
(2855, 0, 24, 24, 29, 17, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 2855
(3363, 0, 35, 35, 29, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3363
(3315, 0, 30, 30, 29, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3315
(14726, 0, 35, 35, 29, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 14726
(3371, 0, 30, 30, 29, 0, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3371
(3367, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3367
(3364, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3364
(3372, 0, 30, 30, 29, 0, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3372
(7010, 0, 35, 35, 126, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 7010
(5129, 0, 30, 30, 55, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5129
(5126, 0, 30, 30, 55, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5126
(5125, 0, 30, 30, 55, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5125
(6114, 0, 50, 50, 55, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 6114
(13084, 0, 50, 50, 55, 17, 1, 1.142857, 1, 1500, 0, 2048, 0, 1, ''), -- 13084
(15351, 0, 60, 60, 55, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15351
(12197, 0, 61, 61, 1216, 1048577, 1, 1.142857, 1, 2000, 576, 2048, 0, 1, ''), -- 12197
(11865, 0, 50, 50, 55, 17, 1, 1.142857, 1, 1500, 0, 2048, 0, 1, ''), -- 11865
(5115, 0, 60, 60, 55, 49, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5115
(5114, 0, 45, 45, 875, 1, 1, 1.142857, 1, 1500, 512, 2048, 0, 1, ''), -- 5114
(5113, 0, 45, 45, 55, 3, 1, 1.142857, 1, 1500, 512, 2048, 0, 1, ''), -- 5113
(1901, 0, 45, 45, 55, 1, 1, 1.142857, 1, 1500, 512, 2048, 0, 1, ''), -- 1901
(7976, 0, 30, 30, 55, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 7976
(3369, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3369
(3368, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3368
(3400, 0, 30, 30, 126, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3400
(3399, 0, 35, 35, 126, 83, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3399
(3328, 0, 50, 50, 29, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3328
(3216, 0, 37, 37, 29, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3216
(5121, 0, 30, 30, 55, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5121
(5120, 0, 30, 30, 55, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5120
(3323, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3323
(3189, 0, 7, 7, 126, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3189
(3331, 0, 30, 30, 29, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3331
(3329, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3329
(5119, 0, 30, 30, 55, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5119
(7565, 0, 1, 1, 35, 0, 1, 1.142857, 1, 2000, 33536, 2048, 0, 1, ''), -- 7565
(15453, 6613, 60, 60, 80, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15453
(15452, 6612, 58, 58, 12, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15452
(5150, 0, 35, 35, 55, 83, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5150
(15451, 6610, 56, 56, 80, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15451
(4949, 0, 63, 63, 125, 3, 1, 1.142857, 1, 2000, 64, 4196352, 0, 1, ''), -- 4949
(3310, 0, 55, 55, 29, 8195, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3310
(9856, 0, 50, 50, 29, 2097152, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 9856
(8673, 0, 50, 50, 29, 2097152, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 8673
(12383, 0, 1, 1, 31, 0, 1, 0.8571429, 1, 2000, 768, 2048, 0, 1, ''), -- 12383
(8401, 0, 30, 30, 104, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 8401
(3057, 0, 63, 63, 104, 3, 1, 1.142857, 1, 2000, 64, 2048, 0, 1, ''), -- 3057
(5188, 0, 30, 30, 29, 524416, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5188
(8724, 0, 50, 50, 29, 2097152, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 8724
(3322, 0, 30, 30, 29, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3322
(14377, 0, 60, 60, 85, 0, 1, 1.142857, 1, 2000, 32768, 2048, 0, 1, '18950'), -- 14377
(3312, 0, 50, 50, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3312
(15188, 0, 55, 55, 994, 2, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15188
(14375, 0, 60, 60, 85, 0, 1, 1.142857, 1, 2000, 32768, 2048, 0, 1, '18950'), -- 14375
(10259, 0, 1, 1, 35, 0, 1, 1.142857, 1, 2000, 768, 2048, 0, 1, ''), -- 10259
(3018, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3018
(3314, 0, 30, 30, 29, 4225, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3314
(3320, 0, 45, 45, 29, 131073, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3320
(3318, 0, 45, 45, 29, 131073, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3318
(3309, 0, 45, 45, 29, 131075, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3309
(5614, 0, 25, 25, 29, 0, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5614
(5611, 0, 13, 13, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5611
(5610, 0, 12, 12, 29, 0, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5610
(5613, 0, 11, 11, 126, 0, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5613
(6466, 0, 12, 12, 7, 0, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 6466
(5609, 0, 14, 14, 29, 0, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5609
(5606, 0, 12, 12, 29, 0, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5606
(6929, 0, 30, 30, 29, 65539, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 6929
(13842, 0, 60, 60, 1215, 2, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 13842
(5603, 0, 38, 38, 29, 0, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5603
(5597, 0, 38, 38, 29, 0, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5597
(3321, 0, 30, 30, 29, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3321
(3319, 0, 30, 30, 29, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3319
(3317, 0, 30, 30, 29, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3317
(173758, 0, 60, 60, 29, 0, 1, 0.9920629, 1, 2000, 33555200, 2048, 0, 1, ''), -- 173758
(15164, 0, 60, 60, 114, 0, 1, 1.142857, 1, 2000, 33555200, 2048, 0, 1, ''), -- 15164
(3028, 0, 45, 45, 104, 81, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3028
(3029, 0, 40, 40, 104, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3029
(5817, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5817
(3313, 0, 30, 30, 29, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3313
(3011, 0, 35, 35, 104, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3011
(4721, 0, 25, 25, 104, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 4721
(3024, 0, 30, 30, 104, 0, 1, 1.142857, 1, 2000, 768, 2048, 0, 1, ''), -- 3024
(3014, 0, 30, 30, 104, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3014
(3013, 0, 35, 35, 104, 80, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3013
(3023, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3023
(3022, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3022
(8398, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 8398
(3021, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3021
(3020, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3020
(3019, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3019
(3017, 0, 30, 30, 104, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3017
(3012, 0, 30, 30, 104, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3012
(11071, 0, 21, 21, 104, 17, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 11071
(3027, 0, 40, 40, 104, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3027
(3026, 0, 45, 45, 104, 81, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3026
(3025, 0, 30, 30, 104, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''); -- 3025

INSERT INTO `creature_template` (`entry`, `gossip_menu_id`, `level_min`, `level_max`, `faction`, `npc_flags`, `speed_walk`, `speed_run`, `scale`, `base_attack_time`, `unit_flags`, `unit_flags2`, `vehicle_id`, `hover_height`, `auras`) VALUES
(14392, 0, 60, 60, 29, 3, 1, 1.142857, 1, 2000, 0, 4196352, 0, 1, ''), -- 14392
(14720, 6024, 62, 62, 29, 3, 1, 2.285714, 1, 2000, 0, 4196352, 0, 1, '26341'), -- 14720
(857, 0, 61, 61, 1577, 1048577, 1, 1.142857, 1, 2000, 576, 2048, 0, 1, ''), -- 857
(14982, 0, 61, 61, 1514, 1048577, 1, 1.142857, 1, 2000, 576, 2048, 0, 1, ''), -- 14982
(7298, 0, 45, 45, 55, 0, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 7298
(15102, 0, 22, 23, 1642, 1048577, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15102
(10090, 0, 40, 40, 55, 51, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 10090
(3296, 1951, 55, 55, 85, 1, 1, 1.142857, 1, 2000, 32768, 2048, 0, 1, ''), -- 3296
(3083, 0, 60, 60, 105, 0, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 3083
(5124, 0, 30, 30, 55, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5124
(15701, 6772, 60, 60, 55, 3, 1, 1.385714, 1, 2000, 0, 2048, 0, 1, ''), -- 15701
(4081, 0, 29, 29, 875, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 4081
(5138, 0, 30, 30, 55, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5138
(7950, 0, 57, 57, 875, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 7950
(5137, 0, 35, 35, 55, 16, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5137
(6569, 0, 20, 20, 55, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 6569
(7944, 0, 57, 57, 64, 67, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 7944
(7937, 0, 63, 63, 64, 2, 1, 1.142857, 1, 2000, 64, 2048, 0, 1, ''), -- 7937
(5569, 0, 40, 40, 875, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5569
(5117, 0, 40, 40, 55, 49, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5117
(9984, 0, 30, 30, 55, 4194304, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 9984
(5116, 0, 50, 50, 55, 51, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5116
(15450, 6609, 60, 60, 875, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15450
(15448, 6608, 58, 58, 12, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15448
(15446, 6607, 56, 56, 55, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15446
(15437, 6605, 58, 58, 80, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15437
(5605, 0, 30, 30, 55, 0, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 5605
(15434, 6604, 56, 56, 875, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15434
(5178, 0, 30, 30, 875, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5178
(5177, 0, 35, 35, 875, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5177
(1246, 0, 30, 30, 55, 17, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 1246
(5570, 0, 50, 50, 55, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5570
(15539, 6665, 60, 60, 35, 1, 1, 1.385714, 1, 2000, 0, 2048, 0, 1, ''), -- 15539
(15734, 6805, 55, 55, 55, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15734
(15733, 0, 55, 55, 875, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15733
(15731, 6803, 55, 55, 80, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15731
(5140, 0, 30, 30, 55, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5140
(15432, 6603, 60, 60, 55, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15432
(15431, 6602, 58, 58, 12, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15431
(5123, 0, 30, 30, 55, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5123
(5122, 0, 30, 30, 55, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5122
(2695, 0, 15, 15, 55, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 2695
(15457, 6616, 60, 60, 80, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15457
(15456, 6615, 58, 58, 875, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15456
(15735, 6806, 55, 55, 12, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15735
(15455, 6614, 56, 56, 875, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15455
(15663, 0, 30, 30, 55, 0, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15663
(5595, 0, 55, 55, 57, 1, 1, 1.142857, 1, 2000, 32768, 2048, 0, 1, ''), -- 5595
(15445, 6606, 60, 60, 12, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15445
(15383, 6599, 56, 56, 55, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15383
(5951, 0, 1, 1, 31, 0, 1, 0.8571429, 1, 2000, 0, 2048, 0, 1, ''), -- 5951
(4311, 0, 30, 30, 29, 0, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 4311
(3100, 0, 8, 9, 189, 0, 1, 0.8571429, 1, 2000, 0, 2048, 0, 1, ''), -- 3100
(2996, 0, 45, 45, 104, 131072, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 2996
(6746, 0, 30, 30, 104, 65667, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 6746
(8362, 0, 30, 30, 104, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 8362
(5054, 0, 50, 50, 104, 786433, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5054
(3001, 0, 35, 35, 104, 16, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3001
(2995, 4326, 55, 55, 104, 8195, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 2995
(3007, 0, 46, 46, 104, 3, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3007
(3004, 0, 35, 35, 104, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3004
(14728, 0, 35, 35, 104, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 14728
(3092, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3092
(3978, 0, 30, 30, 104, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3978
(11051, 0, 26, 26, 104, 17, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 11051
(4451, 0, 28, 28, 104, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 4451
(7089, 0, 35, 35, 104, 16, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 7089
(3050, 0, 21, 21, 104, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3050
(8364, 0, 30, 30, 104, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 8364
(5189, 0, 25, 25, 104, 524416, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 5189
(3095, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3095
(3093, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3093
(11084, 0, 36, 36, 104, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 11084
(8357, 0, 45, 45, 104, 131072, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 8357
(3015, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3015
(8356, 0, 45, 45, 104, 131072, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 8356
(3008, 0, 24, 24, 104, 17, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3008
(10881, 0, 3, 3, 104, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 10881
(3005, 0, 30, 30, 104, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3005
(3002, 0, 40, 40, 104, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3002
(8722, 0, 50, 50, 104, 2097152, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 8722
(2999, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 2999
(2997, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 2997
(2987, 0, 12, 12, 83, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 2987
(15767, 6809, 55, 55, 104, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15767
(11869, 0, 50, 50, 104, 17, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 11869
(6410, 0, 45, 45, 83, 2, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 6410
(15702, 6790, 60, 60, 104, 3, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15702
(8363, 0, 30, 30, 104, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 8363
(8361, 0, 30, 30, 104, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 8361
(8359, 0, 30, 30, 104, 4227, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 8359
(8358, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 8358
(8674, 0, 50, 50, 104, 2097152, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 8674
(10278, 0, 24, 24, 104, 17, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 10278
(10054, 0, 30, 30, 29, 4194304, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 10054
(15105, 0, 30, 30, 1641, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 15105
(8360, 0, 30, 30, 104, 4224, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 8360
(3084, 0, 55, 55, 105, 1, 1, 1.142857, 1, 2000, 0, 2048, 0, 1, ''), -- 3084
(3003, 0, 30, 30, 104, 128, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''), -- 3003
(2998, 0, 35, 35, 104, 1, 1, 1.142857, 1, 2000, 512, 2048, 0, 1, ''); -- 2998


DELETE FROM `creature_text_template` WHERE (`group_id`=0 AND `entry` IN (5109,6175));
INSERT INTO `creature_text_template` (`entry`, `group_id`, `text`, `chat_type`, `language`, `emote`, `sound`, `broadcast_text_id`, `comment`) VALUES
(5109, 0, 'Fresh bread for sale!', 12, 7, 0, 0, 0, 'Myra Tyrngaarde'),
(6175, 0, 'Help the children of Stormwind... victims of the war and plague!', 12, 0, 0, 0, 0, 'John Turner');

DELETE FROM `quest_template` WHERE `ID` IN (8792 /*8792*/, 8850 /*8850*/, 8813 /*8813*/, 8814 /*8814*/);
INSERT INTO `quest_template` (`ID`, `QuestType`, `QuestLevel`, `ScalingFactionGroup`, `MaxScalingLevel`, `QuestPackageID`, `MinLevel`, `QuestSortID`, `QuestInfoID`, `SuggestedGroupNum`, `RewardNextQuest`, `RewardXPDifficulty`, `RewardXPMultiplier`, `RewardMoney`, `RewardMoneyDifficulty`, `RewardMoneyMultiplier`, `RewardBonusMoney`, `RewardDisplaySpell1`, `RewardDisplaySpell2`, `RewardDisplaySpell3`, `RewardSpell`, `RewardHonor`, `RewardKillHonor`, `StartItem`, `RewardArtifactXPDifficulty`, `RewardArtifactXPMultiplier`, `RewardArtifactCategoryID`, `Flags`, `FlagsEx`, `FlagsEx2`, `RewardSkillLineID`, `RewardNumSkillUps`, `PortraitGiver`, `PortraitGiverMount`, `PortraitTurnIn`, `RewardItem1`, `RewardItem2`, `RewardItem3`, `RewardItem4`, `RewardAmount1`, `RewardAmount2`, `RewardAmount3`, `RewardAmount4`, `ItemDrop1`, `ItemDrop2`, `ItemDrop3`, `ItemDrop4`, `ItemDropQuantity1`, `ItemDropQuantity2`, `ItemDropQuantity3`, `ItemDropQuantity4`, `RewardChoiceItemID1`, `RewardChoiceItemID2`, `RewardChoiceItemID3`, `RewardChoiceItemID4`, `RewardChoiceItemID5`, `RewardChoiceItemID6`, `RewardChoiceItemQuantity1`, `RewardChoiceItemQuantity2`, `RewardChoiceItemQuantity3`, `RewardChoiceItemQuantity4`, `RewardChoiceItemQuantity5`, `RewardChoiceItemQuantity6`, `RewardChoiceItemDisplayID1`, `RewardChoiceItemDisplayID2`, `RewardChoiceItemDisplayID3`, `RewardChoiceItemDisplayID4`, `RewardChoiceItemDisplayID5`, `RewardChoiceItemDisplayID6`, `POIContinent`, `POIx`, `POIy`, `POIPriority`, `RewardTitle`, `RewardArenaPoints`, `RewardFactionID1`, `RewardFactionID2`, `RewardFactionID3`, `RewardFactionID4`, `RewardFactionID5`, `RewardFactionValue1`, `RewardFactionValue2`, `RewardFactionValue3`, `RewardFactionValue4`, `RewardFactionValue5`, `RewardFactionCapIn1`, `RewardFactionCapIn2`, `RewardFactionCapIn3`, `RewardFactionCapIn4`, `RewardFactionCapIn5`, `RewardFactionOverride1`, `RewardFactionOverride2`, `RewardFactionOverride3`, `RewardFactionOverride4`, `RewardFactionOverride5`, `RewardFactionFlags`, `AreaGroupID`, `TimeAllowed`, `AllowableRaces`, `TreasurePickerID`, `Expansion`, `LogTitle`, `LogDescription`, `QuestDescription`, `AreaDescription`, `QuestCompletionLog`, `RewardCurrencyID1`, `RewardCurrencyID2`, `RewardCurrencyID3`, `RewardCurrencyID4`, `RewardCurrencyQty1`, `RewardCurrencyQty2`, `RewardCurrencyQty3`, `RewardCurrencyQty4`, `PortraitGiverText`, `PortraitGiverName`, `PortraitTurnInText`, `PortraitTurnInName`, `AcceptedSoundKitID`, `CompleteSoundKitID`, `VerifiedBuild`) VALUES
(8792, 2, 60, 0, 255, 0, 1, -365, 0, 0, 0, 1, 1, 0, 0, 1, 3900, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 0, 0, 0, 511, 0, 0, 'The Horde Needs Your Help!', 'Speak with Warlord Gorchuk in Orgrimmar\'s Valley of Spirits.', 'Hello, I\'m glad that you\'ve decided to hear me out. The Horde needs all of the help that it can get to prepare for the Ahn\'Qiraj War, and that means that we need you! Even now as we speak, official collectors are gathering the necessary material needed for the upcoming war, but we won\'t be able to meet our goals without your assistance, $N!$B$BYou should go speak with the guy in charge, Warlord Gorchuk. What do you say, $c? Will you help out with the vital preparations?', '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', 890, 878, 35186), -- 8792
(8850, 0, 60, 0, 255, 0, 50, -365, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 21513, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 0, 0, 0, 511, 0, 0, 'Thirty Signets for War Supplies', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', 890, 878, 35186), -- 8850
(8813, 0, 60, 0, 255, 0, 1, -367, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 47, 0, 0, 0, 0, 9, 0, 0, 0, 0, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 1, 0, 0, 511, 0, 0, 'One Commendation Signet', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', 890, 878, 35186), -- 8813
(8814, 0, 60, 0, 255, 0, 1, -367, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 0, 0, 0, 0, 9, 0, 0, 0, 0, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 1, 0, 0, 511, 0, 0, 'One Commendation Signet', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', 890, 878, 35186); -- 8814


DELETE FROM `quest_objectives` WHERE `ID` IN (384564 /*384564*/, 382097 /*382097*/, 382261 /*382261*/);
INSERT INTO `quest_objectives` (`ID`, `QuestID`, `Type`, `Order`, `StorageIndex`, `ObjectID`, `Amount`, `Flags`, `Flags2`, `ProgressBarWeight`, `Description`, `VerifiedBuild`) VALUES
(384564, 8850, 1, 0, 0, 21436, 30, 0, 0, 0, '', 35186), -- 384564
(382097, 8813, 1, 0, 0, 21436, 1, 0, 0, 0, '', 35186), -- 382097
(382261, 8814, 1, 0, 0, 21436, 1, 0, 0, 0, '', 35186); -- 382261


DELETE FROM `creature_template_wdb` WHERE `entry` IN (3057 /*3057*/, 12383 /*12383*/, 8401 /*8401*/, 3018 /*3018*/, 15164 /*15164*/, 3028 /*3028*/, 3029 /*3029*/, 3011 /*3011*/, 3024 /*3024*/, 4721 /*4721*/, 3013 /*3013*/, 3014 /*3014*/, 11071 /*11071*/, 3017 /*3017*/, 3012 /*3012*/, 3025 /*3025*/, 3021 /*3021*/, 3020 /*3020*/, 3019 /*3019*/, 8398 /*8398*/, 3083 /*3083*/, 15533 /*15533*/, 14376 /*14376*/, 15535 /*15535*/, 15460 /*15460*/, 15738 /*15738*/, 15534 /*15534*/, 15469 /*15469*/, 3373 /*3373*/, 15459 /*15459*/, 15737 /*15737*/, 3349 /*3349*/, 15458 /*15458*/, 15532 /*15532*/, 15529 /*15529*/, 15528 /*15528*/, 15736 /*15736*/, 15512 /*15512*/, 15739 /*15739*/, 15700 /*15700*/, 15508 /*15508*/, 15477 /*15477*/, 15522 /*15522*/, 8404 /*8404*/, 15525 /*15525*/, 15696 /*15696*/, 15515 /*15515*/, 7562 /*7562*/, 3370 /*3370*/, 12799 /*12799*/, 5910 /*5910*/, 10880 /*10880*/, 16012 /*16012*/, 3342 /*3342*/, 3401 /*3401*/, 6446 /*6446*/, 3402 /*3402*/, 3327 /*3327*/, 3334 /*3334*/, 5816 /*5816*/, 5892 /*5892*/, 3403 /*3403*/, 3330 /*3330*/, 4047 /*4047*/, 3344 /*3344*/, 13417 /*13417*/, 14304 /*14304*/, 15765 /*15765*/, 5909 /*5909*/, 3324 /*3324*/, 5815 /*5815*/, 3335 /*3335*/, 3325 /*3325*/, 5875 /*5875*/, 3351 /*3351*/, 3350 /*3350*/, 3326 /*3326*/, 15761 /*15761*/, 11046 /*11046*/, 8659 /*8659*/, 12353 /*12353*/, 14540 /*14540*/, 10088 /*10088*/, 14541 /*14541*/, 12351 /*12351*/, 3362 /*3362*/, 5195 /*5195*/, 14539 /*14539*/, 4752 /*4752*/, 3352 /*3352*/, 3406 /*3406*/, 3407 /*3407*/, 7294 /*7294*/, 9988 /*9988*/, 14182 /*14182*/, 5812 /*5812*/, 3355 /*3355*/, 3356 /*3356*/, 7790 /*7790*/, 7230 /*7230*/, 10266 /*10266*/, 7792 /*7792*/, 7793 /*7793*/, 1383 /*1383*/, 11176 /*11176*/, 11177 /*11177*/, 11178 /*11178*/, 3354 /*3354*/, 15350 /*15350*/, 3408 /*3408*/, 15006 /*15006*/, 3353 /*3353*/, 14498 /*14498*/, 3890 /*3890*/, 9317 /*9317*/, 2857 /*2857*/, 3410 /*3410*/, 14942 /*14942*/, 11017 /*11017*/, 3412 /*3412*/, 3413 /*3413*/, 14499 /*14499*/, 3357 /*3357*/, 14451 /*14451*/, 3358 /*3358*/, 4485 /*4485*/, 3332 /*3332*/, 3333 /*3333*/, 3359 /*3359*/, 3347 /*3347*/, 3348 /*3348*/, 11066 /*11066*/, 6986 /*6986*/, 3346 /*3346*/, 6987 /*6987*/, 3345 /*3345*/, 3405 /*3405*/, 3404 /*3404*/, 5811 /*5811*/, 3365 /*3365*/, 3316 /*3316*/, 3366 /*3366*/, 7088 /*7088*/, 3363 /*3363*/, 2855 /*2855*/, 14726 /*14726*/, 3315 /*3315*/, 3367 /*3367*/, 3371 /*3371*/, 3364 /*3364*/, 3372 /*3372*/, 7010 /*7010*/, 3369 /*3369*/, 3368 /*3368*/, 3400 /*3400*/, 3399 /*3399*/, 3328 /*3328*/, 3216 /*3216*/, 3331 /*3331*/, 3329 /*3329*/, 3323 /*3323*/, 3189 /*3189*/, 7565 /*7565*/, 3430 /*3430*/, 3310 /*3310*/, 8673 /*8673*/, 9856 /*9856*/, 5188 /*5188*/, 8724 /*8724*/, 14377 /*14377*/, 3322 /*3322*/, 3312 /*3312*/, 15188 /*15188*/, 14375 /*14375*/, 3314 /*3314*/, 5611 /*5611*/, 3318 /*3318*/, 5610 /*5610*/, 5614 /*5614*/, 3320 /*3320*/, 3309 /*3309*/, 5613 /*5613*/, 6466 /*6466*/, 5606 /*5606*/, 5609 /*5609*/, 6929 /*6929*/, 13842 /*13842*/, 3319 /*3319*/, 3321 /*3321*/, 5603 /*5603*/, 3317 /*3317*/, 5597 /*5597*/, 5817 /*5817*/, 3313 /*3313*/);
INSERT INTO `creature_template_wdb` (`entry`, `kill_credit1`, `kill_credit2`, `display_total_count`, `display_total_probability`, `display_id1`, `display_id2`, `display_id3`, `display_id4`, `display_scale1`, `display_scale2`, `display_scale3`, `display_scale4`, `display_probability1`, `display_probability2`, `display_probability3`, `display_probability4`, `name`, `female_name`, `subname`, `title_alt`, `icon_name`, `health_scaling_expansion`, `required_expansion`, `vignette_id`, `unit_class`, `rank`, `beast_family`, `type`, `type_flags`, `type_flags2`, `pet_spell_list_id`, `health_multiplier`, `mana_multiplier`, `civilian`, `racial_leader`, `movement_id`, `sniff_build`) VALUES
(3057, 0, 0, 1, 1, 4307, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Cairne Bloodhoof', '', 'High Chieftain', NULL, NULL, 0, 0, 0, 1, 3, 0, 7, 134217732, 0, 0, 300, 16, 0, 0, 1693, 35186), -- 3057
(12383, 0, 0, 1, 1, 1072, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Nibbles', '', 'Prairie Dog', NULL, NULL, 0, 0, 0, 1, 0, 0, 8, 134217728, 0, 0, 0.2, 1, 1, 0, 1695, 35186), -- 12383
(8401, 0, 0, 1, 1, 7629, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Halpa', '', 'Prairie Dog Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 8401
(3018, 0, 0, 1, 1, 2086, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Hogor Thunderhoof', '', 'Guns Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3018
(15164, 0, 0, 1, 0, 11686, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 'Mulgore Trigger', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 10, 134217728, 0, 0, 1.35, 1, 0, 0, 1693, 35186), -- 15164
(3028, 0, 0, 1, 1, 2088, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Kah Mistrunner', '', 'Fishing Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.2, 1, 1, 0, 1693, 35186), -- 3028
(3029, 0, 0, 1, 1, 2120, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Sewa Mistrunner', '', 'Fishing Supplier', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.15, 1, 1, 0, 1693, 35186), -- 3029
(3011, 0, 0, 1, 1, 2101, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Teg Dawnstrider', '', 'Expert Enchanter', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3011
(3024, 0, 0, 1, 1, 2097, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Tah Winterhoof', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3024
(4721, 0, 0, 1, 100, 2738, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Zangen Stonehoof', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.02, 1, 1, 0, 1693, 35186), -- 4721
(3013, 0, 0, 1, 1, 2091, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Komin Winterhoof', '', 'Herbalism Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3013
(3014, 0, 0, 1, 1, 2119, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Nida Winterhoof', '', 'Herbalism Supplier', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3014
(11071, 0, 0, 1, 1, 10614, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Mot Dawnstrider', '', 'Journeyman Enchanter', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.02, 1, 1, 0, 1693, 35186), -- 11071
(3017, 0, 0, 1, 1, 2117, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Nan Mistrunner', '', 'Fruit Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3017
(3012, 0, 0, 1, 1, 2118, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Nata Dawnstrider', '', 'Enchanting Supplies', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3012
(3025, 0, 0, 1, 1, 2111, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Kaga Mistrunner', '', 'Meat Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3025
(3021, 0, 0, 1, 1, 2089, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Kard Ragetotem', '', 'Sword and Dagger Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3021
(3020, 0, 0, 1, 1, 2085, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Etu Ragetotem', '', 'Mace & Staff Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3020
(3019, 0, 0, 1, 1, 2084, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Delgo Ragetotem', '', 'Axe Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3019
(8398, 0, 0, 1, 1, 10689, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Ohanko', '', 'Two Handed Weapon Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 8398
(3083, 0, 0, 1, 1, 2140, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Honor Guard', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 2, 1, 0, 0, 1693, 35186), -- 3083
(15533, 0, 0, 1, 100, 15542, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Bloodguard Rawtar', '', 'Lean Wolf Steak Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15533
(14376, 0, 0, 1, 100, 14414, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Scout Manslayer', '', NULL, NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 3, 1, 0, 0, 1693, 35186), -- 14376
(15535, 0, 0, 1, 100, 15544, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Chief Sharpclaw', '', 'Baked Salmon Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15535
(15460, 0, 0, 1, 100, 15462, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Grunt Maug', '', 'Tin Bar Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15460
(15738, 0, 0, 2, 100, 15722, 15723, 0, 0, 1, 1, 0, 0, 50, 50, 0, 0, 'Undercity Commendation Officer', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 15738
(15534, 0, 0, 1, 100, 15543, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Fisherman Lin\'do', '', 'Spotted Yellowtail Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15534
(15469, 0, 0, 1, 100, 15466, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Senior Sergeant T\'kelah', '', 'Mithril Bar Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15469
(3373, 0, 0, 1, 100, 1395, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Arnok', '', 'First Aid Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3373
(15459, 0, 0, 1, 100, 15461, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Miner Cromwell', '', 'Copper Bar Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15459
(15737, 0, 0, 2, 100, 15701, 15702, 0, 0, 1, 1, 0, 0, 50, 50, 0, 0, 'Darkspear Commendation Officer', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 15737
(3349, 0, 0, 1, 100, 1370, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Ukra\'nor', '', 'Staff Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3349
(15458, 0, 0, 1, 100, 15460, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Commander Stronghammer', '', 'Alliance Ambassador', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15458
(15532, 0, 0, 1, 100, 15541, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Stoneguard Clayhoof', '', 'Runecloth Bandage Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15532
(15529, 0, 0, 1, 100, 15539, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Lady Callow', '', 'Mageweave Bandage Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15529
(15528, 0, 0, 1, 100, 15537, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Healer Longrunner', '', 'Wool Bandage Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15528
(15736, 0, 0, 2, 100, 15716, 15717, 0, 0, 1, 1, 0, 0, 50, 50, 0, 0, 'Orgrimmar Commendation Officer', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 15736
(15512, 0, 0, 1, 100, 15503, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Apothecary Jezel', '', 'Purple Lotus Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15512
(15739, 0, 0, 2, 100, 15720, 15721, 0, 0, 1, 1, 0, 0, 50, 50, 0, 0, 'Thunder Bluff Commendation Officer', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 15739
(15700, 0, 0, 1, 100, 15661, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Warlord Gorchuk', '', 'War Effort Commander', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 10, 1, 1, 0, 1693, 35186), -- 15700
(15508, 0, 0, 1, 100, 15502, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Batrider Pele\'keiki', '', 'Firebloom Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15508
(15477, 0, 0, 1, 100, 15472, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Herbalist Proudfeather', '', 'Peacebloom Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15477
(15522, 0, 0, 1, 100, 15535, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Sergeant Umala', '', 'Thick Leather Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15522
(8404, 0, 0, 1, 1, 7631, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Xan\'tish', '', 'Snake Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 8404
(15525, 0, 0, 1, 100, 15536, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Doctor Serratus', '', 'Rugged Leather Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15525
(15696, 0, 0, 4, 100, 15650, 15652, 15651, 15653, 1, 1, 1, 1, 25, 25, 25, 25, 'War Effort Recruit', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15696
(15515, 0, 0, 1, 100, 15508, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Skinner Jamani', '', 'Heavy Leather Collector', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 5, 1, 1, 0, 1693, 35186), -- 15515
(7562, 0, 0, 1, 1, 2957, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Brown Snake', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, 134217728, 0, 0, 1, 1, 1, 0, 1699, 35186), -- 7562
(3370, 0, 0, 1, 100, 1392, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Urtrun Clanbringer', '', 'Guild Master', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.2, 1, 1, 0, 1693, 35186), -- 3370
(12799, 0, 0, 1, 100, 12681, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Sergeant Ba\'sha', '', 'Accessories Quartermaster', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 2, 1, 1, 0, 1693, 35186), -- 12799
(5910, 0, 0, 1, 100, 4546, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Zankaja', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 5910
(10880, 0, 0, 1, 1, 10186, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Warcaller Gorlach', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 10880
(16012, 0, 0, 1, 100, 15966, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Mokvar', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 2, 1, 0, 0, 1693, 35186), -- 16012
(3342, 0, 0, 1, 100, 1358, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Shan\'ti', '', 'Fruit Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3342
(3401, 0, 0, 1, 100, 4360, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Shenthul', '', 'Rogue Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.35, 1, 1, 0, 1693, 35186), -- 3401
(6446, 0, 0, 1, 1, 5190, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Therzok', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 6446
(3402, 0, 0, 1, 100, 4361, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Zando\'zan', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3402
(3327, 0, 0, 1, 100, 1327, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Gest', '', 'Rogue Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.15, 1, 1, 0, 1693, 35186), -- 3327
(3334, 0, 0, 1, 100, 1334, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Rekkul', '', 'Poison Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3334
(5816, 0, 0, 1, 100, 4355, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Katis', '', 'Wand Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 5816
(5892, 0, 0, 1, 100, 4534, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Searn Firewarder', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 5892
(3403, 0, 0, 1, 100, 4231, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Sian\'tsu', '', 'Shaman Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.15, 1, 1, 0, 1693, 35186), -- 3403
(3330, 0, 0, 1, 100, 1330, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Muragus', '', 'Staff Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3330
(4047, 0, 0, 1, 100, 4514, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Zor Lonetree', '', 'Elder Far Seer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.35, 1, 1, 0, 1693, 35186), -- 4047
(3344, 0, 0, 1, 100, 1360, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Kardris Dreamseeker', '', 'Shaman Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.35, 1, 1, 0, 1693, 35186), -- 3344
(13417, 0, 0, 1, 100, 13341, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Sagorne Creststrider', '', 'Shaman Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.25, 1, 1, 0, 1693, 35186), -- 13417
(14304, 0, 0, 4, 100, 14360, 14362, 14361, 14363, 1, 1, 1, 1, 25, 25, 25, 25, 'Kor\'kron Elite', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 2, 1, 0, 0, 1693, 35186), -- 14304
(15765, 0, 0, 1, 100, 15724, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Officer Redblade', '', 'Orgrimmar Commendations', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 15765
(5909, 0, 0, 1, 100, 4545, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Cazul', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.15, 1, 1, 0, 1693, 35186), -- 5909
(3324, 0, 0, 1, 100, 1324, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Grol\'dar', '', 'Warlock Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.25, 1, 1, 0, 1693, 35186), -- 3324
(5815, 0, 0, 1, 100, 4354, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Kurgul', '', 'Demon Trainer', NULL, NULL, 0, 0, 0, 8, 0, 0, 7, 134217728, 0, 0, 1.2, 1, 1, 0, 1693, 35186), -- 5815
(3335, 0, 0, 1, 100, 1335, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Hagrus', '', 'Reagents Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3335
(3325, 0, 0, 1, 100, 1325, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Mirket', '', 'Warlock Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.25, 1, 1, 0, 1693, 35186), -- 3325
(5875, 0, 0, 1, 100, 4492, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Gan\'rul Bloodeye', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.15, 1, 1, 0, 1693, 35186), -- 5875
(3351, 0, 0, 1, 100, 1372, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Magenius', '', 'Reagents Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3351
(3350, 0, 0, 1, 100, 1371, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Asoran', '', 'General Goods Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3350
(3326, 0, 0, 1, 100, 1326, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Zevrost', '', 'Warlock Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.25, 1, 1, 0, 1693, 35186), -- 3326
(15761, 0, 0, 1, 100, 15731, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Officer Vu\'Shalay', '', 'Darkspear Commendations', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 15761
(11046, 0, 0, 1, 100, 10578, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Whuut', '', 'Journeyman Alchemist', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.02, 1, 1, 0, 1693, 35186), -- 11046
(8659, 0, 0, 1, 1, 7921, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Jes\'rimon', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.25, 1, 1, 0, 1693, 35186), -- 8659
(12353, 0, 0, 1, 1, 247, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Timber Riding Wolf', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 12353
(14540, 0, 0, 1, 1, 14573, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Swift Brown Wolf', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, 134217728, 0, 0, 1, 1, 1, 0, 1698, 35186), -- 14540
(10088, 0, 0, 1, 1, 9336, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Xao\'tsu', '', 'Pet Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.15, 1, 1, 0, 1693, 35186), -- 10088
(14541, 0, 0, 1, 1, 14574, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Swift Gray Wolf', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, 134217728, 0, 0, 1, 1, 1, 0, 1698, 35186), -- 14541
(12351, 0, 0, 1, 1, 2327, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Dire Riding Wolf', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 12351
(3362, 0, 0, 1, 100, 1384, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Ogunaro Wolfrunner', '', 'Kennel Master', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.2, 1, 1, 0, 1693, 35186), -- 3362
(5195, 0, 0, 1, 1, 2328, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Brown Riding Wolf', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 5195
(14539, 0, 0, 1, 1, 14575, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Swift Timber Wolf', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, 134217728, 0, 0, 1, 1, 1, 0, 1698, 35186), -- 14539
(4752, 0, 0, 1, 100, 4464, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Kildar', '', 'Wolf Riding Instructor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.25, 1, 1, 0, 1693, 35186), -- 4752
(3352, 0, 0, 1, 100, 1373, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Ormak Grimshot', '', 'Hunter Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.35, 1, 1, 0, 1693, 35186), -- 3352
(3406, 0, 0, 1, 100, 4239, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Xor\'juul', '', 'Hunter Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.25, 1, 1, 0, 1693, 35186), -- 3406
(3407, 0, 0, 1, 100, 4241, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Sian\'dur', '', 'Hunter Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.15, 1, 1, 0, 1693, 35186), -- 3407
(7294, 0, 0, 1, 100, 6064, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Shim\'la', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 7294
(9988, 0, 0, 1, 1, 9261, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Xon\'cha', '', 'Stable Master', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 9988
(14182, 0, 0, 1, 1, 14216, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Bounty Hunter Kolark', '', NULL, NULL, NULL, 0, 0, 0, 2, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 14182
(5812, 0, 0, 1, 100, 4351, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Tumi', '', 'Heavy Armor Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 5812
(3355, 0, 0, 1, 100, 1377, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Saru Steelfury', '', 'Artisan Blacksmith', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.2, 1, 1, 0, 1693, 35186), -- 3355
(3356, 0, 0, 1, 100, 1378, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Sumi', '', 'Blacksmithing Supplier', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3356
(7790, 0, 0, 1, 1, 6873, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Orokk Omosh', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.2, 1, 1, 0, 1693, 35186), -- 7790
(7230, 0, 0, 1, 100, 6005, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Shayis Steelfury', '', 'Armor Crafter', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.35, 1, 1, 0, 1693, 35186), -- 7230
(10266, 0, 0, 1, 1, 9739, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Ug\'thok', '', 'Journeyman Blacksmith', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.02, 1, 1, 0, 1693, 35186), -- 10266
(7792, 0, 0, 1, 1, 6843, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Aturk the Anvil', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.25, 1, 1, 0, 1693, 35186), -- 7792
(7793, 0, 0, 1, 100, 6854, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Ox', '', 'The Mithril Order', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.3, 1, 1, 0, 1693, 35186), -- 7793
(1383, 0, 0, 1, 1, 4382, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Snarl', '', 'Expert Blacksmith', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 1383
(11176, 0, 0, 1, 100, 10695, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Krathok Moltenfist', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.3, 1, 1, 0, 1693, 35186), -- 11176
(11177, 0, 0, 1, 100, 10696, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Okothos Ironrager', '', 'Armorsmith', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.3, 1, 1, 0, 1693, 35186), -- 11177
(11178, 0, 0, 1, 100, 10697, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Borgosh Corebender', '', 'Weaponsmith', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.3, 1, 1, 0, 1693, 35186), -- 11178
(3354, 0, 0, 1, 100, 1375, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Sorek', '', 'Warrior Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.25, 1, 1, 0, 1693, 35186), -- 3354
(15350, 0, 0, 1, 100, 15387, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Horde Warbringer', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 15350
(3408, 0, 0, 1, 100, 4242, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Zel\'mak', '', 'Warrior Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.15, 1, 1, 0, 1693, 35186), -- 3408
(15006, 0, 0, 1, 100, 15112, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Deze Snowbane', '', 'Arathi Basin Battlemaster', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 50, 1, 0, 0, 1693, 35186), -- 15006
(3353, 0, 0, 1, 100, 1374, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Grezz Ragefist', '', 'Warrior Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.35, 1, 1, 0, 1693, 35186), -- 3353
(14498, 0, 0, 1, 1, 3850, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Tosamina', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 14498
(3890, 0, 0, 1, 100, 15032, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Brakgul Deathbringer', '', 'Warsong Gulch Battlemaster', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 50, 1, 0, 0, 1693, 35186), -- 3890
(9317, 0, 0, 1, 1, 8631, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Rilli Greasygob', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.02, 1, 1, 0, 1693, 35186), -- 9317
(2857, 0, 0, 1, 1, 4386, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Thund', '', 'Journeyman Engineer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.02, 1, 1, 0, 1693, 35186), -- 2857
(3410, 0, 0, 1, 100, 4359, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Jin\'sora', '', 'Bow Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3410
(14942, 0, 0, 1, 100, 15033, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Kartra Bloodsnarl', '', 'Alterac Valley Battlemaster', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 50, 1, 0, 0, 1693, 35186), -- 14942
(11017, 0, 0, 1, 100, 10472, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Roxxik', '', 'Artisan Engineer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.25, 1, 1, 0, 1693, 35186), -- 11017
(3412, 0, 0, 1, 100, 7135, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Nogg', '', 'Expert Engineer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3412
(3413, 0, 0, 1, 1, 7136, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Sovik', '', 'Engineering Supplies', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3413
(14499, 0, 0, 2, 2, 14589, 14616, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 'Horde Orphan', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 14499
(3357, 0, 0, 1, 100, 1379, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Makaru', '', 'Mining Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3357
(14451, 0, 0, 1, 100, 14499, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Orphan Matron Battlewail', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 14451
(3358, 0, 0, 1, 100, 1380, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Gorina', '', 'Mining Supplier', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3358
(4485, 0, 0, 1, 1, 5535, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Belgrom Rockmaul', '', NULL, NULL, NULL, 0, 0, 0, 2, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 4485
(3332, 0, 0, 1, 100, 1332, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Lumak', '', 'Fishing Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3332
(3333, 0, 0, 1, 100, 1333, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Shankys', '', 'Fishing Supplies', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3333
(3359, 0, 0, 1, 100, 1381, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Kiro', '', 'War Harness Maker', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3359
(3347, 0, 0, 1, 100, 1368, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Yelmak', '', 'Expert Alchemist', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3347
(3348, 0, 0, 1, 100, 1369, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Kor\'geld', '', 'Alchemy Supplies', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3348
(11066, 0, 0, 1, 100, 10589, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Jhag', '', 'Journeyman Enchanter', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 11066
(6986, 0, 0, 1, 1, 5769, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Dran Droffers', '', 'Droffers and Son Salvage', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.2, 1, 1, 0, 1693, 35186), -- 6986
(3346, 0, 0, 1, 100, 1367, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Kithas', '', 'Enchanting Supplies', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3346
(6987, 0, 0, 1, 1, 5770, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Malton Droffers', '', 'Droffers and Son Salvage', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.15, 1, 0, 0, 1693, 35186), -- 6987
(3345, 0, 0, 1, 100, 1366, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Godan', '', 'Expert Enchanter', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3345
(3405, 0, 0, 1, 100, 4362, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Zeal\'aya', '', 'Herbalism Supplier', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3405
(3404, 0, 0, 1, 100, 4358, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Jandi', '', 'Herbalism Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3404
(5811, 0, 0, 1, 100, 4350, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Kamari', '', 'Journeyman Leatherworker', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 5811
(3365, 0, 0, 1, 100, 1387, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Karolek', '', 'Expert Leatherworker', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3365
(3316, 0, 0, 1, 100, 1316, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Handor', '', 'Cloth & Leather Armor Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3316
(3366, 0, 0, 1, 100, 1388, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Tamar', '', 'Leatherworking Supplies', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3366
(7088, 0, 0, 1, 100, 5846, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Thuwd', '', 'Skinning Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 7088
(3363, 0, 0, 1, 100, 1385, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Magar', '', 'Expert Tailor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3363
(2855, 0, 0, 1, 1, 4384, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Snang', '', 'Journeyman Tailor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.02, 1, 1, 0, 1693, 35186), -- 2855
(14726, 0, 0, 1, 100, 14757, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Rashona Straglash', '', 'Horde Cloth Quartermaster', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 14726
(3315, 0, 0, 1, 100, 1315, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Tor\'phan', '', 'Cloth & Leather Armor Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3315
(3367, 0, 0, 1, 100, 1389, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Felika', '', 'General Trade Goods Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3367
(3371, 0, 0, 1, 100, 1393, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Tamaro', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3371
(3364, 0, 0, 1, 100, 1386, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Borya', '', 'Tailoring Supplies', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3364
(3372, 0, 0, 1, 100, 1394, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Sarlek', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3372
(7010, 0, 0, 1, 100, 6839, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Zilzibin Drumlore', '', NULL, NULL, NULL, 0, 0, 0, 8, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 7010
(3369, 0, 0, 1, 100, 1391, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Gotri', '', 'Bag Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3369
(3368, 0, 0, 1, 100, 1390, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Borstan', '', 'Meat Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3368
(3400, 0, 0, 1, 100, 2735, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Xen\'to', '', 'Cooking Supplier', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3400
(3399, 0, 0, 1, 100, 2734, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Zamja', '', 'Cooking Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.1, 1, 1, 0, 1693, 35186), -- 3399
(3328, 0, 0, 1, 100, 1328, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Ormok', '', 'Rogue Trainer', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.25, 1, 1, 0, 1693, 35186), -- 3328
(3216, 0, 0, 1, 1, 3754, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Neeru Fireblade', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.15, 1, 1, 0, 1693, 35186), -- 3216
(3331, 0, 0, 1, 100, 1331, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Kareth', '', 'Blade Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3331
(3329, 0, 0, 1, 100, 1329, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Kor\'jus', '', 'Mushroom Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3329
(3323, 0, 0, 1, 100, 1323, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Horthus', '', 'Reagents Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3323
(3189, 0, 0, 1, 1, 4073, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Kor\'ghan', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 3189
(7565, 0, 0, 1, 1, 1206, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Black Kingsnake', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, 134217728, 0, 0, 1, 1, 1, 0, 1699, 35186), -- 7565
(3430, 0, 0, 1, 0, 1346, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 'Mangletooth', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 3430
(3310, 0, 0, 1, 100, 1311, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Doras', '', 'Wind Rider Master', NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 3, 3, 1, 0, 1693, 35186), -- 3310
(8673, 0, 0, 1, 100, 8001, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Auctioneer Thathung', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 3, 1, 1, 0, 1693, 35186), -- 8673
(9856, 0, 0, 1, 100, 9133, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Auctioneer Grimful', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 3, 1, 1, 0, 1693, 35186), -- 9856
(5188, 0, 0, 1, 1, 3128, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Garyl', '', 'Tabard Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 5188
(8724, 0, 0, 1, 100, 8000, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Auctioneer Wabang', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 3, 1, 1, 0, 1693, 35186), -- 8724
(14377, 0, 0, 1, 100, 14415, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Scout Tharr', '', NULL, NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 3, 1, 0, 0, 1693, 35186), -- 14377
(3322, 0, 0, 1, 100, 1322, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Kaja', '', 'Guns and Ammo Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3322
(3312, 0, 0, 1, 1, 1312, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Olvia', '', 'Meat Vendor', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.25, 1, 1, 0, 1693, 35186), -- 3312
(15188, 0, 0, 1, 0, 15322, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 'Cenarion Emissary Blackhoof', '', NULL, NULL, NULL, 0, 0, 0, 8, 0, 0, 7, 134217728, 0, 0, 1, 1, 0, 0, 1693, 35186), -- 15188
(14375, 0, 0, 1, 100, 14413, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Scout Stronghand', '', NULL, NULL, NULL, 0, 0, 0, 1, 1, 0, 7, 134217728, 0, 0, 3, 1, 0, 0, 1693, 35186), -- 14375
(3314, 0, 0, 1, 100, 1314, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Urtharo', '', 'Weapon Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3314
(5611, 0, 0, 1, 100, 3606, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Barkeep Morag', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 5611
(3318, 0, 0, 1, 100, 1318, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Koma', '', 'Banker', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 3, 1, 1, 0, 1693, 35186), -- 3318
(5610, 0, 0, 1, 100, 7137, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Kozish', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 5610
(5614, 0, 0, 1, 100, 3609, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Sarok', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.02, 1, 1, 0, 1693, 35186), -- 5614
(3320, 0, 0, 1, 100, 1320, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Soran', '', 'Banker', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 3, 1, 1, 0, 1693, 35186), -- 3320
(3309, 0, 0, 1, 100, 1310, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Karus', '', 'Banker', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 3, 1, 1, 0, 1693, 35186), -- 3309
(5613, 0, 0, 1, 100, 3608, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Doyo\'da', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 5613
(6466, 0, 0, 1, 100, 5205, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Gamon', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 0, 0, 1693, 35186), -- 6466
(5606, 0, 0, 1, 100, 3604, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Goma', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 5606
(5609, 0, 0, 1, 100, 3605, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Zazo', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 5609
(6929, 0, 0, 1, 1, 5706, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 'Innkeeper Gryshka', '', 'Innkeeper', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 6929
(13842, 0, 0, 1, 100, 13843, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Frostwolf Ambassador Rokhstrom', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1, 1, 1, 0, 1693, 35186), -- 13842
(3319, 0, 0, 1, 100, 1319, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Sana', '', 'Mail Armor Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3319
(3321, 0, 0, 1, 100, 1321, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Morgum', '', 'Leather Armor Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3321
(5603, 0, 0, 1, 100, 3564, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Grunt Mojka', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.15, 1, 1, 0, 1693, 35186), -- 5603
(3317, 0, 0, 1, 100, 1317, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Ollanus', '', 'Light Armor Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 3317
(5597, 0, 0, 1, 100, 3546, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Grunt Komak', '', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.15, 1, 1, 0, 1693, 35186), -- 5597
(5817, 0, 0, 1, 100, 4356, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Shimra', '', 'General Trade Goods Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186), -- 5817
(3313, 0, 0, 1, 100, 1313, 0, 0, 0, 1, 0, 0, 0, 100, 0, 0, 0, 'Trak\'gen', '', 'General Goods Merchant', NULL, NULL, 0, 0, 0, 1, 0, 0, 7, 134217728, 0, 0, 1.05, 1, 1, 0, 1693, 35186); -- 3313


DELETE FROM `gameobject_template` WHERE `entry` IN (177267 /*177267*/, 177268 /*177268*/, 177266 /*177266*/, 178571 /*178571*/, 177265 /*177265*/, 3303 /*3303*/, 177015 /*177015*/, 173162 /*173162*/, 177014 /*177014*/, 173159 /*173159*/, 173157 /*173157*/, 173161 /*173161*/, 173160 /*173160*/, 177016 /*177016*/, 172997 /*172997*/, 172996 /*172996*/, 172971 /*172971*/, 172970 /*172970*/, 177023 /*177023*/, 179742 /*179742*/, 179741 /*179741*/, 176520 /*176520*/, 176519 /*176519*/, 176521 /*176521*/, 176516 /*176516*/, 176517 /*176517*/, 179740 /*179740*/, 176518 /*176518*/, 172974 /*172974*/, 172973 /*172973*/, 172972 /*172972*/, 172969 /*172969*/, 173117 /*173117*/, 173007 /*173007*/, 177002 /*177002*/, 173101 /*173101*/, 173062 /*173062*/, 173025 /*173025*/, 172995 /*172995*/, 172994 /*172994*/, 172993 /*172993*/, 172977 /*172977*/, 172976 /*172976*/, 172975 /*172975*/, 173170 /*173170*/, 173163 /*173163*/, 173130 /*173130*/, 173132 /*173132*/, 173131 /*173131*/, 173146 /*173146*/, 173136 /*173136*/, 173167 /*173167*/, 173145 /*173145*/, 173175 /*173175*/, 173169 /*173169*/, 173165 /*173165*/, 173144 /*173144*/, 173143 /*173143*/, 173177 /*173177*/, 173142 /*173142*/, 173139 /*173139*/, 173138 /*173138*/, 173137 /*173137*/, 173141 /*173141*/, 173140 /*173140*/, 173172 /*173172*/, 177005 /*177005*/, 175316 /*175316*/, 173173 /*173173*/, 177004 /*177004*/, 173058 /*173058*/, 173057 /*173057*/, 172981 /*172981*/, 172980 /*172980*/, 172979 /*172979*/, 172978 /*172978*/, 175319 /*175319*/, 173061 /*173061*/, 173059 /*173059*/, 175658 /*175658*/, 173060 /*173060*/, 173056 /*173056*/, 175312 /*175312*/, 177003 /*177003*/, 172950 /*172950*/, 172956 /*172956*/, 173022 /*173022*/, 172951 /*172951*/, 172944 /*172944*/, 173050 /*173050*/, 173194 /*173194*/, 173184 /*173184*/, 173178 /*173178*/, 173179 /*173179*/, 177013 /*177013*/, 177007 /*177007*/, 177006 /*177006*/, 173085 /*173085*/, 173074 /*173074*/, 173067 /*173067*/, 173072 /*173072*/, 177010 /*177010*/, 177011 /*177011*/, 173096 /*173096*/, 173095 /*173095*/, 173094 /*173094*/, 173083 /*173083*/, 173073 /*173073*/, 173065 /*173065*/, 173066 /*173066*/, 173064 /*173064*/, 173089 /*173089*/, 173119 /*173119*/, 173118 /*173118*/, 173120 /*173120*/, 173071 /*173071*/, 173092 /*173092*/, 173121 /*173121*/, 173070 /*173070*/, 173090 /*173090*/, 173123 /*173123*/, 173122 /*173122*/, 173082 /*173082*/, 173093 /*173093*/, 173091 /*173091*/, 173099 /*173099*/, 173077 /*173077*/, 173081 /*173081*/, 173063 /*173063*/, 173080 /*173080*/, 173100 /*173100*/, 173068 /*173068*/, 177012 /*177012*/, 173084 /*173084*/, 173069 /*173069*/, 173086 /*173086*/, 173088 /*173088*/, 173075 /*173075*/, 173087 /*173087*/, 173076 /*173076*/, 177009 /*177009*/, 173079 /*173079*/, 172992 /*172992*/, 177008 /*177008*/, 173042 /*173042*/, 173052 /*173052*/, 173051 /*173051*/, 173049 /*173049*/, 173039 /*173039*/, 173041 /*173041*/, 173040 /*173040*/, 173038 /*173038*/, 173021 /*173021*/, 173054 /*173054*/, 173048 /*173048*/, 175314 /*175314*/, 173104 /*173104*/, 173055 /*173055*/, 173024 /*173024*/, 173023 /*173023*/, 172949 /*172949*/, 173045 /*173045*/, 173053 /*173053*/, 172947 /*172947*/, 173047 /*173047*/, 173046 /*173046*/, 173105 /*173105*/, 173020 /*173020*/, 173103 /*173103*/, 172991 /*172991*/, 172990 /*172990*/, 172989 /*172989*/, 172988 /*172988*/, 172987 /*172987*/, 172986 /*172986*/, 172985 /*172985*/, 172984 /*172984*/, 172983 /*172983*/, 172982 /*172982*/, 173034 /*173034*/, 172955 /*172955*/, 173035 /*173035*/, 173043 /*173043*/, 172948 /*172948*/, 173044 /*173044*/, 173033 /*173033*/, 173032 /*173032*/, 173031 /*173031*/, 173030 /*173030*/, 173018 /*173018*/, 173036 /*173036*/, 173037 /*173037*/, 173028 /*173028*/, 172954 /*172954*/, 172946 /*172946*/, 173019 /*173019*/, 175315 /*175315*/, 173029 /*173029*/, 173017 /*173017*/, 173015 /*173015*/, 173014 /*173014*/, 172942 /*172942*/, 175317 /*175317*/, 173016 /*173016*/, 172941 /*172941*/, 173027 /*173027*/, 173026 /*173026*/, 179596 /*179596*/, 172945 /*172945*/, 105576 /*105576*/, 175318 /*175318*/, 175313 /*175313*/, 173166 /*173166*/, 173102 /*173102*/, 173168 /*173168*/, 173176 /*173176*/, 173174 /*173174*/, 173171 /*173171*/, 173164 /*173164*/, 173116 /*173116*/, 179739 /*179739*/, 173006 /*173006*/, 172968 /*172968*/, 172952 /*172952*/, 177025 /*177025*/, 172967 /*172967*/, 172953 /*172953*/, 173213 /*173213*/, 172962 /*172962*/, 172963 /*172963*/, 172964 /*172964*/, 177021 /*177021*/, 172966 /*172966*/, 173210 /*173210*/, 173212 /*173212*/, 173211 /*173211*/, 173113 /*173113*/, 173125 /*173125*/, 173108 /*173108*/, 173110 /*173110*/, 177022 /*177022*/, 173214 /*173214*/, 173209 /*173209*/, 173109 /*173109*/, 173107 /*173107*/, 177026 /*177026*/, 173111 /*173111*/, 173218 /*173218*/, 173219 /*173219*/, 173217 /*173217*/, 173208 /*173208*/, 173220 /*173220*/, 173222 /*173222*/, 172965 /*172965*/, 173106 /*173106*/, 173224 /*173224*/, 173223 /*173223*/, 173215 /*173215*/, 173205 /*173205*/, 173115 /*173115*/, 173225 /*173225*/, 173114 /*173114*/, 173226 /*173226*/, 173221 /*173221*/, 173216 /*173216*/, 173207 /*173207*/, 177020 /*177020*/, 173206 /*173206*/, 173204 /*173204*/, 177019 /*177019*/, 173202 /*173202*/, 177024 /*177024*/, 173199 /*173199*/, 173198 /*173198*/, 179881 /*179881*/, 173197 /*173197*/, 173203 /*173203*/, 173112 /*173112*/, 177017 /*177017*/, 173200 /*173200*/, 172961 /*172961*/, 172960 /*172960*/, 172959 /*172959*/, 172958 /*172958*/, 172957 /*172957*/, 180842 /*180842*/, 180822 /*180822*/, 177018 /*177018*/, 180836 /*180836*/, 173012 /*173012*/, 173008 /*173008*/, 173010 /*173010*/, 173009 /*173009*/, 173011 /*173011*/, 173013 /*173013*/, 180830 /*180830*/);
INSERT INTO `gameobject_template` (`entry`, `type`, `display_id`, `scale`, `name`, `icon_name`, `unk1`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `data24`, `data25`, `data26`, `data27`, `data28`, `data29`, `data30`, `data31`, `data32`, `data33`, `quest_items_count`, `required_level`, `sniff_build`) VALUES
(177267, 5, 4717, 1, 'Bridge to Elder Rise', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177267
(177268, 5, 4718, 1, 'Bridge to Hunter Rise', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177268
(177266, 5, 4717, 1, 'Bridge to Elder Rise', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177266
(178571, 1, 1967, 1, 'Bonfire', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 178571
(177265, 5, 4716, 1, 'Bridge to Spirit Rise', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177265
(3303, 8, 192, 1.37, 'Warm Fire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 3303
(177015, 8, 4572, 3.531562, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177015
(173162, 5, 711, 1.33, 'Survival of the Fittest', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173162
(177014, 8, 4572, 2.825249, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177014
(173159, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173159
(173157, 5, 707, 1.33, 'Skyfury Staves', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173157
(173161, 5, 714, 1.33, 'Darkbriar Lodge', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173161
(173160, 5, 714, 1.33, 'Spirit Lodge', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173160
(177016, 8, 4572, 2.825249, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177016
(172997, 5, 309, 1, 'Orgrimmar Main Gate', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172997
(172996, 5, 309, 1, 'Valley of Strength', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172996
(172971, 5, 309, 1, 'Talon Gate', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172971
(172970, 5, 309, 1, 'Valley of Spirits', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172970
(177023, 8, 4572, 1.443039, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177023
(179742, 5, 707, 1.33, 'Hall of Legends', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 179742
(179741, 9, 214, 1.9032, 'Horde Military Ranks', '', '', 2677, 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 179741
(176520, 8, 408, 1, 'Doodad_SmallFirePit75', '', '', 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 176520
(176519, 8, 408, 1, 'Doodad_SmallFirePit74', '', '', 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 176519
(176521, 8, 408, 1, 'Doodad_SmallFirePit76', '', '', 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 176521
(176516, 8, 408, 1, 'Doodad_SmallFirePit71', '', '', 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 176516
(176517, 8, 408, 1, 'Doodad_SmallFirePit72', '', '', 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 176517
(179740, 5, 309, 1, 'Hall of Legends', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 179740
(176518, 8, 408, 1, 'Doodad_SmallFirePit73', '', '', 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 176518
(172974, 5, 309, 1, 'Valley of Wisdom', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172974
(172973, 5, 309, 1, 'Cleft of Shadow', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172973
(172972, 5, 309, 1, 'Talon Gate', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172972
(172969, 5, 309, 1, 'Valley of Spirits', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172969
(173117, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173117
(173007, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173007
(177002, 8, 4572, 1.845776, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177002
(173101, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173101
(173062, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173062
(173025, 5, 709, 1.33, 'Stranglethorn Imported Fruits', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173025
(172995, 5, 309, 1, 'Valley of Spirits', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172995
(172994, 5, 309, 1, 'Orgrimmar Main Gate', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172994
(172993, 5, 309, 1, 'Valley of Strength', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172993
(172977, 5, 309, 1, 'The Drag', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172977
(172976, 5, 309, 1, 'Valley of Wisdom', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172976
(172975, 5, 309, 1, 'Cleft of Shadow', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172975
(173170, 5, 707, 1.33, 'Shadowswift Brotherhood', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173170
(173163, 8, 475, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173163
(173130, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173130
(173132, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173132
(173131, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173131
(173146, 8, 375, 0.819672, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173146
(173136, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173136
(173167, 8, 474, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173167
(173145, 8, 375, 0.819672, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173145
(173175, 8, 474, 1.14, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173175
(173169, 5, 713, 1.33, 'Rekkul\'s Poisons', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173169
(173165, 8, 474, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173165
(173144, 8, 375, 0.819672, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173144
(173143, 8, 375, 0.819672, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173143
(173177, 5, 707, 1.33, 'Ironwood Staves and Wands', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173177
(173142, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173142
(173139, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173139
(173138, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173138
(173137, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173137
(173141, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173141
(173140, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173140
(173172, 8, 474, 1.14, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173172
(177005, 8, 4572, 2.587224, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177005
(175316, 8, 474, 1.14, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 175316
(173173, 5, 714, 1.33, 'Shadowdeep Reagents', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173173
(177004, 8, 4572, 2.587224, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177004
(173058, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173058
(173057, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173057
(172981, 5, 309, 1, 'Valley of Honor', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172981
(172980, 5, 309, 1, 'Cleft of Shadow', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172980
(172979, 5, 309, 1, 'The Drag', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172979
(172978, 5, 309, 1, 'Thrall\'s Fortress', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172978
(175319, 5, 714, 1.33, 'Darkfire Enclave', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 175319
(173061, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173061
(173059, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173059
(175658, 9, 214, 1.9032, 'The Armor of Mannoroth', '', '', 1762, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 175658
(173060, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173060
(173056, 5, 710, 1.33, 'Asoran\'s Market', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173056
(175312, 8, 475, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 175312
(177003, 8, 4572, 2.587224, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177003
(172950, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172950
(172956, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172956
(173022, 5, 714, 1.33, 'Godan\'s Runeworks', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173022
(172951, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172951
(172944, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172944
(173050, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173050
(173194, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173194
(173184, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173184
(173178, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173178
(173179, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173179
(177013, 8, 4572, 2.042546, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177013
(177007, 8, 4572, 2.587224, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177007
(177006, 8, 4572, 2.587224, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177006
(173085, 5, 707, 1.33, 'Hunter\'s Hall', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173085
(173074, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173074
(173067, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173067
(173072, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173072
(177010, 8, 4572, 1.621068, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177010
(177011, 8, 4572, 1.945282, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177011
(173096, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173096
(173095, 8, 209, 1.109756, 'Forge', '', '', 3, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173095
(173094, 8, 273, 1.651786, 'Anvil', '', '', 1, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173094
(173083, 5, 716, 1.33, 'The Burning Anvil', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173083
(173073, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173073
(173065, 8, 273, 1.85, 'Anvil', '', '', 1, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173065
(173066, 8, 273, 1.85, 'Anvil', '', '', 1, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173066
(173064, 8, 209, 1.82, 'Forge', '', '', 3, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173064
(173089, 8, 373, 1.08, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173089
(173119, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173119
(173118, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173118
(173120, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173120
(173071, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173071
(173092, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173092
(173121, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173121
(173070, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173070
(173090, 8, 373, 1.08, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173090
(173123, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173123
(173122, 8, 408, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173122
(173082, 5, 716, 1.33, 'Nogg\'s Machine Shop', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173082
(173093, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173093
(173091, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173091
(173099, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173099
(173077, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173077
(173081, 5, 716, 1.33, 'Red Canyon Mining', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173081
(173063, 8, 305, 1.08, 'Forge', '', '', 3, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173063
(173080, 5, 715, 1.33, 'Orgrimmar Bowyer', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173080
(173100, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173100
(173068, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173068
(177012, 8, 4572, 1.945282, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177012
(173084, 5, 707, 1.33, 'Hall of the Brave', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173084
(173069, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173069
(173086, 5, 709, 1.33, 'Lumak\'s Fishing', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173086
(173088, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173088
(173075, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173075
(173087, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173087
(173076, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173076
(177009, 8, 4572, 1.621068, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177009
(173079, 5, 707, 1.33, 'Kiro\'s Harnesses', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173079
(172992, 5, 309, 1, 'The Drag', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172992
(177008, 8, 4572, 2.15602, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177008
(173042, 8, 373, 1.27, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173042
(173052, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173052
(173051, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173051
(173049, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173049
(173039, 8, 373, 1.27, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173039
(173041, 8, 373, 1.27, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173041
(173040, 8, 373, 1.27, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173040
(173038, 8, 373, 1.27, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173038
(173021, 5, 711, 1.33, 'Yelmak\'s Alchemy and Potions', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173021
(173054, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173054
(173048, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173048
(175314, 8, 474, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 175314
(173104, 8, 474, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173104
(173055, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173055
(173024, 5, 710, 1.33, 'Droffers And Sons Salvage', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173024
(173023, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173023
(172949, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172949
(173045, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173045
(173053, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173053
(172947, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172947
(173047, 19, 2128, 1, 'Mailbox', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173047
(173046, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173046
(173105, 8, 474, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173105
(173020, 5, 713, 1.33, 'Jandi\'s Arboretum', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173020
(173103, 8, 474, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173103
(172991, 5, 309, 1, 'Orgrimmar Main Gate', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172991
(172990, 5, 309, 1, 'Valley of Wisdom', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172990
(172989, 5, 309, 1, 'Valley of Honor', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172989
(172988, 5, 309, 1, 'Valley of Strength', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172988
(172987, 5, 309, 1, 'Cleft of Shadow', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172987
(172986, 5, 309, 1, 'Orgrimmar Main Gate', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172986
(172985, 5, 309, 1, 'Valley of Wisdom', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172985
(172984, 5, 309, 1, 'Valley of Honor', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172984
(172983, 5, 309, 1, 'Cleft of Shadow', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172983
(172982, 5, 309, 1, 'Valley of Strength', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172982
(173034, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173034
(172955, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172955
(173035, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173035
(173043, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173043
(172948, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172948
(173044, 5, 712, 1.33, 'Kodohide Leatherworkers', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173044
(173033, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173033
(173032, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173032
(173031, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173031
(173030, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173030
(173018, 5, 712, 1.33, 'Magar\'s Cloth Goods', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173018
(173036, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173036
(173037, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173037
(173028, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173028
(172954, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172954
(172946, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172946
(173019, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173019
(175315, 8, 474, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 175315
(173029, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173029
(173017, 5, 710, 1.33, 'Gotri\'s Travelling Gear', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173017
(173015, 8, 409, 0.8, 'Meat Rack', '', '', 4, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173015
(173014, 8, 409, 0.8, 'Meat Rack', '', '', 4, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173014
(172942, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172942
(175317, 8, 474, 1.14, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 175317
(173016, 5, 709, 1.33, 'Borstan\'s Firepit', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173016
(172941, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172941
(173027, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173027
(173026, 8, 409, 0.8, 'Meat Rack', '', '', 4, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173026
(179596, 23, 5498, 1, 'Meeting Stone', '', '', 13, 18, 2437, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 179596
(172945, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172945
(105576, 8, 465, 2, 'Summoning Circle', '', '', 203, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 105576
(175318, 8, 474, 1.14, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 175318
(175313, 8, 475, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 175313
(173166, 8, 474, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173166
(173102, 8, 474, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173102
(173168, 5, 707, 1.33, 'The Slow Blade', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173168
(173176, 8, 474, 1.14, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173176
(173174, 5, 713, 1.33, 'Dark Earth Fungus and Mushrooms', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173174
(173171, 8, 474, 1.14, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173171
(173164, 8, 475, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173164
(173116, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173116
(179739, 5, 309, 1, 'Hall of Legends', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 179739
(173006, 5, 711, 1.33, 'Spiritfury Reagents', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173006
(172968, 5, 309, 1, 'Valley of Spirits', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172968
(172952, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172952
(177025, 8, 4572, 2.547396, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177025
(172967, 5, 309, 1, 'Valley of Spirits', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172967
(172953, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172953
(173213, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173213
(172962, 5, 309, 1, 'Valley of Wisdom', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172962
(172963, 5, 309, 1, 'The Drag', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172963
(172964, 5, 309, 1, 'Valley of Honor', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172964
(177021, 8, 4572, 2.547396, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177021
(172966, 5, 309, 1, 'Valley of Spirits', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172966
(173210, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173210
(173212, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173212
(173211, 8, 373, 1.190001, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173211
(173113, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173113
(173125, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173125
(173108, 8, 409, 1, 'Meat Rack', '', '', 4, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173108
(173110, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173110
(177022, 8, 4572, 2.547396, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177022
(173214, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173214
(173209, 8, 409, 1, 'Meat Rack', '', '', 4, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173209
(173109, 8, 409, 1, 'Meat Rack', '', '', 4, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173109
(173107, 8, 331, 1, 'Orc Cooker', '', '', 4, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173107
(177026, 8, 4572, 2.211281, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177026
(173111, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173111
(173218, 5, 707, 1.33, 'Boomstick Imports', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173218
(173219, 5, 710, 1.33, 'The Skytower', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173219
(173217, 5, 709, 1.33, 'The Chophouse', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186); -- 173217

INSERT INTO `gameobject_template` (`entry`, `type`, `display_id`, `scale`, `name`, `icon_name`, `unk1`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `data24`, `data25`, `data26`, `data27`, `data28`, `data29`, `data30`, `data31`, `data32`, `data33`, `quest_items_count`, `required_level`, `sniff_build`) VALUES
(173208, 8, 409, 1, 'Meat Rack', '', '', 4, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173208
(173220, 5, 710, 1.33, 'Horde Embassy', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173220
(173222, 5, 710, 1.33, 'Orgrimmar Auction House', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173222
(172965, 5, 309, 1, 'Valley of Spirits', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172965
(173106, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173106
(173224, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173224
(173223, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173223
(173215, 5, 707, 1.33, 'The Shattered Axe', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173215
(173205, 8, 373, 1.19, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173205
(173115, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173115
(173225, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173225
(173114, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173114
(173226, 8, 375, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173226
(173221, 19, 2128, 1, 'Mailbox', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173221
(173216, 5, 708, 1.33, 'Bank of Orgrimmar', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173216
(173207, 8, 374, 1.752408, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173207
(177020, 8, 4572, 1.858219, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177020
(173206, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173206
(173204, 8, 373, 1.19, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173204
(177019, 8, 4572, 2.211281, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177019
(173202, 5, 717, 1.33, 'Soran\'s Leather and Steel Armory', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173202
(177024, 8, 4572, 2.211281, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177024
(173199, 8, 374, 1.4364, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173199
(173198, 8, 373, 1.19, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173198
(179881, 1, 5951, 1.25, 'The Severed Head of Nefarian', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 179881
(173197, 8, 373, 1.19, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173197
(173203, 5, 710, 1.33, 'Orgrimmar General Store', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173203
(173112, 8, 373, 1, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173112
(177017, 8, 4572, 2.211281, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177017
(173200, 8, 374, 1.608768, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173200
(172961, 5, 309, 1, 'Valley of Spirits', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172961
(172960, 5, 309, 1, 'Cleft of Shadow', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172960
(172959, 5, 309, 1, 'The Drag', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172959
(172958, 5, 309, 1, 'Valley of Honor', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172958
(172957, 5, 309, 1, 'Valley of Wisdom', '', '', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 172957
(180842, 5, 6602, 1, 'AQWar - Resource, Bars, Horde, Tier 4', '', '', 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 180842
(180822, 5, 6584, 1, 'AQWar - Resource, Herbs, Horde, Tier 4', '', '', 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 180822
(177018, 8, 4572, 2.211281, 'Bonfire', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 177018
(180836, 5, 6596, 1, 'AQWar - Resource, Cooking, Horde, Tier 4', '', '', 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 180836
(173012, 8, 373, 1.27, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173012
(173008, 8, 373, 1.27, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173008
(173010, 8, 373, 1.27, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173010
(173009, 8, 373, 1.27, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173009
(173011, 8, 373, 1.27, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173011
(173013, 8, 373, 1.27, 'Mighty Blaze', '', '', 4, 10, 2061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186), -- 173013
(180830, 5, 6590, 1, 'AQWar - Resource, Bandages, Horde, Tier 4', '', '', 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35186); -- 180830


DELETE FROM `npc_text` WHERE `entry` IN (5500 /*5500*/, 8107 /*8107*/, 7994 /*7994*/, 7991 /*7991*/, 7988 /*7988*/, 7971 /*7971*/, 7981 /*7981*/, 7984 /*7984*/, 8129 /*8129*/, 8126 /*8126*/, 8130 /*8130*/, 7962 /*7962*/, 7958 /*7958*/, 7960 /*7960*/, 7964 /*7964*/, 7969 /*7969*/, 7967 /*7967*/, 8003 /*8003*/, 8070 /*8070*/, 8000 /*8000*/, 8072 /*8072*/, 7997 /*7997*/, 8052 /*8052*/, 8049 /*8049*/, 8133 /*8133*/, 8013 /*8013*/, 8016 /*8016*/, 8010 /*8010*/, 8019 /*8019*/, 8022 /*8022*/, 8025 /*8025*/, 8055 /*8055*/, 8127 /*8127*/, 8131 /*8131*/, 8073 /*8073*/, 8037 /*8037*/, 8040 /*8040*/, 8043 /*8043*/, 8094 /*8094*/, 8031 /*8031*/, 8034 /*8034*/, 8074 /*8074*/, 8028 /*8028*/, 2593 /*2593*/, 7176 /*7176*/);
INSERT INTO `npc_text` (`entry`, `probability1`, `probability2`, `probability3`, `probability4`, `probability5`, `probability6`, `probability7`, `probability8`, `broadcast_text_id1`, `broadcast_text_id2`, `broadcast_text_id3`, `broadcast_text_id4`, `broadcast_text_id5`, `broadcast_text_id6`, `broadcast_text_id7`, `broadcast_text_id8`, `sniff_build`) VALUES
(5500, 1, 0, 0, 0, 0, 0, 0, 0, 8116, 0, 0, 0, 0, 0, 0, 0, 35186), -- 5500
(8107, 1, 0, 0, 0, 0, 0, 0, 0, 11384, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8107
(7994, 1, 0, 0, 0, 0, 0, 0, 0, 11186, 0, 0, 0, 0, 0, 0, 0, 35186), -- 7994
(7991, 1, 0, 0, 0, 0, 0, 0, 0, 11183, 0, 0, 0, 0, 0, 0, 0, 35186), -- 7991
(7988, 1, 0, 0, 0, 0, 0, 0, 0, 11180, 0, 0, 0, 0, 0, 0, 0, 35186), -- 7988
(7971, 1, 0, 0, 0, 0, 0, 0, 0, 11162, 0, 0, 0, 0, 0, 0, 0, 35186), -- 7971
(7981, 1, 0, 0, 0, 0, 0, 0, 0, 11171, 0, 0, 0, 0, 0, 0, 0, 35186), -- 7981
(7984, 1, 0, 0, 0, 0, 0, 0, 0, 11174, 0, 0, 0, 0, 0, 0, 0, 35186), -- 7984
(8129, 1, 0, 0, 0, 0, 0, 0, 0, 11417, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8129
(8126, 1, 0, 0, 0, 0, 0, 0, 0, 11415, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8126
(8130, 1, 0, 0, 0, 0, 0, 0, 0, 11418, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8130
(7962, 1, 0, 0, 0, 0, 0, 0, 0, 11151, 0, 0, 0, 0, 0, 0, 0, 35186), -- 7962
(7958, 1, 0, 0, 0, 0, 0, 0, 0, 11147, 0, 0, 0, 0, 0, 0, 0, 35186), -- 7958
(7960, 1, 0, 0, 0, 0, 0, 0, 0, 11149, 0, 0, 0, 0, 0, 0, 0, 35186), -- 7960
(7964, 1, 0, 0, 0, 0, 0, 0, 0, 11153, 0, 0, 0, 0, 0, 0, 0, 35186), -- 7964
(7969, 1, 0, 0, 0, 0, 0, 0, 0, 11158, 0, 0, 0, 0, 0, 0, 0, 35186), -- 7969
(7967, 1, 0, 0, 0, 0, 0, 0, 0, 11156, 0, 0, 0, 0, 0, 0, 0, 35186), -- 7967
(8003, 1, 0, 0, 0, 0, 0, 0, 0, 11201, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8003
(8070, 1, 0, 0, 0, 0, 0, 0, 0, 11337, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8070
(8000, 1, 0, 0, 0, 0, 0, 0, 0, 11198, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8000
(8072, 1, 0, 0, 0, 0, 0, 0, 0, 11339, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8072
(7997, 1, 0, 0, 0, 0, 0, 0, 0, 11189, 0, 0, 0, 0, 0, 0, 0, 35186), -- 7997
(8052, 1, 0, 0, 0, 0, 0, 0, 0, 11260, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8052
(8049, 1, 0, 0, 0, 0, 0, 0, 0, 11257, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8049
(8133, 1, 0, 0, 0, 0, 0, 0, 0, 11422, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8133
(8013, 1, 0, 0, 0, 0, 0, 0, 0, 11212, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8013
(8016, 1, 0, 0, 0, 0, 0, 0, 0, 11221, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8016
(8010, 1, 0, 0, 0, 0, 0, 0, 0, 11209, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8010
(8019, 1, 0, 0, 0, 0, 0, 0, 0, 11224, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8019
(8022, 1, 0, 0, 0, 0, 0, 0, 0, 11227, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8022
(8025, 1, 0, 0, 0, 0, 0, 0, 0, 11233, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8025
(8055, 1, 0, 0, 0, 0, 0, 0, 0, 11263, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8055
(8127, 1, 0, 0, 0, 0, 0, 0, 0, 11420, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8127
(8131, 1, 0, 0, 0, 0, 0, 0, 0, 11419, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8131
(8073, 1, 0, 0, 0, 0, 0, 0, 0, 11341, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8073
(8037, 1, 0, 0, 0, 0, 0, 0, 0, 11245, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8037
(8040, 1, 0, 0, 0, 0, 0, 0, 0, 11248, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8040
(8043, 1, 0, 0, 0, 0, 0, 0, 0, 11251, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8043
(8094, 1, 0, 0, 0, 0, 0, 0, 0, 11372, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8094
(8031, 1, 0, 0, 0, 0, 0, 0, 0, 11239, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8031
(8034, 1, 0, 0, 0, 0, 0, 0, 0, 11242, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8034
(8074, 1, 0, 0, 0, 0, 0, 0, 0, 11342, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8074
(8028, 1, 0, 0, 0, 0, 0, 0, 0, 11236, 0, 0, 0, 0, 0, 0, 0, 35186), -- 8028
(2593, 100, 0, 0, 0, 0, 0, 0, 0, 4857, 0, 0, 0, 0, 0, 0, 0, 35186), -- 2593
(7176, 1, 0, 0, 0, 0, 0, 0, 0, 9869, 0, 0, 0, 0, 0, 0, 0, 35186); -- 7176


INSERT INTO `sniff_file` (`id`, `build`, `name`) VALUES
(@SNIFFID+0, 35186, 'war_effort_thunder_bluff_recruiter_(1.13.5.35186)_07-31-2020.pkt'),
(@SNIFFID+1, 35186, 'war_effort_aftermath_ironforge_(1.13.5.35186)_07-31-2020.pkt'),
(@SNIFFID+2, 35186, 'war_effort_aftermath_orgrimmar_(1.13.5.35186)_07-31-2020.pkt');

